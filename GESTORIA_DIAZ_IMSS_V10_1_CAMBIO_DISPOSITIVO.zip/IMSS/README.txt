IMSS V10.1: corrección de SÍ, QUIERO HACER EL CAMBIO.
Lee CAMBIO_V10_1.md. Abre ABRIR_BOT.bat y confirma la autorización del titular en cada trámite.
94 pruebas locales superadas; pendiente validar el clic en tu HONOR real.
No incluye PIN ni datos de clientes.
