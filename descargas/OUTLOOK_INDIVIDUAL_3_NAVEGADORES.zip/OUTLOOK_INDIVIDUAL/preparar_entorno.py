"""Prepare a private Python runtime for the standalone Outlook application."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import venv


def main():
    if sys.version_info < (3, 10):
        print('Instala Python 3.10 o superior con Tcl/Tk.')
        return 1
    root = Path(__file__).resolve().parent
    folder = root / '.venv'
    interpreter = folder / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    requirements = root / 'requirements.txt'
    signature = hashlib.sha256(requirements.read_bytes()).hexdigest()
    marker = folder / 'requisitos_instalados.json'
    if not interpreter.exists():
        print('Preparando Outlook individual...')
        venv.EnvBuilder(with_pip=True, symlinks=os.name != 'nt').create(folder)
    installed = False
    try:
        installed = json.loads(marker.read_text())['sha256'] == signature
    except (OSError, ValueError, KeyError):
        pass
    if installed:
        installed = subprocess.run([str(interpreter), '-c', 'import selenium, tkinter'],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    if not installed:
        print('Instalando dependencias de Outlook...')
        result = subprocess.run([str(interpreter), '-m', 'pip', 'install', '-r', str(requirements)])
        if result.returncode:
            print('No se pudieron instalar las dependencias. Revisa la conexion a Internet.')
            return 1
        marker.write_text(json.dumps({'sha256': signature}))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print('No se pudo preparar el entorno: ' + type(error).__name__)
        raise SystemExit(1)
