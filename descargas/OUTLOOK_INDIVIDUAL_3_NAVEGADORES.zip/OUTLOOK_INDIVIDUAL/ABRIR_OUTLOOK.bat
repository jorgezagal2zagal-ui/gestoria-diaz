@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  set "OUTLOOK_PYTHON=python"
) else (
  set "OUTLOOK_PYTHON=py -3"
)
%OUTLOOK_PYTHON% preparar_entorno.py
if errorlevel 1 goto error
"%~dp0.venv\Scripts\python.exe" "%~dp0app.py"
if errorlevel 1 goto error
exit /b 0
:error
echo No se pudo abrir Outlook individual. Revisa el mensaje anterior.
pause
exit /b 1
