import shutil
from urllib.parse import urlsplit

class Element:
    def __init__(self,locator):self.locator=locator
    @property
    def text(self):return self.locator.inner_text()
    def is_displayed(self):return self.locator.is_visible()
    def is_enabled(self):return self.locator.is_enabled()
    def clear(self):self.locator.fill('')
    def send_keys(self,value):self.locator.fill(value)
    def click(self):self.locator.click()

class Driver:
    def __init__(self,fail):
        from playwright.sync_api import sync_playwright
        self.pw=sync_playwright().start();self.browser=self.pw.chromium.launch(executable_path=shutil.which('chromium') or shutil.which('chrome'),args=['--no-sandbox'])
        self.page=self.browser.new_page();self.closed=False;self.fail=fail
        self.page.route('**/*',self.route)
    def route(self,route):
        url=route.request.url
        if url=='https://login.live.com/':html='<input type="email"><button type="submit" onclick="location.href=\'/password\'">Next</button>'
        elif urlsplit(url).path=='/password':
            dest='https://login.live.com/unavailable' if self.fail else 'https://account.microsoft.com/'
            html=f'<input type="password"><button type="submit" onclick="location.href=\'{dest}\'">Sign in</button>'
        elif urlsplit(url).path=='/unavailable':html='<p>El inicio de sesión con contraseña no está disponible. Pruebe con otro método.</p>'
        elif 'outlook.live.com' in url:html='<div role="main">Inbox</div>'
        else:html='<main>Account</main>'
        route.fulfill(status=200,content_type='text/html; charset=utf-8',body='<meta charset="utf-8">'+html)
    @property
    def current_url(self):return self.page.url
    def get(self,url):self.page.goto(url)
    def find_elements(self,by,selector):
        return [Element(x) for x in self.page.locator('xpath='+selector if by=='xpath' else selector).all()]
    def quit(self):
        if not self.closed:self.closed=True;self.browser.close();self.pw.stop()
