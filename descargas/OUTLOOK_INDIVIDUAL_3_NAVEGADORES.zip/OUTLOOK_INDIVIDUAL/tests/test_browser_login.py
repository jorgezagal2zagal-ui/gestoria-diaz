import sys
import unittest
from pathlib import Path
from unittest.mock import Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from automation import open_inbox,try_account
from core import Account
from browser_fixture import Driver

class LocalBrowserTests(unittest.TestCase):
    def test_real_login_three_windows_first_two_fail_third_keeps_inbox_open(self):
        drivers=[];names=[];account=Account('fixture@example.com','fixture')
        def attempt(account,browser,cancelled,report):
            driver=Driver(fail=browser!='firefox');drivers.append(driver);names.append(browser)
            return open_inbox(account,browser,cancelled,report,driver_factory=lambda name:driver,timeout=5,stage_timeout=2)
        try:
            result=try_account(account,['chrome','edge','firefox'],lambda:False,Mock(),attempt)
            self.assertEqual(names,['chrome','edge','firefox'])
            self.assertTrue(drivers[0].closed);self.assertTrue(drivers[1].closed)
            self.assertIs(result,drivers[2]);self.assertFalse(result.closed)
            self.assertEqual(result.current_url,'https://outlook.live.com/mail/0/inbox')
        finally:
            for driver in drivers:driver.quit()

if __name__=='__main__':unittest.main()
