import sys
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import Account, parse_accounts
from automation import try_account, PasswordUnavailable, LoginFailure, SkipRequested, RateLimited, available_browsers
from app import App

class IndividualTests(unittest.TestCase):
    def test_tries_same_account_chrome_edge_firefox_then_fails(self):
        account=Account('fixture@example.com','fixture');calls=[]
        def attempt(item,browser,*args):calls.append((item,browser));raise PasswordUnavailable()
        with self.assertRaises(LoginFailure):try_account(account,['firefox','edge','chrome','chrome'],lambda:False,Mock(),attempt)
        self.assertEqual(calls,[(account,'chrome'),(account,'edge'),(account,'firefox')])
    def test_firefox_success_is_returned_without_closing(self):
        driver=Mock();calls=[]
        def attempt(account,browser,*args):
            calls.append(browser)
            if browser!='firefox':raise PasswordUnavailable()
            return driver
        self.assertIs(try_account(Account('fixture@example.com','fixture'),['chrome','edge','firefox'],lambda:False,Mock(),attempt),driver)
        self.assertEqual(calls,['chrome','edge','firefox']);driver.quit.assert_not_called()
    def test_chrome_success_never_opens_other_browsers(self):
        attempt=Mock(return_value=Mock())
        try_account(Account('fixture@example.com','fixture'),['chrome','edge','firefox'],lambda:False,Mock(),attempt)
        attempt.assert_called_once();self.assertEqual(attempt.call_args.args[1],'chrome')
    def test_missing_browser_is_skipped_without_repeating_installed_one(self):
        with patch('automation.browser_binary',side_effect=lambda name:'/binary' if name!='edge' else None):
            self.assertEqual(available_browsers(),['chrome','firefox'])
    def test_stop_between_attempts_does_not_open_next_browser(self):
        stopped=threading.Event();calls=[]
        def attempt(account,browser,*args):calls.append(browser);stopped.set();raise PasswordUnavailable()
        with self.assertRaises(SkipRequested):try_account(Account('fixture@example.com','fixture'),['chrome','edge','firefox'],stopped.is_set,Mock(),attempt)
        self.assertEqual(calls,['chrome'])
    def test_rate_limit_stops_without_changing_browser(self):
        attempt=Mock(side_effect=RateLimited())
        with self.assertRaises(RateLimited):try_account(Account('fixture@example.com','fixture'),['chrome','edge','firefox'],lambda:False,Mock(),attempt)
        attempt.assert_called_once()
    def harness(self):
        return SimpleNamespace(_skip_event=threading.Event(),_stop_event=threading.Event(),_post=lambda fn:fn(),_account_status=Mock(),_record_result=Mock(),_finish_run=Mock(),status=Mock())
    def test_three_failed_browsers_advance_account_and_success_stays_open(self):
        harness=self.harness();entered=threading.Event();driver=Mock();calls=[]
        accounts=[Account('first@example.com','fixture'),Account('second@example.com','fixture'),Account('third@example.com','fixture')]
        def opening(account,browser,*args):
            calls.append((account.address,browser))
            if account.address==accounts[0].address:raise PasswordUnavailable()
            return driver
        def record(address,result,detail):
            if result=='Entró a la bandeja':entered.set()
        harness._record_result.side_effect=record
        with patch('automation.open_inbox',side_effect=opening):
            thread=threading.Thread(target=App._run_accounts,args=(harness,accounts,['chrome','edge','firefox']));thread.start()
            try:
                self.assertTrue(entered.wait(2));self.assertTrue(thread.is_alive());driver.quit.assert_not_called()
                self.assertEqual(calls,[('first@example.com','chrome'),('first@example.com','edge'),('first@example.com','firefox'),('second@example.com','chrome')])
            finally:harness._stop_event.set();harness._skip_event.set();thread.join(2)
        self.assertFalse(thread.is_alive());driver.quit.assert_called_once();harness._finish_run.assert_called_once()
    def test_only_next_button_advances_successful_account(self):
        harness=self.harness();entered=[threading.Event(),threading.Event()];driver1=Mock();driver2=Mock()
        accounts=[Account('first@example.com','fixture'),Account('second@example.com','fixture')]
        def record(address,result,detail):
            if result=='Entró a la bandeja':entered[0 if address==accounts[0].address else 1].set()
        harness._record_result.side_effect=record
        with patch('automation.open_inbox',side_effect=[driver1,driver2]) as opening:
            thread=threading.Thread(target=App._run_accounts,args=(harness,accounts,['chrome','edge','firefox']));thread.start()
            try:
                self.assertTrue(entered[0].wait(2));self.assertFalse(entered[1].wait(.1));driver1.quit.assert_not_called()
                harness._skip_event.set();self.assertTrue(entered[1].wait(2));driver1.quit.assert_called_once();driver2.quit.assert_not_called()
                self.assertEqual(opening.call_count,2)
            finally:harness._stop_event.set();harness._skip_event.set();thread.join(2)
        driver2.quit.assert_called_once()
    def test_exception_reports_do_not_include_password(self):
        report=Mock()
        with self.assertRaises(LoginFailure):try_account(Account('fixture@example.com','secret-marker'),['chrome','edge','firefox'],lambda:False,report,Mock(side_effect=RuntimeError('secret-marker')))
        self.assertNotIn('secret-marker',repr(report.call_args_list))
    def test_import_keeps_password_with_colons(self):
        accounts=parse_accounts('fixture@example.com:abc:def')
        self.assertEqual(accounts[0].password,'abc:def')

if __name__=='__main__':unittest.main()
