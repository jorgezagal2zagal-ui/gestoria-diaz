import sys
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from conexion.batch import BatchStore, QueueInput
from conexion.parallel import ConcurrentRunner, JobEngine
from conexion.parallel_ui import ParallelPanel
from conexion.result import RequestResult

CURPS=['AAAA010101HDFBBB01','BBBB020202HDFCCC02','CCCC030303HDFDDD03']
class DispatchTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        self.store=BatchStore(tmp.name)
    def add(self,index=0,instance=''):
        self.store.import_items([QueueInput(CURPS[index],'semanas',instance)])
        return self.store.find(CURPS[index],'semanas')
    def test_old_assignment_does_not_pin_automatic_pending(self):
        item=self.add()
        with self.store.connect() as db:db.execute("UPDATE jobs SET instancia='CERRADO' WHERE id=?",(item['id'],))
        claimed=self.store.claim(['ABIERTO'],capacity=1)
        self.assertEqual(claimed['instancia'],'ABIERTO')
    def test_manual_instance_is_respected(self):
        self.add(instance='ELEGIDO')
        self.assertIsNone(self.store.claim(['OTRO'],capacity=1))
        self.assertEqual(self.store.claim(['ELEGIDO'],capacity=1)['instancia'],'ELEGIDO')
    def test_busy_emulator_does_not_block_other_open_emulator(self):
        self.add(0);self.add(1)
        self.store.claim(['OCUPADO'],capacity=3)
        self.assertEqual(self.store.claim(['OCUPADO','LIBRE'],capacity=3)['instancia'],'LIBRE')
    def test_review_only_blocks_its_own_instance(self):
        item=self.add(0);self.add(1)
        with self.store.connect() as db:db.execute("UPDATE jobs SET estado='revision',instancia='DUDOSO' WHERE id=?",(item['id'],))
        self.assertEqual(self.store.claim(['DUDOSO','LIBRE'],capacity=1)['instancia'],'LIBRE')
    def test_review_instance_reused_only_after_idle_screen_check(self):
        item=self.add(0);self.add(1)
        with self.store.connect() as db:db.execute("UPDATE jobs SET estado='revision',instancia='ABIERTO' WHERE id=?",(item['id'],))
        self.assertIsNone(self.store.claim(['ABIERTO']))
        self.assertEqual(self.store.claim(['ABIERTO'],verified_idle=['ABIERTO'])['instancia'],'ABIERTO')
        self.assertEqual(self.store.find(CURPS[0],'semanas')['estado'],'revision')
    def test_waits_then_dispatches_when_any_emulator_opens(self):
        self.add();opened=[];called=threading.Event();seen=[]
        def execute(item):
            seen.append(item['instancia']);called.set()
            return RequestResult('completada',attempts=1)
        runner=ConcurrentRunner(self.store,execute);runner.capacity=1
        runner.start(lambda:tuple(opened))
        try:
            self.assertFalse(called.wait(.1))
            self.assertTrue(runner.running)
            opened.append('NUEVO_ABIERTO');runner.wake.set()
            self.assertTrue(called.wait(2))
            runner.thread.join(2)
            self.assertEqual(seen,['NUEVO_ABIERTO'])
            self.assertEqual(self.store.counts()['completada'],1)
        finally:runner.stop();runner.thread.join(2)
    def test_immediately_reuses_released_emulator(self):
        self.add(0);self.add(1);seen=[]
        def execute(item):
            seen.append(item['instancia']);return RequestResult('completada',attempts=1)
        runner=ConcurrentRunner(self.store,execute);runner.capacity=1
        runner.start(lambda:('ABIERTO',));runner.thread.join(3)
        self.assertFalse(runner.running)
        self.assertEqual(seen,['ABIERTO','ABIERTO'])
    def panel(self):
        panel=ParallelPanel.__new__(ParallelPanel)
        panel.store=self.store;panel.detail=Mock();panel.rows={};panel.table=Mock()
        panel.start=Mock();panel.app=SimpleNamespace(root=Mock(),ruta=lambda:'ldconsole')
        return panel
    def test_duplicate_pending_resumes_instead_of_returning(self):
        item=self.add();panel=self.panel()
        panel.retry_saved(item,'ldconsole')
        panel.start.assert_called_once_with('ldconsole')
        self.assertEqual(len(self.store.rows()),1)
    def test_saved_pending_and_review_are_visible(self):
        a=self.add(0);b=self.add(1)
        with self.store.connect() as db:db.execute("UPDATE jobs SET estado='revision' WHERE id=?",(b['id'],))
        panel=self.panel();panel.load_saved_rows()
        self.assertEqual(set(panel.rows),{a['id'],b['id']})
    def test_review_not_repeated_without_operator_review(self):
        item=self.add()
        with self.store.connect() as db:db.execute("UPDATE jobs SET estado='revision' WHERE id=?",(item['id'],))
        panel=self.panel()
        with patch('conexion.parallel_ui.messagebox.askyesno',return_value=False):
            panel.retry_saved(self.store.find(CURPS[0],'semanas'),'ldconsole')
        panel.start.assert_not_called()
        self.assertEqual(self.store.find(CURPS[0],'semanas')['estado'],'revision')
    def test_completed_request_not_repeated(self):
        item=self.add()
        with self.store.connect() as db:db.execute("UPDATE jobs SET estado='completada' WHERE id=?",(item['id'],))
        panel=self.panel();panel.retry_saved(self.store.find(CURPS[0],'semanas'),'ldconsole')
        panel.start.assert_not_called()

class DetectorApp:
    pass
class DetectorTests(unittest.TestCase):
    def test_detects_open_instances_outside_selected_count_and_skips_code_screen(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        store=BatchStore(tmp.name)
        app=DetectorApp();app.usados_sesion=set()
        app.conexion=SimpleNamespace(bridge=SimpleNamespace(excluded_emails=lambda:set()),batch=SimpleNamespace(store=store))
        engine=JobEngine(app,Mock());engine.snapshot={'path':'ldconsole'}
        nodes=[{'visible':True,'area':1,'enabled':True,'texto':'form'}]
        fake=SimpleNamespace(
            listar=lambda path:{'CERRADO':{'running':False,'android':False,'index':'0'},'OTRO_ABIERTO':{'running':True,'android':True,'index':'4'},'CON_CODIGO':{'running':True,'android':True,'index':'5'}},
            pantalla=lambda path,idx:nodes if idx=='4' else [{'visible':True,'area':1,'enabled':True,'texto':'Código de validación'}],
            todo_texto=lambda ns:' '.join(n['texto'] for n in ns),
            cajas_codigo_validacion=lambda ns:False,buscar=lambda ns,key:True,
        )
        with patch.dict(sys.modules,{DetectorApp.__module__:fake}):
            self.assertEqual(engine.open_idle_instances(),('OTRO_ABIERTO',))

if __name__=='__main__':unittest.main()
