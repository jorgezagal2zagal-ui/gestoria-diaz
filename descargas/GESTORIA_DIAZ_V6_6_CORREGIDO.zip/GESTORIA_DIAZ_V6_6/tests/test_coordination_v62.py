"""Exercise the real request loop with local fake IMSS and bridge services."""
import sys
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from conexion.imss_link import ImssConnection

class FakeApp:
    __module__ = 'coordination_fixture'
    def __init__(self, connection):
        self.c=connection
        self.root=SimpleNamespace(after=lambda delay,fn:fn())
        self.usados_sesion=set()
        self.codigo=Mock()
        self.btn_consulta=Mock()
        self.selector_cantidad=Mock()
        self.btn_codigo=Mock()
        self.events=Mock()
        self.emit=Mock()
        self.consultas=[]
        self.validaciones=[]
        self.resultado_tramite=False
        self.pendiente=None
    def _consulta(self,path,curp,email,instance,procedure):
        self.consultas.append((curp,email,instance))
        self.pendiente=(path,0,instance,curp,email,procedure)
    def _codigo(self,code,*pending):
        self.validaciones.append((code,pending[3],pending[4]))
        if len(self.validaciones)==1 and self.c.reject_first:
            self.c.rejected=True
            self.c.reset_ready=True
        else:
            self.resultado_tramite=True

class CoordinationTests(unittest.TestCase):
    def setup_connection(self,responses):
        c=ImssConnection.__new__(ImssConnection)
        c.cancel=threading.Event();c.skip=threading.Event()
        c.reject_first=False;c.active=True;c.job=None;c.history=None
        c.app=FakeApp(c)
        c.bridge=Mock()
        c.bridge.presence.return_value={'emails':['a@example.com','b@example.com','c@example.com']}
        c.bridge.excluded_emails.return_value=set()
        c.bridge.create.side_effect=['job1','job2','job3']
        c.response=Mock(side_effect=responses)
        self.entered=threading.Event()
        original=c.state
        def state(stage,text,detail='',timeout=None):
            original(stage,text,detail,timeout)
            if text.startswith('Lectura pendiente;'):
                self.entered.set()
        c.state=state
        return c
    def run_connection(self,c):
        c.run('ldconsole','CURP_PRUEBA','INSTANCIA_1','semanas','','')
    def setUp(self):
        self.modules=patch.dict(sys.modules,{'coordination_fixture':SimpleNamespace(correos_usados=lambda:set())})
        self.modules.start();self.addCleanup(self.modules.stop)
    def check_review(self,responses,submissions):
        c=self.setup_connection(responses)
        thread=threading.Thread(target=self.run_connection,args=(c,))
        thread.start()
        try:
            self.assertTrue(self.entered.wait(2),'request did not enter review')
            self.assertTrue(thread.is_alive())
            self.assertEqual(c.bridge.create.call_count,1)
            self.assertEqual(c.bridge.finish.call_count,0)
            self.assertEqual(len(c.app.consultas),submissions)
            self.assertEqual(c.app.validaciones,[])
        finally:
            c.cancel.set();thread.join(2)
        self.assertFalse(thread.is_alive())
        self.assertEqual(c.bridge.finish.call_count,1)
    def test_reader_error_before_imss_keeps_same_job(self):
        self.check_review([{'status':'reader_error','reason':'lector'}],0)
    def test_reader_error_after_imss_keeps_same_job(self):
        self.check_review([{'status':'ready'},{'status':'reader_error','reason':'lector'}],1)
    def test_timeout_does_not_change_email(self):
        self.check_review([{'status':'ready'},{'status':'error','reason':'timeout'}],1)
    def test_login_error_does_not_rotate_accounts(self):
        c=self.setup_connection([{'status':'error'}]);self.run_connection(c)
        self.assertEqual(c.bridge.create.call_count,1)
        self.assertEqual(c.app.consultas,[])
    def test_imss_rejection_retries_same_curp_with_new_email(self):
        c=self.setup_connection([{'status':'ready'},{'status':'code','code':'204655'},{'status':'ready'},{'status':'code','code':'856465'}])
        c.reject_first=True;self.run_connection(c)
        self.assertEqual(c.last_result.status,'completada')
        self.assertEqual(c.app.consultas,[('CURP_PRUEBA','a@example.com','INSTANCIA_1'),('CURP_PRUEBA','b@example.com','INSTANCIA_1')])
        self.assertEqual(len(c.app.validaciones),2)
        self.assertEqual(c.bridge.create.call_count,2)
    def test_success_uses_one_request(self):
        c=self.setup_connection([{'status':'ready'},{'status':'code','code':'204655'}]);self.run_connection(c)
        self.assertEqual(c.last_result.status,'completada')
        self.assertEqual(c.bridge.create.call_count,1)

if __name__=='__main__':unittest.main()
