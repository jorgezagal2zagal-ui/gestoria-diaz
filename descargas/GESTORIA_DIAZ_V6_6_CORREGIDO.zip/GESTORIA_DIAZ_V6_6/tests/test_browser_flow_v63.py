"""Real queue, worker threads, disk bridge, reader and Chromium; fake IMSS/login only."""
import sys
import shutil
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from conexion.batch import BatchStore, QueueInput
from conexion.bridge import Bridge
from conexion.parallel import JobEngine, ConcurrentRunner
from conexion.reader import normalized, ROW
from test_reader_v62 import Element

class BrowserElement(Element):
    def find_elements(self,by,selector):
        return [BrowserElement(x) for x in self.locator.locator(selector).all()]
    def click(self):self.locator.click()

class LocalDriver:
    def __init__(self,submitted,events):
        from playwright.sync_api import sync_playwright
        self.pw=sync_playwright().start()
        self.browser=self.pw.chromium.launch(executable_path=shutil.which('chromium') or shutil.which('chrome'),args=['--no-sandbox'])
        self.page=self.browser.new_page()
        self.page.route('**/*',lambda route:route.fulfill(status=200,content_type='text/html',body='<div role="listbox" style="height:100px">Inbox</div>'))
        self.page.goto('https://outlook.live.com/mail/0/inbox')
        self.submitted=submitted;self.inserted=False;self.events=events
        events.append('browser_opened')
    @property
    def current_url(self):return self.page.url
    def set_page_load_timeout(self,value):pass
    def set_script_timeout(self,value):pass
    def find_elements(self,by,selector):
        if selector==ROW and self.submitted.is_set() and not self.inserted:
            self.inserted=True
            self.page.set_content(f'''<div role="listbox"><div role="option" data-item-id="new">Código de Verificación</div></div>
            <div data-app-section="MailReadCompose" data-item-id="new"><span>verifica-noreplay@imss.gob.mx</span>
            <time datetime="{time.time()}"></time><div id="UniqueMessageBody">Tu código de verificación es: 204655</div></div>''')
        return [BrowserElement(x) for x in self.page.locator(selector).all()]
    def execute_script(self,script,pane):
        return pane.locator.evaluate('(pane)=>{return (function(){'+script+'}).call(null,pane)}')
    def refresh(self):pass
    def quit(self):
        self.events.append('browser_closed');self.browser.close();self.pw.stop()

class FlowApp:
    __module__='browser_flow_fixture'
    def preparar_solicitud(self,*args):return True
    def work(self,*args,**kwargs):return True
    def foto(self,*args):pass
    def _consulta(self,path,curp,email,instance,procedure):
        self.events_log.append(('imss_started',instance))
        self.pendiente=(path,0,instance,curp,email,procedure)
        self.submitted.set()
    def _codigo(self,code,*pending):
        self.events_log.append(('imss_code',code,pending[2]))
        self.resultado_tramite=True

class BrowserFlowTests(unittest.TestCase):
    def test_pending_to_open_browser_to_imss_code_on_any_idle_emulator(self):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        store=BatchStore(tmp.name);store.import_items([QueueInput('AAAA010101HDFBBB01','semanas')])
        # Reproduce a stale assignment left by a prior run.
        with store.connect() as db:db.execute("UPDATE jobs SET instancia='CERRADO'")
        app=FlowApp();app.usados_sesion=set();app.events_log=[];app.submitted=threading.Event()
        for attr in ('arranque','enviados','bloqueada','sesion','ultimo_abrir','intentos_pin'):setattr(app,attr,{})
        app.registrar_correo=Mock();app.estado=Mock();app.emit=Mock()
        app.outlook=SimpleNamespace(warm_email='',_record_result=Mock())
        app.conexion=SimpleNamespace(bridge=Bridge(Path(tmp.name)/'bridge'),history=None,batch=SimpleNamespace(store=store))
        engine=JobEngine(app,Mock());engine.snapshot={'path':'ldconsole','timeout':60,'accounts':(SimpleNamespace(address='fixture@example.com'),)}
        nodes=[{'visible':True,'area':1,'enabled':True,'texto':'Inicia sesión','id':'txtCURP'}, {'visible':True,'area':1,'enabled':True,'texto':'Correo','id':'txtCorreo'}]
        fixture=SimpleNamespace(
            listar=lambda path:{'LIBRE_NO_SELECCIONADO':{'running':True,'android':True,'index':'4'}},
            pantalla=lambda *args:nodes,todo_texto=lambda ns:' '.join(n['texto'] for n in ns),
            texto_normalizado=normalized,buscar=lambda ns,key:next((n for n in ns if n['id']==key),None),
            cajas_codigo_validacion=lambda ns:[],correos_usados=lambda:set(),abrir_app=Mock(),tramite_confirmado=lambda words:False,
        )
        runner=ConcurrentRunner(store,engine.execute,can_dispatch=engine.has_mailboxes);runner.capacity=1
        def open_local(worker,account,browsers,cancelled,report):return LocalDriver(app.submitted,app.events_log)
        with patch.dict(sys.modules,{'browser_flow_fixture':fixture}), patch('outlook_conectado.OutlookWorker.open_account',new=open_local),patch('automation.available_browsers',return_value=['local fixture']),patch('outlook_conectado.SpecialPages') as pages:
            pages.return_value.handle.return_value=None
            runner.start(engine.open_idle_instances)
            runner.thread.join(12)
            if runner.running:
                runner.stop();engine.cancel();runner.thread.join(3)
                self.fail('The full browser/IMSS flow failed to finish: '+repr(app.events_log))
        self.assertEqual(store.counts()['completada'],1)
        self.assertEqual(app.events_log,['browser_opened',('imss_started','LIBRE_NO_SELECCIONADO'),('imss_code','204655','LIBRE_NO_SELECCIONADO'),'browser_closed'])
        self.assertFalse(engine.contexts)

if __name__=='__main__':unittest.main()
