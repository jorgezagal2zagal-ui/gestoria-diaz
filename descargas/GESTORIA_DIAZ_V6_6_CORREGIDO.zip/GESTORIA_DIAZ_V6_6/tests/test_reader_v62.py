"""Regression checks for the native Outlook header (local Chromium, no login)."""
import sys
import shutil
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from conexion.reader import NATIVE_HEADER, OutlookReader, extract_code

class Element:
    def __init__(self, locator):
        self.locator = locator
    @property
    def text(self):
        return self.locator.inner_text()
    def get_attribute(self, name):
        return self.locator.get_attribute(name)
    def is_displayed(self):
        return self.locator.is_visible()
    def find_elements(self, by, selector):
        return [Element(x) for x in self.locator.locator(selector).all()]

class Driver:
    def __init__(self, page):
        self.page = page
    def execute_script(self, script, pane):
        return pane.locator.evaluate('(pane) => { return (function(){' + script + '}).call(null, pane); }')

class ReaderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from playwright.sync_api import sync_playwright
        cls.pw = sync_playwright().start()
        cls.browser = cls.pw.chromium.launch(executable_path=shutil.which('chromium') or shutil.which('chrome'), args=['--no-sandbox'])
    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()
    def setUp(self):
        self.page = self.browser.new_page()
        self.addCleanup(self.page.close)
    def fixture(self, sender='verifica-noreplay@imss.gob.mx', body_id='UniqueMessageBody', attributed=False):
        # Absolute timestamp remains authoritative; old messages stay rejected.
        import time
        stamp = str(time.time())
        attr = ' email="'+sender+'"' if attributed else ''
        self.page.set_content(f'''<div id="row" data-item-id="new"></div>
        <div id="pane" data-item-id="new" class="allowTextSelection">
        <span{attr}>{sender}</span><time datetime="{stamp}"></time>
        <div id="{body_id}">Tu código de verificación es: 204655
        Este código expira en 20 minutos</div></div>''')
        return Element(self.page.locator('#row')), Element(self.page.locator('#pane'))
    def test_plain_native_sender_delivers_code(self):
        import time
        row,pane=self.fixture()
        reader=OutlookReader(Driver(self.page))
        self.assertEqual(reader.inspect(row,pane,time.time()-2), '204655')
    def test_prefixed_body_id(self):
        row,pane=self.fixture(body_id='m_123_UniqueMessageBody')
        meta=Driver(self.page).execute_script(NATIVE_HEADER,pane)
        self.assertIn('verifica-noreplay@imss.gob.mx',meta['addresses'])
    def test_sender_in_body_cannot_authenticate_itself(self):
        import time
        row,pane=self.fixture(sender='other@example.com')
        self.page.locator('#UniqueMessageBody').evaluate('(el)=>{el.innerHTML += "<span>verifica-noreplay@imss.gob.mx</span>"}')
        self.assertIsNone(OutlookReader(Driver(self.page)).inspect(row,pane,time.time()-2))
    def test_existing_attributed_header(self):
        import time
        row,pane=self.fixture(attributed=True)
        self.assertEqual(OutlookReader(Driver(self.page)).inspect(row,pane,time.time()-2),'204655')
    def test_old_code_still_rejected(self):
        import time
        row,pane=self.fixture()
        self.assertIsNone(OutlookReader(Driver(self.page)).inspect(row,pane,time.time()+100))
    def test_multiple_codes_rejected(self):
        self.assertIsNone(extract_code('Código de verificación: 204655\nCódigo de verificación: 856465'))

if __name__ == '__main__':
    unittest.main()
