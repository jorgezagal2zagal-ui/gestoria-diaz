import sys
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from outlook_conectado import OutlookWorker

class LifecycleTests(unittest.TestCase):
    def exercise(self, failure):
        worker=OutlookWorker()
        worker.accounts=[SimpleNamespace(address='a@example.com')]
        worker.job_cancel=threading.Event();worker.shutdown=threading.Event()
        worker.accepting=True;worker.baseline_timeout=0
        worker.bridge=Mock();worker.bridge.job.return_value=Path('/tmp/fixture_job');worker.bridge.cancelled.return_value=False
        worker.bridge.response.return_value={'status':'reader_error' if failure else 'code'}
        worker._post=lambda cb: cb()
        worker.manage_buttons=[]
        for name in ('start_button','skip_button','stop_button','status'):
            setattr(worker,name,Mock())
        worker._record_result=Mock();worker._account_status=Mock()
        driver=Mock();worker.open_account=Mock(return_value=driver)
        reader=Mock();reader.last_diagnostic='fixture'
        if failure:
            reader.baseline.side_effect=RuntimeError('fixture')
        else:
            reader.scan.return_value='204655'
        waiting=threading.Event()
        def reply(key,status,**kwargs):
            if status in ('code','reader_error'):
                waiting.set()
        worker.bridge.reply.side_effect=reply
        request={'id':'job','email':'a@example.com','sender':'','subject':'','expires':time.time()+60}
        with patch('outlook_conectado.OutlookReader',return_value=reader), patch('automation.available_browsers',return_value=['Edge']), patch('outlook_conectado.SpecialPages') as special, patch('outlook_conectado.read_json',return_value={'at':time.time()}), patch('outlook_conectado.close_driver') as close:
            special.return_value.handle.return_value=None
            thread=threading.Thread(target=worker.process,args=(request,))
            thread.start()
            try:
                self.assertTrue(waiting.wait(2))
                self.assertTrue(thread.is_alive())
                statuses=[call.args[1] for call in worker.bridge.reply.call_args_list]
                self.assertIn('reader_error' if failure else 'code',statuses)
                worker.open_account.assert_called_once()
                close.assert_not_called()
            finally:
                worker.job_cancel.set();thread.join(2)
            self.assertFalse(thread.is_alive())
            close.assert_called_once_with(driver)
    def test_reader_failure_keeps_browser_until_stop(self):self.exercise(True)
    def test_code_delivery_keeps_browser_until_imss_finishes(self):self.exercise(False)
    def test_only_one_browser_attempt(self):
        worker=OutlookWorker()
        with patch('outlook_conectado.open_inbox') as login:
            worker.open_account('account',['Edge','Chrome'],lambda:False,Mock())
            self.assertEqual(login.call_args.args[1],'Edge')
            self.assertFalse(login.call_args.kwargs['close_on_error'])
            self.assertTrue(callable(login.call_args.kwargs['on_driver']))

if __name__=='__main__':unittest.main()
