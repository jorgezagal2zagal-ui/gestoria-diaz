import sys
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from outlook_conectado import OutlookWorker
from automation import PasswordUnavailable, AccountBrowsersExhausted, LoginFailure, RateLimited, SkipRequested, VerificationRequired, password_unavailable
import test_coordination_v62 as coordination
import test_login_v64 as login_fixture

class RetryTests(unittest.TestCase):
    def test_exact_spanish_message_is_recognized(self):
        self.assertTrue(password_unavailable('El inicio de sesión con contraseña no está disponible. Pruebe con otro método.'))
    def run_opener(self,errors,cancelled=lambda:False):
        worker=OutlookWorker();drivers=[];calls=[]
        def opening(account,browser,cancel,report,**kwargs):
            driver=Mock();drivers.append(driver);calls.append((account,browser));kwargs['on_driver'](driver)
            result=errors[len(calls)-1]
            if isinstance(result,Exception):raise result
            return driver
        return worker,drivers,calls,opening
    def test_first_password_error_second_success_same_account(self):
        worker,drivers,calls,opening=self.run_opener([PasswordUnavailable(),None])
        with patch('outlook_conectado.open_inbox',side_effect=opening):
            result=worker.open_account('SAME_ACCOUNT',['chrome','edge','firefox'],lambda:False,Mock())
        self.assertEqual(calls,[('SAME_ACCOUNT','chrome'),('SAME_ACCOUNT','edge')])
        drivers[0].quit.assert_called_once();drivers[1].quit.assert_not_called();self.assertIs(result,drivers[1])
    def test_second_failure_skips_without_third_browser(self):
        worker,drivers,calls,opening=self.run_opener([PasswordUnavailable(),LoginFailure()])
        with patch('outlook_conectado.open_inbox',side_effect=opening),self.assertRaises(AccountBrowsersExhausted):
            worker.open_account('account',['chrome','edge','firefox'],lambda:False,Mock())
        self.assertEqual(len(calls),2)
        for driver in drivers:driver.quit.assert_called_once()
    def test_other_first_failure_keeps_window_without_retry(self):
        worker,drivers,calls,opening=self.run_opener([LoginFailure()])
        with patch('outlook_conectado.open_inbox',side_effect=opening),self.assertRaises(LoginFailure):
            worker.open_account('account',['chrome','edge'],lambda:False,Mock())
        self.assertEqual(len(calls),1);drivers[0].quit.assert_not_called()
    def test_throttle_on_second_does_not_skip_or_try_third(self):
        worker,drivers,calls,opening=self.run_opener([PasswordUnavailable(),RateLimited()])
        with patch('outlook_conectado.open_inbox',side_effect=opening),self.assertRaises(RateLimited):
            worker.open_account('account',['chrome','edge','firefox'],lambda:False,Mock())
        self.assertEqual(len(calls),2);drivers[1].quit.assert_not_called()
    def test_second_verification_skips_without_interacting(self):
        worker,drivers,calls,opening=self.run_opener([PasswordUnavailable(),VerificationRequired()])
        with patch('outlook_conectado.open_inbox',side_effect=opening),self.assertRaises(AccountBrowsersExhausted):
            worker.open_account('account',['chrome','edge'],lambda:False,Mock())
        self.assertEqual(len(calls),2);drivers[1].quit.assert_called_once()
    def test_only_one_installed_browser_does_not_repeat_it(self):
        worker,drivers,calls,opening=self.run_opener([PasswordUnavailable()])
        with patch('outlook_conectado.open_inbox',side_effect=opening),self.assertRaises(AccountBrowsersExhausted):
            worker.open_account('account',['chrome','chrome'],lambda:False,Mock())
        self.assertEqual(len(calls),1)
    def test_skip_starts_next_account_with_same_curp_before_any_imss_submission(self):
        harness=coordination.CoordinationTests('test_success_uses_one_request');harness.setUp();self.addCleanup(harness.doCleanups)
        c=harness.setup_connection([{'status':'account_skipped'},{'status':'ready'},{'status':'code','code':'204655'}])
        harness.run_connection(c)
        self.assertEqual(c.last_result.status,'completada')
        self.assertEqual(c.app.consultas,[('CURP_PRUEBA','b@example.com','INSTANCIA_1')])
        self.assertEqual(c.bridge.create.call_count,2)

class PasswordErrorDriver(login_fixture.AuthDriver):
    def route(self,route):
        if route.request.url=='https://login.live.com/unknown':
            route.fulfill(status=200,content_type='text/html',body='<meta charset="utf-8"><p>El inicio de sesión con contraseña no está disponible. Pruebe con otro método.</p>')
        else:super().route(route)

class BrowserRetryLocalTests(unittest.TestCase):
    def test_real_login_function_recognizes_error_and_uses_second_browser(self):
        from automation import open_inbox
        worker=OutlookWorker();drivers=[];names=[]
        def local_open(account,browser,cancel,report,**kwargs):
            names.append(browser)
            driver=PasswordErrorDriver(portal=(browser=='edge'));drivers.append(driver)
            return open_inbox(account,browser,cancel,report,driver_factory=lambda name:driver,timeout=5,stage_timeout=2,on_driver=kwargs['on_driver'],close_on_error=kwargs['close_on_error'])
        try:
            with patch('outlook_conectado.open_inbox',side_effect=local_open):
                result=worker.open_account(SimpleNamespace(address='fixture@example.com',password='fixture'),['chrome','edge'],lambda:False,Mock())
            self.assertEqual(names,['chrome','edge']);self.assertTrue(drivers[0].closed)
            self.assertIs(result,drivers[1]);self.assertFalse(drivers[1].closed)
            self.assertEqual(result.current_url,'https://outlook.live.com/mail/0/inbox')
        finally:
            for driver in drivers:driver.quit()

if __name__=='__main__':unittest.main()
