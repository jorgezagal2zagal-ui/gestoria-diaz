import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from conexion.parallel import JobEngine
from conexion.unified import OutlookSection
from outlook_conectado import OutlookWorker
from automation import LoginFailure
import test_coordination_v62 as coordination

class SelectedApp:
    __module__='selected_fixture'
    def work(self,path,**kwargs):
        self.started.extend(self.nombres)
        for name in self.nombres:self.devices[name]={'running':True,'android':True,'index':name}
        return True

class RestoreTests(unittest.TestCase):
    def test_starts_all_three_chosen_instances_without_manual_opening(self):
        app=SelectedApp();app.started=[];app.devices={};app.emit=Mock();app.usados_sesion=set()
        app.conexion=SimpleNamespace(bridge=SimpleNamespace(excluded_emails=lambda:set()))
        engine=JobEngine(app,Mock());engine.snapshot={'path':'console','selected_instances':('ONE','TWO','THREE')}
        with patch.dict(sys.modules,{'selected_fixture':SimpleNamespace(listar=lambda path:app.devices)}):
            engine.start_selected_instances();engine.start_selected_instances()
        self.assertEqual(app.started,['ONE','TWO','THREE'])
    def test_already_open_chosen_instances_are_not_restarted(self):
        app=SelectedApp();app.started=[];app.devices={'ONE':{'running':True}};app.emit=Mock();app.usados_sesion=set()
        app.conexion=SimpleNamespace(bridge=SimpleNamespace(excluded_emails=lambda:set()))
        engine=JobEngine(app,Mock());engine.snapshot={'path':'console','selected_instances':('ONE',)}
        with patch.dict(sys.modules,{'selected_fixture':SimpleNamespace(listar=lambda path:app.devices)}):engine.start_selected_instances()
        self.assertEqual(app.started,[])
    def test_original_ldplayer_work_launches_exactly_the_chosen_three(self):
        import gestoria_5_instancias as imss
        app=imss.App.__new__(imss.App)
        app.nombres=('GESTORIA_DIAZ_001','GESTORIA_DIAZ_002','GESTORIA_DIAZ_003')
        app.emit=Mock();app.estado=Mock();app.events=Mock()
        devices={name:{'index':str(i),'running':False,'android':False} for i,name in enumerate(app.nombres,1)}
        def run(path,command,*args,**kwargs):
            if command=='launch':
                index=args[1]
                for info in devices.values():
                    if info['index']==index:info.update(running=True,android=True)
            return ''
        with patch.object(imss,'reparar',side_effect=lambda *args:devices), patch.object(imss,'run',side_effect=run) as commands, patch.object(imss,'celular'), patch.object(imss,'esperar_instancias',side_effect=lambda *args,**kwargs:devices):
            self.assertTrue(app.work('console',notify=False,wait_boot=False))
        launches=[call.args for call in commands.call_args_list if call.args[1]=='launch']
        self.assertEqual(launches,[('console','launch','--index','1'),('console','launch','--index','2'),('console','launch','--index','3')])

    def test_manual_open_failure_retains_same_window(self):
        section=OutlookSection.__new__(OutlookSection)
        section.shutdown=threading.Event();section.job_cancel=threading.Event()
        section.mailbox_opening=threading.Event();section.mailbox_opening.set()
        section.warm_driver=None;section.warm_email=None;section.status=Mock();section.bridge=Mock()
        section._post=lambda fn:fn();section._record_result=Mock();section._account_status=Mock()
        driver=Mock()
        def fail(*args):
            section._opening_driver=driver
            raise LoginFailure('fixture')
        section.open_account=fail
        with patch('automation.available_browsers',return_value=['Edge']):
            result=section.prepare_mailbox(SimpleNamespace(address='test@example.com'))
        self.assertEqual(result,'review');self.assertIs(section.warm_driver,driver)
        driver.quit.assert_not_called()
        section.discard_mailbox();driver.quit.assert_called_once()
    def test_worker_login_failure_before_return_keeps_window_until_stop(self):
        worker=OutlookWorker();worker.accounts=[SimpleNamespace(address='test@example.com')]
        worker.shutdown=threading.Event();worker.job_cancel=threading.Event();worker.accepting=True
        worker.bridge=Mock();worker.bridge.cancelled.return_value=False;worker.bridge.response.return_value={'status':'reader_error'}
        worker._post=lambda fn:fn();worker.manage_buttons=[]
        for name in ('start_button','stop_button','skip_button','status'):setattr(worker,name,Mock())
        worker._record_result=Mock();worker._account_status=Mock();driver=Mock();review=threading.Event()
        worker.bridge.reply.side_effect=lambda key,status,**kw:review.set() if status=='reader_error' else None
        def fail(*args):worker._opening_driver=driver;raise LoginFailure('fixture')
        worker.open_account=fail
        with patch('automation.available_browsers',return_value=['Edge']):
            thread=threading.Thread(target=worker.process,args=({'id':'job','email':'test@example.com','expires':time.time()+60},));thread.start()
            try:
                self.assertTrue(review.wait(2));self.assertTrue(thread.is_alive());driver.quit.assert_not_called()
            finally:worker.job_cancel.set();thread.join(2)
        self.assertFalse(thread.is_alive());driver.quit.assert_called_once()
    def test_android_preparation_failure_keeps_job_and_browser_reserved(self):
        harness=coordination.CoordinationTests('test_success_uses_one_request');harness.setUp();self.addCleanup(harness.doCleanups)
        c=harness.setup_connection([{'status':'ready'}]);c.preparation=lambda:False
        thread=threading.Thread(target=harness.run_connection,args=(c,));thread.start()
        try:
            self.assertTrue(harness.entered.wait(2));c.bridge.finish.assert_not_called()
            self.assertEqual(c.bridge.create.call_count,1)
        finally:c.cancel.set();thread.join(2)
        self.assertFalse(thread.is_alive());self.assertEqual(c.bridge.finish.call_count,1)

if __name__=='__main__':unittest.main()
