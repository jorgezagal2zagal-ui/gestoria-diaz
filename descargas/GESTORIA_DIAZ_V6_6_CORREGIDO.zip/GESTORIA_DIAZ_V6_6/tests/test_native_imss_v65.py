"""Run the real IMSS form routine against an Android XML/ADB simulator."""
import sys
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from xml.sax.saxutils import escape
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import gestoria_5_instancias as imss
from outlook_conectado import OutlookWorker

class Android:
    def __init__(self,legacy=False):
        self.legacy=legacy;self.curp='Ingresa CURP';self.email='Correo electrónico'
        self.focus=None;self.accepted=False;self.submitted=False;self.calls=[]
    def xml(self):
        def node(text,cls,bounds,rid='',enabled=True,**attrs):
            vals={'text':text,'class':cls,'bounds':bounds,'resource-id':rid,'enabled':str(enabled).lower(),'visible-to-user':'true',**attrs}
            return '<node '+ ' '.join(f'{k}="{escape(str(v), {chr(34): "&quot;"})}"' for k,v in vals.items())+' />'
        if self.submitted:
            return '<hierarchy>'+node('Código de validación','android.widget.TextView','[0,0][720,200]')+'</hierarchy>'
        prefix='st.android.imsspublico:id/' if self.legacy else ''
        return '<hierarchy>'+''.join([
            node('Inicia sesión','android.widget.TextView','[0,0][720,150]'),
            node(self.curp,'android.widget.EditText','[20,180][700,260]',prefix+'txtCURP' if self.legacy else ''),
            node(self.email,'android.widget.EditText','[20,280][700,360]',prefix+'txtCorreo' if self.legacy else ''),
            node('He leído y acepto el Aviso de Privacidad','android.widget.CheckBox','[20,400][680,460]',checkable='true',checked=str(self.accepted).lower()),
            node('INICIAR SESIÓN','android.widget.Button','[20,600][700,700]',prefix+'btnIniciar' if self.legacy else '',self.accepted),
        ])+'</hierarchy>'
    def adb(self,path,idx,*args,**kwargs):
        self.calls.append(args)
        if args==('shell','echo','OK'):return 'OK'
        if args[:3]==('shell','dumpsys','window'):return 'new Android format without keyguard flags'
        if args==('shell','dumpsys window | grep mCurrentFocus'):return imss.PACKAGE
        if args[:3]==('shell','cat','/sdcard/u.xml'):return self.xml()
        if args[:3]==('shell','input','tap'):
            y=int(args[4])
            if y==220:self.focus='curp'
            elif y==320:self.focus='email'
            elif y==430:self.accepted=True
            elif y==650 and self.accepted:self.submitted=True
        if args[:3]==('shell','input','text'):setattr(self,self.focus,args[3])
        return ''

class NativeTests(unittest.TestCase):
    def app(self):
        app=imss.App.__new__(imss.App);app.root=SimpleNamespace(after=lambda delay,fn:fn())
        app.btn_consulta=Mock();app.btn_codigo=Mock();app.events=Mock();app.emit=Mock()
        app.refrescar_correos=Mock();app.registrar_correo=Mock();app.pendiente=None;app.fast_mode=True
        app.conexion=SimpleNamespace(active=True,cancel=threading.Event(),state=Mock())
        return app
    def run_form(self,legacy):
        backend=Android(legacy);app=self.app()
        with patch.object(imss,'adb',side_effect=backend.adb),patch.object(imss,'listar',return_value={'INSTANCE':{'android':True,'index':'0'}}),patch.object(imss,'interaction_pause'),patch.object(imss.time,'sleep'):
            app._consulta('console','AAAA010101HDFBBB01','fixture@example.com','INSTANCE','semanas')
        self.assertTrue(backend.submitted)
        self.assertEqual((backend.curp,backend.email),('AAAA010101HDFBBB01','fixture@example.com'))
        self.assertEqual(app.pendiente,('console','0','INSTANCE','AAAA010101HDFBBB01','fixture@example.com','semanas'))
        self.assertIn(('shell','input','tap','350','430'),backend.calls)
        self.assertNotIn(('shell','input','tap','75','504'),backend.calls)
    def test_real_form_fills_and_requests_code_without_legacy_ids(self):self.run_form(False)
    def test_real_form_keeps_legacy_id_support(self):self.run_form(True)
    def test_visible_login_form_overcomes_unknown_keyguard_format(self):
        backend=Android();app=self.app();app.nombres=('INSTANCE',);app.preparando=threading.Event();app.abrir_imss=Mock()
        with patch.object(imss,'adb',side_effect=backend.adb),patch.object(imss,'listar',return_value={'INSTANCE':{'android':True,'running':True,'index':'0'}}):
            self.assertTrue(app.preparar_solicitud('console','INSTANCE',lambda:False,lambda seconds:False))
        app.abrir_imss.assert_not_called()
    def test_ambiguous_editable_fields_are_not_guessed(self):
        backend=Android()
        with patch.object(imss,'adb',side_effect=backend.adb):nodes=imss.pantalla('console','0')
        nodes.append(dict(nodes[1]))
        self.assertIsNone(imss.buscar(nodes,'txtCURP'))
    def test_non_login_screen_is_not_treated_as_form(self):
        backend=Android()
        with patch.object(imss,'adb',side_effect=backend.adb):nodes=imss.pantalla('console','0')
        nodes=[n for n in nodes if n['valor'] not in ('Inicia sesión','INICIAR SESIÓN')]
        self.assertFalse(imss.formulario_inicio(nodes))
    def test_outlook_does_not_scan_before_imss_requests_code(self):
        worker=OutlookWorker();worker.accounts=[SimpleNamespace(address='fixture@example.com')]
        worker.shutdown=threading.Event();worker.job_cancel=threading.Event();worker.accepting=True
        worker.bridge=Mock();worker.bridge.job.return_value=Path('/tmp/fixture_job');worker.bridge.cancelled.return_value=False;worker.bridge.response.return_value={'status':'code'}
        worker._post=lambda fn:fn();worker.manage_buttons=[]
        for name in ('start_button','stop_button','skip_button','status'):setattr(worker,name,Mock())
        worker._record_result=Mock();worker._account_status=Mock();worker.open_account=Mock(return_value=Mock())
        reader=Mock();reader.last_diagnostic='fixture';reader.scan.return_value='204655';waiting=threading.Event();ready=threading.Event();delivered=threading.Event()
        worker.bridge.reply.side_effect=lambda key,status,**kw: ready.set() if status=='ready' else delivered.set() if status=='code' else None
        def read(path):return {'at':time.time()} if str(path).endswith('started.json') or waiting.is_set() else None
        with patch('outlook_conectado.OutlookReader',return_value=reader),patch('outlook_conectado.read_json',side_effect=read),patch('automation.available_browsers',return_value=['local']),patch('outlook_conectado.SpecialPages') as special:
            special.return_value.handle.return_value=None
            thread=threading.Thread(target=worker.process,args=({'id':'job','email':'fixture@example.com','sender':'','subject':'','expires':time.time()+60},));thread.start()
            try:
                self.assertTrue(ready.wait(2));self.assertFalse(delivered.wait(.25));reader.scan.assert_not_called()
                waiting.set();self.assertTrue(delivered.wait(2));reader.scan.assert_called()
            finally:worker.job_cancel.set();thread.join(2)
        self.assertFalse(thread.is_alive())


class NativeBrowserFlowTests(unittest.TestCase):
    def test_real_form_routine_then_browser_reader_in_same_request(self):
        import tempfile
        from conexion.batch import BatchStore, QueueInput
        from conexion.bridge import Bridge
        from conexion.parallel import JobEngine, ConcurrentRunner
        import test_browser_flow_v63 as browser_flow
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        backend=Android();submitted=threading.Event();events=[];codes=[]
        store=BatchStore(tmp.name);store.import_items([QueueInput('AAAA010101HDFBBB01','semanas')])
        app=imss.App.__new__(imss.App)
        app.usados_sesion=set();app.emit=Mock();app.estado=Mock();app.registrar_correo=Mock();app.foto=Mock()
        for attr in ('arranque','enviados','bloqueada','sesion','ultimo_abrir','intentos_pin'):setattr(app,attr,{})
        app.conexion=SimpleNamespace(bridge=Bridge(Path(tmp.name)/'bridge'),history=None,batch=SimpleNamespace(store=store))
        app.outlook=SimpleNamespace(warm_email='',_record_result=Mock())
        engine=JobEngine(app,Mock());engine.snapshot={'path':'console','timeout':60,'accounts':(SimpleNamespace(address='fixture@example.com'),)}
        def adb(*args,**kwargs):
            previous=backend.submitted;result=backend.adb(*args,**kwargs)
            if not previous and backend.submitted:
                events.append('imss_requested_code');submitted.set()
            return result
        def code(worker,value,*pending):
            codes.append((value,pending[2],pending[3],pending[4]));worker.resultado_tramite=True
        def opener(worker,*args):return browser_flow.LocalDriver(submitted,events)
        runner=ConcurrentRunner(store,engine.execute,can_dispatch=engine.has_mailboxes);runner.capacity=1
        with patch.object(imss,'adb',side_effect=adb), patch.object(imss,'listar',return_value={'INSTANCE':{'running':True,'android':True,'index':'0'}}),patch.object(imss,'interaction_pause'),patch.object(imss,'correos_usados',return_value=set()),patch.object(imss.App,'_codigo',new=code),patch('outlook_conectado.OutlookWorker.open_account',new=opener),patch('automation.available_browsers',return_value=['fixture']),patch('outlook_conectado.SpecialPages') as special:
            special.return_value.handle.return_value=None
            runner.start(engine.open_idle_instances);runner.thread.join(12)
            if runner.running:
                runner.stop();engine.cancel();runner.thread.join(3)
                self.fail('The native IMSS to Outlook handoff did not complete: '+repr(app.emit.call_args_list))
        self.assertEqual(store.counts()['completada'],1)
        self.assertEqual((backend.curp,backend.email),('AAAA010101HDFBBB01','fixture@example.com'))
        self.assertEqual(codes,[('204655','INSTANCE','AAAA010101HDFBBB01','fixture@example.com')])
        self.assertEqual(events,['browser_opened','imss_requested_code','browser_closed'])

if __name__=='__main__':unittest.main()
