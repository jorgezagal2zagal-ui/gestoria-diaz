"""Exercise the real login function against local Chromium pages, no Microsoft traffic."""
import sys
import shutil
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from outlook_conectado import OutlookWorker
from automation import open_inbox, LoginFailure
from test_browser_flow_v63 import BrowserElement

class AuthElement(BrowserElement):
    def is_enabled(self):return self.locator.is_enabled()
    def clear(self):self.locator.fill('')
    def send_keys(self,value):self.locator.fill(value)

class AuthDriver:
    def __init__(self,portal=True):
        from playwright.sync_api import sync_playwright
        self.pw=sync_playwright().start()
        self.browser=self.pw.chromium.launch(executable_path=shutil.which('chromium') or shutil.which('chrome'),args=['--no-sandbox'])
        self.page=self.browser.new_page();self.closed=False;self.portal=portal
        self.page.route('**/*',self.route)
    def route(self,route):
        url=route.request.url
        if url=='https://login.live.com/':
            html='<input type="email"><button type="submit" onclick="location.href=\'/password\'">Next</button>'
        elif '/password' in url:
            target='https://account.microsoft.com/' if self.portal else 'https://login.live.com/unknown'
            html=f'<input type="password"><button type="submit" onclick="location.href=\'{target}\'">Sign in</button>'
        elif 'outlook.live.com' in url:html='<div role="main">Inbox</div>'
        else:html='<main>Account portal</main>'
        route.fulfill(status=200,content_type='text/html',body=html)
    @property
    def current_url(self):return self.page.url
    def get(self,url):self.page.goto(url)
    def find_elements(self,by,selector):
        loc=self.page.locator('xpath='+selector if by=='xpath' else selector)
        return [AuthElement(x) for x in loc.all()]
    def quit(self):
        if not self.closed:
            self.closed=True;self.browser.close();self.pw.stop()

class LoginTests(unittest.TestCase):
    def test_account_portal_goes_to_outlook_in_same_browser(self):
        driver=AuthDriver();self.addCleanup(driver.quit)
        result=open_inbox(SimpleNamespace(address='test@example.com',password='fixture'),'local',lambda:False,Mock(),driver_factory=lambda name:driver,timeout=5,stage_timeout=2)
        self.assertIs(result,driver)
        self.assertEqual(driver.current_url,'https://outlook.live.com/mail/0/inbox')
        self.assertFalse(driver.closed)
    def test_unrecognized_screen_after_password_does_not_close_owned_browser(self):
        driver=AuthDriver(portal=False);self.addCleanup(driver.quit);owned=[]
        with self.assertRaises(LoginFailure) as error:
            open_inbox(SimpleNamespace(address='test@example.com',password='fixture'),'local',lambda:False,Mock(),driver_factory=lambda name:driver,timeout=5,stage_timeout=.8,on_driver=owned.append,close_on_error=False)
        self.assertEqual(error.exception.stage,'confirmación de acceso')
        self.assertEqual(owned,[driver]);self.assertFalse(driver.closed)
        self.assertEqual(driver.current_url,'https://login.live.com/unknown')
    def test_default_login_callers_still_close_on_error(self):
        driver=AuthDriver(portal=False)
        with self.assertRaises(LoginFailure):
            open_inbox(SimpleNamespace(address='test@example.com',password='fixture'),'local',lambda:False,Mock(),driver_factory=lambda name:driver,timeout=5,stage_timeout=.8)
        self.assertTrue(driver.closed)

if __name__=='__main__':unittest.main()
