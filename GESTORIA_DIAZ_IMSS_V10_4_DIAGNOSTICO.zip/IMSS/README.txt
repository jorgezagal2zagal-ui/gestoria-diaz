# IMSS V10.4: diagnóstico y correcciones verificadas localmente

Lee CAMBIO_V10_4.md. Si el HONOR vuelve a atascarse, usa COPIAR DIAGNÓSTICO SIN
DATOS y pega el resultado en el chat. No utilices ENVIAR PIN AHORA para el aviso
de cambio de dispositivo. El clic real y el trámite completo aún no están validados.
Las notas de versiones anteriores quedan como historial.

IMSS V10.3: aceptación automática de SÍ, QUIERO HACER EL CAMBIO.
Lee CAMBIO_V10_3.md. Ejecuta ABRIR_BOT.bat.
Marca la autorización automática para ESTE trámite antes de iniciar o mientras espera en el aviso.
No necesitas pulsar además AUTORIZAR CAMBIO. El siguiente folio necesita autorización propia.
122 pruebas locales; pendiente clic real en HONOR. Sin PIN ni datos de las capturas.
