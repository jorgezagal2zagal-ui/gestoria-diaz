"""Read-only phone evidence. Whitelisted booleans/numbers/enums; no node strings."""
import re
from adb_imss import ADB, DeviceError, IMSSFlow, norm


def technical_snapshot(adb, flow=None, running=False):
    report={'schema':1,'version':'10.5','running':bool(running),
            'flow_present':flow is not None,
            'automatic_consent_pending':bool(flow is not None and flow.auto_transfer_approved),
            'transfer_attempted':bool(flow is not None and flow.transfer_attempted),
            'skip_close_attempted':bool(flow is not None and flow.skip_close_attempted)}
    try:nodes=adb.hierarchy()
    except Exception as error:
        report.update(read='unavailable',error='device_error' if isinstance(error,DeviceError) else 'unexpected_error')
        return report
    probe=IMSSFlow(adb,'','',lambda message:None)
    yes=probe.transfer_button(nodes) if probe.device_transfer_dialog(nodes) else None
    report.update(read='ok',node_count=len(nodes),identity_labels=bool(ADB.credential_labels(nodes)),
                  transfer_dialog=probe.device_transfer_dialog(nodes),unique_yes_control=yes is not None,
                  device_update_failure=probe.device_update_failure(nodes))
    def flags(node):
        label=' '.join(re.sub('[^a-z0-9 ]',' ',norm(node.text or node.desc)).split())
        return {'bounds':list(node.bounds),'clickable':bool(node.clickable),'enabled':bool(node.enabled),
                'button_class':'button' in norm(node.clazz),
                'standard_positive_id':node.rid.lower().rsplit('/',1)[-1] in ('button1','positive_button','md_buttondefaultpositive'),
                'public_yes':label in ('si','si quiero hacer el cambio','si quiero cambiar de dispositivo','si deseo vincular','confirmar cambio','vincular este dispositivo'),
                'public_no':label in ('no','cancelar','cancel','rechazar')}
    controls=[]
    for node in nodes:
        item=flags(node)
        if item['button_class'] or item['standard_positive_id'] or item['public_yes'] or item['public_no']:
            controls.append(item)
    report['controls']=controls[:30]
    report['controls_truncated']=len(controls)>30
    if yes is not None:report['target']=flags(yes)
    return report
