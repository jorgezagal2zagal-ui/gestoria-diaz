"""Verified HTTPS transport; validate archive and install without partial overwrite."""
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
from urllib.request import Request, urlopen
from zipfile import ZipFile
import io, shutil, stat

URL='https://dl.google.com/android/repository/platform-tools-latest-windows.zip'

def install_archive(data,parent):
    parent=Path(parent);parent.mkdir(parents=True,exist_ok=True)
    target=parent/'platform-tools'
    if target.exists():raise ValueError('La carpeta ADB ya existe; respáldala antes de reemplazarla.')
    with ZipFile(io.BytesIO(data)) as archive:
        files=archive.infolist()
        if len(files)>2000 or sum(f.file_size for f in files)>250_000_000:
            raise ValueError('El paquete excede el tamaño permitido.')
        names=set()
        for info in files:
            path=PurePosixPath(info.filename.replace('\\','/'))
            if (path.is_absolute() or '..' in path.parts or not path.parts or path.parts[0]!='platform-tools'
                    or any(':' in part for part in path.parts) or stat.S_ISLNK(info.external_attr>>16)):
                raise ValueError('Ruta no permitida en el paquete ADB.')
            normalized=str(path).casefold()
            if normalized in names:raise ValueError('Archivo duplicado en el paquete ADB.')
            names.add(normalized)
        if archive.testzip() is not None:raise ValueError('El paquete ADB está corrupto.')
        if 'platform-tools/adb.exe' not in names:raise ValueError('No se encontró adb.exe en el paquete oficial.')
        with TemporaryDirectory(prefix='adb-stage-',dir=parent) as temporary:
            stage=Path(temporary)
            for info in files:
                dest=stage/Path(*PurePosixPath(info.filename.replace('\\','/')).parts)
                if info.is_dir():dest.mkdir(parents=True,exist_ok=True);continue
                dest.parent.mkdir(parents=True,exist_ok=True)
                with archive.open(info) as source,dest.open('wb') as output:shutil.copyfileobj(source,output)
            (stage/'platform-tools').rename(target)
    return target

def download_and_install(parent):
    request=Request(URL,headers={'User-Agent':'Gestoria-Diaz-IMSS/10'})
    # urllib preserves certificate verification and system proxy/trust configuration.
    with urlopen(request,timeout=50) as response:data=response.read(75_000_001)
    if len(data)>75_000_000:raise ValueError('La descarga excede el límite permitido.')
    return install_archive(data,parent)
