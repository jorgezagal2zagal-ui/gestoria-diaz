"""Local reproducible checks; isolated synthetic data, no real accounts or phone."""
import os, subprocess, sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
commands=[['-m','unittest','discover','-p','tests*.py','-v']]

with tempfile.TemporaryDirectory() as temporary:
    environment=dict(os.environ,LOCALAPPDATA=temporary)
    for args in commands:
        result=subprocess.run([sys.executable,*args],cwd=root,env=environment)
        if result.returncode:sys.exit(result.returncode)
print('LOCAL CHECKS PASSED. Real Windows/HONOR/Microsoft integration remains unverified.')
