"""Local, user-scoped DPAPI storage for the optional phone PIN on Windows.
Never puts secrets in the distributable ZIP, logs, JSON, or source code.
"""
from __future__ import annotations
import ctypes
import os
import sys
from ctypes import wintypes
from pathlib import Path

class VaultError(RuntimeError):
    pass

class DATA_BLOB(ctypes.Structure):
    _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_ubyte))]


def _crypt(data: bytes, encrypt: bool) -> bytes:
    if sys.platform != 'win32':
        raise VaultError('El guardado cifrado requiere Windows.')
    crypt32 = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    src = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    incoming = DATA_BLOB(len(data), ctypes.cast(src, ctypes.POINTER(ctypes.c_ubyte)))
    outgoing = DATA_BLOB()
    if encrypt:
        func = crypt32.CryptProtectData
        func.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.c_wchar_p, ctypes.POINTER(DATA_BLOB),
                         ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
        args = [ctypes.byref(incoming), 'Gestoria Diaz PIN', None, None, None, 0x1, ctypes.byref(outgoing)]
    else:
        func = crypt32.CryptUnprotectData
        func.argtypes = [ctypes.POINTER(DATA_BLOB), ctypes.c_void_p, ctypes.POINTER(DATA_BLOB),
                         ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DATA_BLOB)]
        args = [ctypes.byref(incoming), None, None, None, None, 0x1, ctypes.byref(outgoing)]
    func.restype = wintypes.BOOL
    if not func(*args):
        raise VaultError('Windows no pudo ' + ('cifrar' if encrypt else 'descifrar') + ' el PIN (DPAPI).')
    try:
        return ctypes.string_at(outgoing.pbData, outgoing.cbData)
    finally:
        kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        kernel32.LocalFree(ctypes.cast(outgoing.pbData, ctypes.c_void_p))


def path() -> Path:
    if sys.platform != 'win32':
        raise VaultError('El guardado cifrado requiere Windows.')
    local = os.environ.get('LOCALAPPDATA')
    if not local:
        raise VaultError('Windows no indicó la carpeta privada del usuario.')
    return Path(local) / 'GestoriaDiaz' / 'IMSS' / 'pin.dpapi'


def save(pin: str) -> None:
    import re
    if not re.fullmatch(r'\d{4,12}', pin):
        raise VaultError('El PIN debe tener entre 4 y 12 números.')
    target = path()
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = _crypt(pin.encode('ascii'), encrypt=True)
    temp = target.with_suffix('.tmp')
    try:
        with temp.open('wb') as file:
            file.write(payload)
        os.replace(temp, target)
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass


def load() -> str | None:
    try:
        encrypted = path().read_bytes()
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise VaultError('No se pudo leer el PIN cifrado.') from exc
    try:
        pin = _crypt(encrypted, encrypt=False).decode('ascii')
    except (UnicodeError, ValueError) as exc:
        raise VaultError('El PIN cifrado está dañado o pertenece a otro usuario.') from exc
    import re
    if not re.fullmatch(r'\d{4,12}', pin):
        raise VaultError('El PIN descifrado no es válido.')
    return pin


def forget() -> None:
    try:
        path().unlink(missing_ok=True)
    except OSError as exc:
        raise VaultError('No se pudo eliminar el PIN guardado.') from exc
