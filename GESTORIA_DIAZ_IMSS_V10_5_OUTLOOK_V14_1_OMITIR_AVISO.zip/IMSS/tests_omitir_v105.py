"""Public IMSS message only; synthetic phone, encrypted SQLite and loopback API."""
import tempfile, threading, unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch, call
from adb_imss import ADB, IMSSFlow, Node
from panel import IMSSPanel
from mail_link import Session
from solicitudes import Requests
import enlace
import tests_arranque_v102 as startup
import tests_operacion as operation

CURP='AAAA000101HDFBBB01';EMAIL='synthetic@example.invalid'
MESSAGE='Por el momento, no se pudo realizar la actualización del dispositivo. Favor de intentar más tarde.'
def notice():
    return [Node(MESSAGE,'','','android.widget.TextView',(0,10,400,200)),
            Node('CERRAR','','android:id/button1','android.widget.Button',(220,210,390,270),True)]
def login():
    return [Node('Inicia sesión CURP correo electrónico Aviso de Privacidad','','','android.widget.TextView',(0,0,400,60)),
            Node('','','curp','android.widget.EditText',(0,70,400,110)),
            Node('','','correo','android.widget.EditText',(0,120,400,160))]

class CloseNotice(unittest.TestCase):
    def test_failure_is_closed_once_and_only_then_skipped_after_form_is_confirmed(self):
        adb=Mock();flow=IMSSFlow(adb,CURP,EMAIL,Mock())
        self.assertEqual(flow.step(notice()),'action')
        adb.tap_node.assert_called_once_with(notice()[-1])
        self.assertEqual(flow.step(login()),'skipped_device_update')
        self.assertEqual(flow.step(login()),'skipped_device_update')
        adb.tap_node.assert_called_once();adb.text.assert_not_called()
    def test_real_adb_command_targets_close_from_hierarchy_not_photo_coordinates(self):
        adb=ADB('synthetic-adb');adb.run=Mock(return_value='')
        flow=IMSSFlow(adb,CURP,EMAIL,Mock());flow.step(notice())
        adb.run.assert_called_once_with('shell','input','tap',305,240,timeout=12)
    def test_unknown_error_with_close_is_never_auto_closed(self):
        adb=Mock();flow=IMSSFlow(adb,CURP,EMAIL,Mock())
        nodes=notice();nodes[0].text='No se pudo enviar el código de seguridad'
        self.assertEqual(flow.step(nodes),'paused');adb.tap_node.assert_not_called()
    def test_disabled_or_ambiguous_close_is_not_tapped(self):
        for ambiguous in (False,True):
            adb=Mock();flow=IMSSFlow(adb,CURP,EMAIL,Mock());nodes=notice()
            if ambiguous:nodes.append(Node('Cerrar','','','android.widget.Button',(0,210,100,270),True))
            else:nodes[-1].enabled=False
            self.assertEqual(flow.step(nodes),'paused');adb.tap_node.assert_not_called()
    def test_persistent_dialog_pauses_without_repeated_tap(self):
        adb=Mock();flow=IMSSFlow(adb,CURP,EMAIL,Mock())
        with patch('adb_imss.time.monotonic',return_value=10):self.assertEqual(flow.step(notice()),'action')
        with patch('adb_imss.time.monotonic',return_value=11):self.assertEqual(flow.step(notice()),'retry')
        with patch('adb_imss.time.monotonic',return_value=20):self.assertEqual(flow.step(notice()),'paused')
        adb.tap_node.assert_called_once()
    def test_unknown_screen_after_close_never_advances_to_next_request(self):
        adb=Mock();flow=IMSSFlow(adb,CURP,EMAIL,Mock())
        flow.step(notice())
        with patch('adb_imss.time.monotonic',return_value=10**12):self.assertEqual(flow.step([]),'paused')
        adb.tap_node.assert_called_once()
    def test_failure_after_partial_tap_never_repeats_close(self):
        from adb_imss import DeviceError
        adb=Mock();adb.tap_node.side_effect=DeviceError('transport error')
        flow=IMSSFlow(adb,CURP,EMAIL,Mock())
        with self.assertRaises(DeviceError):flow.step(notice())
        with patch('adb_imss.time.monotonic',return_value=10**12):self.assertEqual(flow.step(notice()),'paused')
        adb.tap_node.assert_called_once()


class SkipQueueIntegration(unittest.TestCase):
    def store(self,directory):return Requests(operation.Protector(),Path(directory)/'jobs.db')
    def ready(self,store,jid=None):
        case=startup.StartupRegression('test_independent_mode_never_calls_outlook')
        f,_=case.panel(linked=False)
        f._jobs=lambda:store;f._current_job=jid
        f._refresh_jobs=lambda:store.list()
        f.queue_enabled=startup.Var(True);f._closed=False;f._next_queue_check=0
        return f
    def run_skip(self,f):
        tapped=[]
        f.adb.tap_node.side_effect=lambda node:tapped.append(node.text)
        f.adb.hierarchy.side_effect=lambda:login() if tapped else notice()
        with patch('panel.time.sleep'),patch('panel.record'):
            self.assertTrue(IMSSPanel.start(f))
        self.assertEqual(tapped,['CERRAR'])
        end=[c.args[1] for c in f.put.call_args_list if c.args[0]=='flow_end'][-1]
        return end
    def test_omission_preserves_folio_data_releases_phone_and_dispatches_next_immediately(self):
        with tempfile.TemporaryDirectory() as d:
            store=self.store(d);first=store.enqueue(CURP);second=store.enqueue('AAAA000102HDFBBB02')
            store.set(first,'ACTIVA',email=EMAIL);store.set(second,'PENDIENTE',email='next@example.invalid')
            f=self.ready(store,first)
            end=self.run_skip(f);self.assertEqual(end,(first,'skipped_device_update'))
            with patch('panel.record'):IMSSPanel._on_flow_end(f,*end)
            old=store.get(first)
            self.assertEqual(old['status'],'OMITIDA_DISPOSITIVO');self.assertEqual(old['curp'],CURP)
            self.assertEqual(old['email'],EMAIL);self.assertEqual(old['id'],first)
            self.assertNotIn(CURP.encode(),store.path.read_bytes())
            self.assertNotEqual(old['status'],'SOLICITUD_ENVIADA')
            f._prepare=Mock()
            IMSSPanel._queue_tick(f)
            f._prepare.assert_called_once_with('AAAA000102HDFBBB02','next@example.invalid',second)
            store.recover();self.assertEqual(store.get(first)['status'],'OMITIDA_DISPOSITIVO')
    def test_individual_request_gets_history_folio_and_is_not_deleted(self):
        with tempfile.TemporaryDirectory() as d:
            store=self.store(d);f=self.ready(store)
            end=self.run_skip(f)
            with patch('panel.record'):IMSSPanel._on_flow_end(f,*end)
            rows=store.list();self.assertEqual(len(rows),1)
            job=store.get(rows[0]['id']);self.assertEqual(job['curp'],CURP)
            self.assertEqual(job['email'],EMAIL);self.assertEqual(job['status'],'OMITIDA_DISPOSITIVO')
            self.assertEqual(f.curp.get(),CURP)
    def test_close_then_real_http_cancel_frees_outlook_for_next_folio_without_done(self):
        with tempfile.TemporaryDirectory() as d,patch.multiple(enlace,BASE=Path(d),KEYFILE=Path(d)/'key'):
            state=enlace.State();server=enlace.Server(state,port=0);server.start();self.addCleanup(server.close)
            client=enlace.Client(port=server.server.server_address[1]);session=Session(client,email=EMAIL)
            store=self.store(d);first=store.enqueue(CURP);f=self.ready(store,first)
            f.link_enabled.set(True)
            with patch('panel.Session',return_value=session):end=self.run_skip(f)
            self.assertEqual(end,(first,'skipped_device_update'))
            self.assertEqual(state.status()['status'],'CANCELADA')
            with patch('panel.record'):IMSSPanel._on_flow_end(f,*end)
            self.assertEqual(store.get(first)['link_id'],'')
            following=Session(client,email='next@example.invalid');following.prepare()
            self.assertEqual(state.status()['request_id'],following.request_id)
            self.assertEqual(state.status()['status'],'ESPERANDO_CODIGO')
    def test_unconfirmed_outlook_release_stops_queue_and_keeps_reservation_for_review(self):
        with tempfile.TemporaryDirectory() as d:
            store=self.store(d);first=store.enqueue(CURP);second=store.enqueue('AAAA000102HDFBBB02')
            f=self.ready(store,first);f.link_enabled.set(True)
            client=Mock();session=Session(client,email=EMAIL)
            client.begin.return_value={'email':EMAIL,'request_id':session.request_id,'status':'ESPERANDO_CODIGO'}
            client.status.side_effect=enlace.LinkError('offline')
            with patch('panel.Session',return_value=session):end=self.run_skip(f)
            self.assertEqual(end,(first,None))
            with patch('panel.record'):IMSSPanel._on_flow_end(f,*end)
            self.assertEqual(store.get(first)['status'],'REQUIERE_ATENCION')
            self.assertEqual(store.get(first)['link_id'],session.request_id)
            client.done.assert_not_called();f._prepare=Mock()
            IMSSPanel._queue_tick(f);f._prepare.assert_not_called()
            self.assertEqual(store.oldest_pending()[0],second)
    def test_disabled_queue_stays_disabled_after_omission(self):
        with tempfile.TemporaryDirectory() as d:
            store=self.store(d);f=self.ready(store);f.queue_enabled.set(False)
            end=self.run_skip(f)
            with patch('panel.record'):IMSSPanel._on_flow_end(f,*end)
            f._prepare=Mock();IMSSPanel._queue_tick(f);f._prepare.assert_not_called()
            self.assertFalse(f.queue_enabled.get())
    def test_omitted_folio_can_be_reviewed_explicitly_without_changing_curp(self):
        with tempfile.TemporaryDirectory() as d:
            store=self.store(d);jid=store.enqueue(CURP);store.set(jid,'OMITIDA_DISPOSITIVO',email=EMAIL)
            f=self.ready(store);f.running=False;f.queue_view=Mock();f.queue_view.selection.return_value=(jid,)
            f._release_job_link=Mock()
            with patch('panel.messagebox.askyesno',return_value=True):IMSSPanel.review_request(f)
            self.assertEqual(store.get(jid)['status'],'PENDIENTE')
            self.assertEqual(store.get(jid)['curp'],CURP)

class ScopedCancellation(unittest.TestCase):
    def test_another_folio_is_never_canceled(self):
        client=Mock();session=Session(client,email=EMAIL)
        client.status.return_value={'email':EMAIL,'request_id':'a'*32,'status':'ESPERANDO_CODIGO'}
        from mail_link import SessionInvalid
        with self.assertRaises(SessionInvalid):session.cancel()
        client.cancel.assert_not_called();client.done.assert_not_called()
    def test_cancel_is_not_reported_successful_until_server_confirms(self):
        client=Mock();session=Session(client,email=EMAIL)
        client.status.return_value={'email':EMAIL,'request_id':session.request_id,'status':'ESPERANDO_CODIGO'}
        from mail_link import SessionInvalid
        with self.assertRaises(SessionInvalid):session.cancel()
        client.cancel.assert_called_once_with(session.request_id);client.done.assert_not_called()
    def test_absent_reservation_needs_no_cancel_or_success_notification(self):
        client=Mock();session=Session(client,email=EMAIL);client.status.return_value={'status':'SIN_SOLICITUD'}
        session.cancel();client.cancel.assert_not_called();client.done.assert_not_called()

if __name__=='__main__':unittest.main()
