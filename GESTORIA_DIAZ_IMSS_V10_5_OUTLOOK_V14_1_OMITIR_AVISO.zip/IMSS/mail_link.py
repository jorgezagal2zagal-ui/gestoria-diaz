"""Optional IMSS client session. Folio/account binding; codes remain in memory only."""
import secrets, threading
from enlace import Client, LinkError

class SessionInvalid(LinkError):pass

class Session:
    def __init__(self,client=None,email='',request_id=None):
        self.client=client or Client()
        self.request_id=request_id or secrets.token_hex(16)
        self.email=email.strip().lower()
        self.prepared=False
        self.written=False
        self.acknowledged=False
        self.manual=False
        self.lock=threading.RLock()
    def prepare(self):
        self.prepared=False
        state=(self.client.begin(self.email,self.request_id) if self.email else
               self.client.reserve(self.request_id))
        self._validate(state)
        if state['status'] in ('CADUCADA','CANCELADA','SOLICITUD_IMSS_ENVIADA'):
            raise SessionInvalid('La sesión no está activa; requiere revisión del operador.')
        self.email=state['email']
        self.prepared=True
        return self.email
    def _validate(self,state):
        if state.get('request_id')!=self.request_id:raise SessionInvalid('El folio del enlace no coincide.')
        if not state.get('email') or (self.email and state['email'].casefold()!=self.email.casefold()):
            raise SessionInvalid('El correo del enlace no coincide.')
    def exchange(self,submit):
        """At most one phone submission, even when the acknowledgement is lost."""
        with self.lock:
            if self.manual:return False
            if self.written:
                if not self.acknowledged:
                    self.client.ack(self.request_id);self.acknowledged=True
                return True
            state=self.client.status(self.request_id);self._validate(state)
            if state['status'] in ('CADUCADA','CANCELADA'):raise SessionInvalid('El enlace caducó o fue cancelado; revisa antes de reintentar.')
            if state['status']!='CODIGO_DISPONIBLE':return False
            code=state.get('code')
            if not isinstance(code,str) or len(code)!=6 or not code.isascii() or not code.isdigit():
                raise SessionInvalid('Código recibido inválido.')
            # Reserve the single attempt before ADB: an exception may mean a partial write.
            self.written=True
            try:submit(code)
            except Exception:
                self.manual=True
                raise
            self.client.ack(self.request_id);self.acknowledged=True
            return True
    def mark_manual(self):
        with self.lock:self.manual=True
    def done(self):return self.client.done(self.request_id)
    def cancel(self):
        """Release only this request, verify cancellation, never report IMSS success."""
        with self.lock:
            state=self.client.status(self.request_id)
            if state.get('status')=='SIN_SOLICITUD':
                self.manual=True;return
            self._validate(state)
            self.client.cancel(self.request_id)
            after=self.client.status(self.request_id);self._validate(after)
            if after.get('status')!='CANCELADA':raise SessionInvalid('No se confirmó la liberación del enlace.')
            self.manual=True


def link_failure_message(error):
    """Fixed UI diagnostics: never display arbitrary remote exceptions or secrets."""
    from urllib.error import HTTPError, URLError
    if isinstance(error,SessionInvalid):
        return 'La reserva no coincide o ya no está activa; revisa el folio en Outlook.'
    cause=error.__cause__
    if isinstance(cause,HTTPError):
        if cause.code==401:return 'El enlace rechazó la clave local. Abre ambos bots con el mismo usuario de Windows.'
        if cause.code==404:return 'La versión Outlook no ofrece este enlace. Usa Outlook V14.'
        if cause.code>=500:return 'Outlook tuvo un error al preparar el enlace; revisa su diagnóstico local.'
    if isinstance(cause,(URLError,TimeoutError,OSError)):
        return 'Outlook no está abierto o el enlace local no responde. Abre Outlook V14 en esta misma PC.'
    text=str(error).casefold()
    if 'otra solicitud' in text or 'otro folio' in text:
        return 'Outlook conserva otro folio activo; revísalo antes de sustituir su reserva.'
    if 'automático desactivado' in text or 'ocupado' in text or 'no está disponible' in text:
        return 'Outlook está ocupado, en espera de seguridad, limitado o con el modo automático desactivado.'
    if 'cuenta nueva' in text or 'seleccionada' in text or 'contraseña cifrada' in text:
        return 'No hay una cuenta NUEVA seleccionada con contraseña cifrada en Outlook.'
    if isinstance(cause,(URLError,TimeoutError,OSError)) or isinstance(error,LinkError):
        return 'Outlook no está abierto o el enlace local no responde. Abre Outlook V14 en esta misma PC.'
    return 'No se pudo preparar el enlace local; revisa el diagnóstico técnico de Outlook e IMSS.'
