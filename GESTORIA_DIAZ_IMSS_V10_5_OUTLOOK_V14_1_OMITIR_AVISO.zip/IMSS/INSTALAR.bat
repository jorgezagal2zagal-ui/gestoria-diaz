@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (set "TASK_PY=python") else (set "TASK_PY=py -3")
%TASK_PY% -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 goto error
if not exist ".venv\Scripts\python.exe" %TASK_PY% -m venv .venv
if errorlevel 1 goto error
.venv\Scripts\python.exe -c "import tkinter"
if errorlevel 1 goto error
.venv\Scripts\python.exe validar.py
if errorlevel 1 goto error
echo Preparacion local terminada. Falta verificar la integracion real con tus dispositivos y cuentas.
pause
exit /b 0
:error
echo No se completo la preparacion. Revisa Python 3.10+, Tk e Internet.
pause
exit /b 1
