import unittest
from adb_imss import IMSSFlow, Node, DeviceError

class FakeADB:
    def __init__(self): self.clicked=[]
    def tap_node(self,node): self.clicked.append(node.text)

class TestCambio(unittest.TestCase):
    def test_explicit_one_time_consent(self):
        a=FakeADB(); f=IMSSFlow(a,'SAMP010101HDFXXX09','x@x.com',lambda x:None)
        n=[Node('Esta CURP ya está vinculada a otro dispositivo móvil. ¿Deseas hacer el cambio?','','','android.widget.TextView',(10,10,300,100)),
           Node('NO','','','android.widget.Button',(10,130,120,180),True),
           Node('SÍ, QUIERO HACER EL CAMBIO','','','android.widget.Button',(140,130,320,180),True)]
        self.assertEqual(f.step(n),'paused')
        self.assertEqual(a.clicked,[])
        with self.assertRaises(DeviceError):f.authorize_device_change(n)
        f.authorize_device_change(n,consent=True)
        self.assertEqual(a.clicked,['SÍ, QUIERO HACER EL CAMBIO'])
        self.assertEqual(f.step(n),'paused')
        f.last_action=None  # resuming does not grant another authorization
        with self.assertRaises(DeviceError):f.authorize_device_change(n,consent=True)
        self.assertEqual(len(a.clicked),1)
    def test_no_random_yes(self):
        a=FakeADB();f=IMSSFlow(a,'SAMP010101HDFXXX09','x@x.com',lambda x:None)
        n=[Node('¿Deseas borrar toda la información?','','','android.widget.TextView',(10,10,300,100)),
           Node('Sí, quiero hacer el cambio','','','android.widget.Button',(140,130,320,180),True)]
        f.step(n)
        with self.assertRaises(DeviceError):f.authorize_device_change(n,consent=True)
        self.assertEqual(a.clicked,[])

if __name__=='__main__': unittest.main()
