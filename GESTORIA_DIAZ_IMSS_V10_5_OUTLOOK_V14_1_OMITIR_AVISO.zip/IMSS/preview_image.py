"""Validate screenshot PNG framing before passing untrusted stdout into Tk."""
import struct,zlib
SIGNATURE=b'\x89PNG\r\n\x1a\n'

def dimensions(data):
    if not isinstance(data,bytes) or len(data)>32_000_000 or not data.startswith(SIGNATURE):
        raise ValueError('La captura no es un PNG válido.')
    offset=8;size=None;has_data=False
    while offset<len(data):
        if len(data)-offset<12:raise ValueError('Captura PNG incompleta.')
        length=struct.unpack('>I',data[offset:offset+4])[0]
        tag=data[offset+4:offset+8];end=offset+12+length
        if end>len(data):raise ValueError('Captura PNG incompleta.')
        payload=data[offset+8:offset+8+length]
        expected=struct.unpack('>I',data[offset+8+length:end])[0]
        if zlib.crc32(tag+payload)&0xffffffff!=expected:raise ValueError('Captura PNG corrupta.')
        if size is None:
            if tag!=b'IHDR' or length!=13:raise ValueError('Falta la cabecera de captura.')
            width,height=struct.unpack('>II',payload[:8])
            if not (0<width<=10000 and 0<height<=10000 and width*height<=40_000_000):
                raise ValueError('Tamaño de captura inválido.')
            size=(width,height)
        elif tag==b'IHDR':raise ValueError('Cabecera de captura duplicada.')
        if tag==b'IDAT':has_data=True
        if tag==b'IEND':
            if length or end!=len(data) or not has_data:raise ValueError('Final de captura inválido.')
            return size
        offset=end
    raise ValueError('Captura PNG incompleta.')
