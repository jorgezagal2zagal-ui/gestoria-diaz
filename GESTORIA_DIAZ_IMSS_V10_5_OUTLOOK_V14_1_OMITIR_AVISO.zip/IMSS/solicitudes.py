# -*- coding: utf-8 -*-
"""Solicitudes secuenciales. Datos CURP cifrados con DPAPI del usuario Windows."""
import sqlite3, secrets, re, os
from pathlib import Path
from datetime import datetime, timezone

CURP=re.compile(r'^[A-Z][AEIOUX][A-Z]{2}\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12][0-9]|3[01])[HM][A-Z]{5}[A-Z0-9]\d$')
STATES={'PENDIENTE','ACTIVA','ESPERANDO_CODIGO','ESPERANDO_PDF','PDF_REVISAR','PDF_VERIFICADO','REQUIERE_ATENCION','ERROR','CANCELADA','SOLICITUD_ENVIADA','OMITIDA_DISPOSITIVO'}

class Requests:
    def __init__(self,protector,db_path=None):
        self.protector=protector
        root=Path(os.environ.get('LOCALAPPDATA') or str(Path.home()))/'GestoriaDiaz'/'IMSSV10'
        self.path=Path(db_path) if db_path else root/'solicitudes.sqlite3'
        self.path.parent.mkdir(parents=True,exist_ok=True)
        with self._db() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS job (id TEXT PRIMARY KEY, curp BLOB NOT NULL,
                    email TEXT, status TEXT NOT NULL, pdf_path TEXT, digest TEXT, created TEXT NOT NULL,
                    updated TEXT NOT NULL, error TEXT NOT NULL DEFAULT '')''')
            columns={row[1] for row in db.execute('PRAGMA table_info(job)')}
            if 'link_id' not in columns:db.execute('ALTER TABLE job ADD COLUMN link_id TEXT')
            db.execute('''CREATE TABLE IF NOT EXISTS skipped_mail (job_id TEXT NOT NULL,
                      email TEXT NOT NULL, PRIMARY KEY(job_id,email))''')
    def _db(self):return sqlite3.connect(self.path,timeout=10)
    def enqueue(self,curp):
        curp=str(curp).strip().upper()
        if not CURP.fullmatch(curp):raise ValueError('La CURP no tiene un formato válido.')
        id=secrets.token_hex(16)
        now=datetime.now(timezone.utc).isoformat()
        with self._db() as db:
            db.execute('INSERT INTO job(id,curp,status,created,updated) VALUES(?,?,?,?,?)',
                       (id,self.protector.protect(curp),'PENDIENTE',now,now))
        return id
    def list(self):
        with self._db() as db:
            rows=db.execute('SELECT id,email,status,created,updated,error,pdf_path FROM job ORDER BY created,id').fetchall()
        # Never expose raw CURPs in queue overview.
        return [dict(zip(('id','email','status','created','updated','error','pdf_path'),r)) for r in rows]
    def oldest_pending(self):
        with self._db() as db:
            row=db.execute("SELECT id,curp FROM job WHERE status='PENDIENTE' ORDER BY created,id LIMIT 1").fetchone()
        return (row[0],self.protector.unprotect(row[1])) if row else (None,None)
    def set(self,id,status, email=None,error=None,pdf_path=None,digest=None,link_id=None):
        if status not in STATES:raise ValueError('Estado inválido')
        fields=['status=?','updated=?'];vals=[status,datetime.now(timezone.utc).isoformat()]
        for key,value in [('email',email),('error',error),('pdf_path',pdf_path),('digest',digest),('link_id',link_id)]:
            if value is not None:fields.append(key+'=?');vals.append(value)
        vals.append(id)
        with self._db() as db:
            result=db.execute('UPDATE job SET '+','.join(fields)+' WHERE id=?',vals)
            if not result.rowcount:raise KeyError('Solicitud no encontrada')
    def get(self,id):
        with self._db() as db:
            row=db.execute('SELECT id,curp,email,status,pdf_path,digest,error,link_id FROM job WHERE id=?',(id,)).fetchone()
        if not row:return None
        keys=('id','curp','email','status','pdf_path','digest','error','link_id')
        obj=dict(zip(keys,row));obj['curp']=self.protector.unprotect(obj['curp'])
        return obj
    def skip_email(self,id,email):
        """Evitar devolver este correo al MISMO trámite tras cambio manual."""
        normalized=str(email).strip().lower()
        if not normalized:return
        with self._db() as db:
            db.execute('INSERT OR IGNORE INTO skipped_mail(job_id,email) VALUES(?,?)',(id,normalized))
    def skipped_emails(self,id):
        with self._db() as db:
            return {row[0] for row in db.execute('SELECT email FROM skipped_mail WHERE job_id=?',(id,))}

    def recover(self):
        # Following crash, never assume a request finished or replay IMSS actions.
        with self._db() as db:
            db.execute("UPDATE job SET status='REQUIERE_ATENCION',error='Revisar el HONOR y el correo antes de continuar' WHERE status IN ('ACTIVA','ESPERANDO_CODIGO','ESPERANDO_PDF') OR (status='PENDIENTE' AND COALESCE(link_id,'')!='')")


class DPAPIProtector:
    def protect(self,value):
        from pin_vault import _crypt
        return _crypt(value.encode('utf-8'),True)
    def unprotect(self,value):
        from pin_vault import _crypt
        return _crypt(value,False).decode('utf-8')
