import concurrent.futures, json, os, tempfile, unittest
from pathlib import Path
from unittest.mock import Mock, patch
from urllib.request import Request, build_opener, ProxyHandler
from urllib.error import HTTPError
import enlace
from mail_link import Session, SessionInvalid

ID='a'*32
OTHER='b'*32
class LocalHTTP(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        base=Path(self.tmp.name)
        p=patch.multiple(enlace,BASE=base,KEYFILE=base/'key');p.start();self.addCleanup(p.stop)
        self.state=enlace.State();self.resolver=Mock(return_value='one@example.com')
        self.server=enlace.Server(self.state,port=0,resolver=self.resolver)
        self.server.start();self.addCleanup(self.server.close)
        self.client=enlace.Client(port=self.server.server.server_address[1])
    def test_real_http_assignment_code_and_completion(self):
        session=Session(self.client,request_id=ID)
        self.assertEqual(session.prepare(),'one@example.com')
        self.client.call('/v1/codigo',{'id':ID,'email':'one@example.com','code':'001234'})
        submitted=[];self.assertTrue(session.exchange(submitted.append))
        self.assertEqual(submitted,['001234'])
        self.assertIsNone(self.client.status(ID)['code'])
        self.assertEqual(self.client.status(ID)['status'],'CODIGO_ENVIADO_AL_CELULAR')
        session.done();self.assertEqual(self.client.status(ID)['status'],'SOLICITUD_IMSS_ENVIADA')
    def test_retry_same_folio_does_not_erase_code_or_reset_clock(self):
        self.client.begin('one@example.com',ID)
        self.state.put_code(ID,'001234',email='one@example.com')
        before=self.client.status(ID)
        self.assertEqual(self.client.begin('one@example.com',ID),before)
        self.assertEqual(self.client.reserve(ID),before)
        with self.assertRaises(enlace.LinkError):self.client.begin('other@example.com',ID)
    def test_other_request_cannot_overwrite_active_request(self):
        self.client.reserve(ID)
        with self.assertRaises(enlace.LinkError):self.client.reserve(OTHER)
        with self.assertRaises(enlace.LinkError):self.client.begin('two@example.com',OTHER)
        self.assertEqual(self.client.status(ID)['email'],'one@example.com')
    def test_wrong_account_and_missing_account_rejected(self):
        self.client.reserve(ID)
        for email in ('other@example.com',''):
            with self.assertRaises(enlace.LinkError):
                self.client.call('/v1/codigo',{'id':ID,'email':email,'code':'001234'})
        self.assertIsNone(self.client.status(ID)['code'])
    def test_lost_ack_response_never_retypes_code(self):
        session=Session(self.client,request_id=ID);session.prepare()
        self.state.put_code(ID,'001234',email='one@example.com')
        real_ack=self.client.ack
        def lost(req):real_ack(req);raise enlace.LinkError('response lost')
        sent=[]
        with patch.object(self.client,'ack',side_effect=lost):
            with self.assertRaises(enlace.LinkError):session.exchange(sent.append)
        self.assertTrue(session.exchange(sent.append));self.assertEqual(sent,['001234'])
    def test_partial_phone_failure_is_not_replayed(self):
        session=Session(self.client,request_id=ID);session.prepare()
        self.state.put_code(ID,'001234',email='one@example.com')
        submit=Mock(side_effect=RuntimeError('partial phone write'))
        with self.assertRaises(RuntimeError):session.exchange(submit)
        self.assertFalse(session.exchange(submit));submit.assert_called_once()
        self.assertEqual(self.client.status(ID)['status'],'CODIGO_DISPONIBLE')
    def test_manual_submission_disables_automatic_submission(self):
        session=Session(self.client,request_id=ID);session.prepare();session.mark_manual()
        submit=Mock();self.assertFalse(session.exchange(submit));submit.assert_not_called()
    def test_parallel_reservations_have_single_winner(self):
        def reserve(i):
            try:return self.client.reserve(format(i,'032x'))['request_id']
            except enlace.LinkError:return None
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            winners=[r for r in pool.map(reserve,range(1,9)) if r]
        self.assertEqual(len(winners),1);self.resolver.assert_called_once()
    def test_no_key_and_cross_origin_rejected(self):
        url=f'http://127.0.0.1:{self.client.port}/v1/ping'
        for headers in ({},{'X-GD-Link-Key':'é'},{'X-GD-Link-Key':enlace.shared_key(),'Origin':'https://untrusted.invalid'}):
            with self.assertRaises(HTTPError) as result:
                build_opener(ProxyHandler({})).open(Request(url,headers=headers))
            self.assertEqual(result.exception.code,401)
    def test_server_can_close_without_starting_worker(self):
        server=enlace.Server(enlace.State(),port=0)
        server.close();self.assertEqual(server.server.socket.fileno(),-1)
    def test_redirect_never_forwards_local_key_to_another_server(self):
        from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
        import threading
        received=[]
        class Target(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):
                received.append(self.headers.get('X-GD-Link-Key'))
                self.send_response(200);self.end_headers();self.wfile.write(b'{}')
        target=ThreadingHTTPServer(('127.0.0.1',0),Target)
        worker=threading.Thread(target=target.serve_forever,daemon=True);worker.start()
        self.addCleanup(target.server_close);self.addCleanup(target.shutdown)
        class Redirect(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):
                self.send_response(302)
                self.send_header('Location',f'http://127.0.0.1:{target.server_address[1]}/leak')
                self.end_headers()
        redirect=ThreadingHTTPServer(('127.0.0.1',0),Redirect)
        threading.Thread(target=redirect.serve_forever,daemon=True).start()
        self.addCleanup(redirect.server_close);self.addCleanup(redirect.shutdown)
        with self.assertRaises(enlace.LinkError):
            enlace.Client(port=redirect.server_address[1]).ping()
        self.assertEqual(received,[])
    def test_body_limits_and_invalid_json(self):
        url=f'http://127.0.0.1:{self.client.port}/v1/iniciar'
        for body in (b'x'*2049,b'{',b'[]',b'\xff'):
            with self.assertRaises(HTTPError) as result:
                build_opener(ProxyHandler({})).open(Request(url,data=body,headers={'X-GD-Link-Key':enlace.shared_key()}))
            self.assertEqual(result.exception.code,400)
    def test_loopback_uses_local_route_despite_internet_proxy(self):
        with patch.dict(os.environ,{'HTTP_PROXY':'http://invalid:1','http_proxy':'http://invalid:1','NO_PROXY':'','no_proxy':''}):
            self.assertTrue(self.client.ping()['ok'])
    def test_no_account_and_busy_leave_state_unchanged(self):
        state=enlace.State()
        with self.assertRaises(ValueError):state.reserve(ID,lambda:None,lambda:True)
        self.assertIsNone(state.job)
        with self.assertRaises(ValueError):state.reserve(ID,lambda:'one@example.com',lambda:False)
        self.assertIsNone(state.job)
    def test_expired_codes_are_rejected_and_done_is_not_expired(self):
        self.state.start('one@example.com',ID);self.state.job['created']-=901
        with self.assertRaises(ValueError):self.state.put_code(ID,'001234',email='one@example.com')
        self.assertEqual(self.state.status()['status'],'CADUCADA')
        self.state.start('two@example.com',OTHER);self.state.imss_done(OTHER);self.state.job['created']-=901
        self.assertEqual(self.state.status()['status'],'SOLICITUD_IMSS_ENVIADA')
    def test_cancel_clears_code_and_requires_matching_folio(self):
        self.client.reserve(ID);self.state.put_code(ID,'001234',email='one@example.com')
        with self.assertRaises(enlace.LinkError):self.client.cancel(OTHER)
        self.client.cancel(ID)
        self.assertEqual(self.client.status(ID)['status'],'CANCELADA')
        self.assertIsNone(self.client.status(ID)['code'])
        with self.assertRaises(enlace.LinkError):self.client.done(ID)
        self.assertEqual(self.client.reserve(OTHER)['request_id'],OTHER)
    def test_mismatched_server_response_never_writes_phone(self):
        client=Mock();client.status.return_value={'request_id':OTHER,'email':'one@example.com','status':'CODIGO_DISPONIBLE','code':'001234'}
        session=Session(client,email='one@example.com',request_id=ID);submit=Mock()
        with self.assertRaises(SessionInvalid):session.exchange(submit)
        submit.assert_not_called()

if __name__=='__main__':unittest.main()
