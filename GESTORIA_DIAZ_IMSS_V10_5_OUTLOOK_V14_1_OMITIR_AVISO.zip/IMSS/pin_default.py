"""No embedded PIN. Only load a PIN explicitly saved by this Windows user."""
DEFAULT_PHONE_PIN = ''

def configured_pin(vault):
    try:
        saved=vault.load()
        if saved:return saved,'PIN privado cargado desde DPAPI; activa su uso si lo autorizas.'
    except vault.VaultError:
        return None,'PIN privado no disponible; confirma la identidad manualmente.'
    return None,'Sin PIN guardado. Puedes usar el teléfono o guardar uno cifrado explícitamente.'
