"""In-memory, single-use consent bound to one manual request or queue folio."""
class TransferConsent:
    def __init__(self):self.manual=None;self.jobs=set()
    def grant_manual(self,curp,email=''):
        self.manual=(curp.strip().upper(),email.strip().lower())
    def grant_job(self,jid):self.jobs.add(jid)
    def move_to_job(self,jid,curp,email=''):
        if self._matches(curp,email):
            self.jobs.add(jid);self.manual=None;return True
        return False
    def _matches(self,curp,email):
        return (self.manual is not None and self.manual[0]==curp.strip().upper()
                and (not self.manual[1] or self.manual[1]==email.strip().lower()))
    def claim(self,curp,email='',jid=None):
        if jid is not None:
            approved=jid in self.jobs;self.jobs.discard(jid)
            return approved
        approved=self._matches(curp,email)
        self.manual=None
        return approved
    def clear(self):self.manual=None;self.jobs.clear()
