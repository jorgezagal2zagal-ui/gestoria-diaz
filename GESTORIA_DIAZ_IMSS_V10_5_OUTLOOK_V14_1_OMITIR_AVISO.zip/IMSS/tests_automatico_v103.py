"""Explicit single-request consent, automatic positive tap and safe preview failures."""
import struct,threading,unittest,zlib
from types import SimpleNamespace
from unittest.mock import Mock,patch,call
from adb_imss import ADB,IMSSFlow,Node,DeviceError
from panel import IMSSPanel
from preview_image import dimensions,SIGNATURE
from transfer_consent import TransferConsent
import tests_arranque_v102 as startup_cases
Var=startup_cases.Var

CURP='AAAA000101HDFBBB01';EMAIL='synthetic@example.invalid'
def dialog():
    return [Node('Esta CURP está vinculada a otro dispositivo móvil ¿Deseas vincularla a este?','','','android.widget.TextView',(10,10,300,120)),
            Node('NO','','android:id/button2','android.widget.Button',(10,130,100,180),True),
            Node('SÍ, QUIERO HACER EL CAMBIO','','android:id/button1','android.widget.Button',(120,130,300,180),True)]
def tiny_png():
    def chunk(tag,payload):
        return struct.pack('>I',len(payload))+tag+payload+struct.pack('>I',zlib.crc32(tag+payload)&0xffffffff)
    return SIGNATURE+chunk(b'IHDR',struct.pack('>IIBBBBB',1,1,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b'\0\0\0\0\0'))+chunk(b'IEND',b'')

class ConsentScope(unittest.TestCase):
    def test_manual_approval_is_single_use_and_bound_to_curp_and_email(self):
        consent=TransferConsent();consent.grant_manual(CURP,EMAIL)
        self.assertTrue(consent.claim(CURP,EMAIL));self.assertFalse(consent.claim(CURP,EMAIL))
        consent.grant_manual(CURP,EMAIL)
        self.assertFalse(consent.claim(CURP,'other@example.invalid'));self.assertFalse(consent.claim(CURP,EMAIL))
    def test_unapproved_folio_never_inherits_approval(self):
        consent=TransferConsent();consent.grant_job('one')
        self.assertFalse(consent.claim(CURP,EMAIL,'two'))
        self.assertTrue(consent.claim(CURP,EMAIL,'one'));self.assertFalse(consent.claim(CURP,EMAIL,'one'))
    def test_queueing_moves_approval_to_exact_folio(self):
        consent=TransferConsent();consent.grant_manual(CURP)
        self.assertTrue(consent.move_to_job('one',CURP));self.assertIsNone(consent.manual)
        self.assertTrue(consent.claim(CURP,EMAIL,'one'));self.assertFalse(consent.claim(CURP,EMAIL))
    def test_stop_revokes_manual_and_future_queued_approvals(self):
        consent=TransferConsent();consent.grant_manual(CURP,EMAIL);consent.grant_job('one');consent.clear()
        self.assertFalse(consent.claim(CURP,EMAIL));self.assertFalse(consent.claim(CURP,EMAIL,'one'))

class AutomaticEngine(unittest.TestCase):
    def test_approved_dialog_sends_single_yes_without_another_confirmation(self):
        adb=Mock();flow=IMSSFlow(adb,CURP,EMAIL,Mock());flow.auto_transfer_approved=True
        with patch('adb_imss.time.monotonic',return_value=10):self.assertEqual(flow.step(dialog()),'action')
        adb.tap_node.assert_called_once();self.assertEqual(adb.tap_node.call_args.args[0].text,'SÍ, QUIERO HACER EL CAMBIO')
        self.assertFalse(flow.auto_transfer_approved)
        with patch('adb_imss.time.monotonic',return_value=11):self.assertEqual(flow.step(dialog()),'retry')
        with patch('adb_imss.time.monotonic',return_value=14):self.assertEqual(flow.step(dialog()),'paused')
        adb.tap_node.assert_called_once()
    def test_no_approval_and_unrelated_yes_never_trigger_automatic_tap(self):
        adb=Mock();flow=IMSSFlow(adb,CURP,EMAIL,Mock())
        self.assertEqual(flow.step(dialog()),'paused');adb.tap_node.assert_not_called()
        flow.auto_transfer_approved=True
        flow.step([Node('Otra pantalla','','','android.widget.TextView',(0,0,300,100)),dialog()[-1]])
        adb.tap_node.assert_not_called()
    def test_live_opt_in_wakes_the_same_paused_flow_without_popup(self):
        adb=Mock();flow=IMSSFlow(adb,CURP,EMAIL,Mock())
        f=SimpleNamespace(auto_transfer=Var(True),flow=flow,running=True,stop=threading.Event(),
            advance=threading.Event(),transfer_consent_status=Var(''))
        with patch('panel.messagebox.askyesno') as ask:IMSSPanel.auto_transfer_changed(f)
        self.assertTrue(f.advance.is_set());self.assertTrue(flow.auto_transfer_approved);ask.assert_not_called()
        self.assertEqual(flow.step(dialog()),'action');adb.tap_node.assert_called_once()
    def test_stop_after_hierarchy_read_prevents_preapproved_automatic_touch(self):
        fixture=startup_cases.StartupRegression(methodName='test_independent_mode_never_calls_outlook')
        f,_=fixture.panel(linked=False);f.transfer_consents.grant_manual(CURP,EMAIL)
        def stopped():f.stop.set();return dialog()
        f.adb.hierarchy.side_effect=stopped
        with patch('panel.time.sleep'),patch('panel.record'):self.assertTrue(IMSSPanel.start(f))
        f.adb.tap_node.assert_not_called();self.assertIn(call('flow_end',(None,None)),f.put.call_args_list)
    def test_full_start_and_flow_automatically_accept_dialog_and_reach_finish(self):
        fixture=startup_cases.StartupRegression(methodName='test_independent_mode_never_calls_outlook')
        f,events=fixture.panel(linked=False)
        f.auto_transfer.set(True)
        f.queue_view=Mock();f.queue_view.selection.return_value=()
        IMSSPanel.auto_transfer_changed(f)
        tapped=[]
        f.adb.tap_node.side_effect=lambda node:tapped.append(node.text)
        f.adb.hierarchy.side_effect=lambda:[Node('Solicitud exitosa','','','android.widget.TextView',(0,0,300,100))] if tapped else dialog()
        # The device refuses screenshots, but navigation and consent still work.
        f.adb.screenshot.side_effect=DeviceError('screen capture unavailable')
        with patch('panel.time.sleep'),patch('panel.record'),patch('panel.messagebox.askyesno') as ask:
            self.assertTrue(IMSSPanel.start(f))
        self.assertEqual(tapped,['SÍ, QUIERO HACER EL CAMBIO']);ask.assert_not_called()
        self.assertIn(call('flow_end',(None,'finished')),f.put.call_args_list)
        self.assertIn(call('preview_unavailable',None),f.put.call_args_list)
        self.assertFalse(f.transfer_consents.claim(CURP,EMAIL))

class PreviewSafety(unittest.TestCase):
    def test_real_png_framing_and_crc_are_validated(self):
        png=tiny_png();self.assertEqual(dimensions(png),(1,1))
        for invalid in (b'Failed to take screenshot',png[:-4],png[:-1]+bytes([png[-1]^1]),b''):
            with self.assertRaises(ValueError):dimensions(invalid)
    def test_invalid_stdout_never_reaches_tk_image_constructor(self):
        f=SimpleNamespace(preview_unavailable=Mock())
        with patch('panel.tk.PhotoImage') as image,patch('panel.record'):
            IMSSPanel.display_preview(f,b'Failed to take screenshot')
        image.assert_not_called();f.preview_unavailable.assert_called_once()
    def test_png_format_is_explicit_in_tk(self):
        image=Mock();image.width.return_value=1;image.height.return_value=1;image.subsample.return_value='scaled'
        f=SimpleNamespace(preview=Mock(),preview_status=Var(''),preview_unavailable=Mock())
        with patch('panel.tk.PhotoImage',return_value=image) as constructor:
            IMSSPanel.display_preview(f,tiny_png())
        self.assertEqual(constructor.call_args.kwargs['format'],'png')
        self.assertEqual(f.screen_size,(1,1));f.preview_unavailable.assert_not_called()
    def test_image_error_message_never_contains_screenshot_content(self):
        f=SimpleNamespace(preview_unavailable=Mock())
        with patch('panel.tk.PhotoImage',side_effect=RuntimeError('PRIVATE_CAPTURE')),patch('panel.record') as record:
            IMSSPanel.display_preview(f,tiny_png())
        f.preview_unavailable.assert_called_once();self.assertEqual(record.call_args.args[0],'preview_render_failed')
    def test_capture_failure_is_an_event_not_a_flow_exception(self):
        f=SimpleNamespace(adb=Mock(),put=Mock());f.adb.screenshot.return_value=b'Failed to take screenshot'
        with patch('panel.record'):IMSSPanel.capture_preview(f)
        f.put.assert_called_once_with('preview_unavailable',None)
    def test_unavailable_preview_removes_stale_clickable_image(self):
        f=SimpleNamespace(screen_image='old',screen_size=(100,100),preview=Mock(),preview_status=Var(''),
            _preview_error=False,log_line=Mock())
        IMSSPanel.preview_unavailable(f)
        self.assertIsNone(f.screen_image);self.assertEqual(f.screen_size,(0,0));f.preview.delete.assert_called_once_with('all')

if __name__=='__main__':unittest.main()
