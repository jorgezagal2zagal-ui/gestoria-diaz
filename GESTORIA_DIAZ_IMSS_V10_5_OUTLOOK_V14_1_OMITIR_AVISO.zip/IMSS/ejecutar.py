"""Windows entry point with clear prerequisites and private technical diagnostics."""
import sys

def main():
    if sys.version_info<(3,10):raise SystemExit('Requiere Python 3.10 o superior.')
    if sys.platform!='win32':raise SystemExit('Este panel requiere Windows, Tk y DPAPI. Para pruebas locales ejecuta validar.py.')
    from diagnostico import record
    try:
        from panel import IMSSPanel
        IMSSPanel().run()
    except Exception as exc:
        record('startup_failed',exc)
        raise SystemExit('No se pudo abrir el panel. Revisa dependencias y el diagnóstico técnico en LOCALAPPDATA/GestoriaDiaz/Diagnostico.') from None

if __name__=='__main__':main()
