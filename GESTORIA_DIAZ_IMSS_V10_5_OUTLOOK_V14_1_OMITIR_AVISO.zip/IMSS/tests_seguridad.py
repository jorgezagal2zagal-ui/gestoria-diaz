import unittest
from adb_imss import ADB, DeviceError, Node

class StubADB(ADB):
    def __init__(self, focus='', policy='mKeyguardShowing=false'):
        super().__init__('adb','test')
        self.focus, self.policy = focus, policy
        self.events=[]
        self.files={}
        self.failed=[]
    def run(self, *args, **kwargs):
        self.events.append(args)
        if args[:4] == ('shell','dumpsys','window','windows'):
            return 'mCurrentFocus=Window{ u0 ' + self.focus + '}\n'
        if args[:4] == ('shell','dumpsys','window','policy'):
            return self.policy
        if args[:3] == ('shell','uiautomator','dump'):
            dest=args[3]
            if dest in self.failed:
                return 'ERROR: dump failed'
            self.files[dest]='<?xml version="1.0"?><hierarchy><node text="Hola" content-desc="" resource-id="" class="android.widget.TextView" bounds="[0,0][100,100]" enabled="true" /></hierarchy>'
            return 'UI hierarchy dumped to: '+dest
        if args[:3] == ('shell','rm','-f'):
            self.files.pop(args[3],None); return ''
        if args[:2] == ('shell','cat'):
            if args[2] not in self.files:
                raise DeviceError('No such file or directory')
            return self.files[args[2]]
        return ''

class TestSeguridad(unittest.TestCase):
    def test_xml_tmp_first(self):
        d=StubADB()
        self.assertEqual(d.hierarchy()[0].text,'Hola')
        self.assertIn(('shell','uiautomator','dump','/data/local/tmp/window_imss.xml'), d.events)
        self.assertEqual(d.files,{})
    def test_xml_fallback_to_sdcard(self):
        d=StubADB();d.failed=['/data/local/tmp/window_imss.xml']
        self.assertEqual(d.hierarchy()[0].text, 'Hola')
        self.assertIn(('shell','uiautomator','dump','/sdcard/window_imss.xml'),d.events)
    def test_missing_files_clear_error(self):
        d=StubADB();d.failed=['/data/local/tmp/window_imss.xml','/sdcard/window_imss.xml']
        with self.assertRaisesRegex(DeviceError, 'Android no permitió leer la pantalla'):
            d.hierarchy()
    def test_identity_focus_confirm(self):
        d=StubADB('com.android.settings/com.android.settings.password.ConfirmLockPassword')
        self.assertEqual(d.security_prompt(),'identidad')
    def test_plain_app_never_gets_pin(self):
        d=StubADB('st.android.imsspublico/.MainActivity')
        self.assertIsNone(d.security_prompt())
        with self.assertRaisesRegex(DeviceError, 'No se confirmó'):
            d.confirm_identity_pin('1234')
        self.assertFalse(any('KEYCODE_1' in parts for parts in d.events))
    def test_node_identity(self):
        n=[Node('Validación de identidad', '', '', 'TextView',(0,0,100,60)),
           Node('Confirma tu identidad para ingresar', '', '', 'TextView',(0,60,100,100))]
        d=StubADB()
        self.assertTrue(d.credential_labels(n))
    def test_lock_evidence(self):
        d=StubADB('com.other/Activity','mKeyguardShowing=true')
        self.assertEqual(d.security_prompt(),'bloqueo')
    def test_identity_entry_one_attempt(self):
        class Once(StubADB):
            def __init__(self): super().__init__('com.android.settings/.ConfirmDeviceCredentialActivity'); self.n=0
            def security_prompt(self, nodes=None):
                self.n+=1
                return 'identidad' if self.n==1 else None
        d=Once()
        self.assertTrue(d.confirm_identity_pin('1234'))
        self.assertEqual([args[-1] for args in d.events if args[:3]==('shell','input','keyevent')],
                         ['KEYCODE_1','KEYCODE_2','KEYCODE_3','KEYCODE_4','KEYCODE_ENTER'])

if __name__ == '__main__': unittest.main()
