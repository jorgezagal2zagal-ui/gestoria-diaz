# IMSS V10.3: aceptación automática con autorización previa

La captura de V10.2 muestra que Outlook ya se conectó y el flujo llegó al aviso.
El texto «Cambio de dispositivo pendiente ... No se pulsó ningún botón» era una
pausa deliberada esperando confirmación, no evidencia de que hubiera fallado un clic.
Esta versión permite autorizar ese clic antes de llegar al aviso, sin otra ventana.

## Uso del cambio automático

1. Cierra la copia anterior y extrae esta versión. Conserva el respaldo de la anterior.
2. Abre ABRIR_BOT.bat, conecta el HONOR y prepara la CURP y el correo del trámite.
3. Marca **Autorizo el cambio de dispositivo automáticamente en ESTE trámite**, solo
   si el titular autorizó vincular su CURP a ese teléfono.
4. Pulsa INICIAR TRÁMITE. Al detectar el aviso específico, el motor localiza
   SÍ, QUIERO HACER EL CAMBIO y envía un solo toque sin abrir otro mensaje de confirmación.
5. También puedes marcar esa casilla cuando el mismo trámite ya esté esperando
   en el aviso: despierta el flujo, vuelve a leer la pantalla y envía el clic autorizado.

Para cola, autoriza el folio seleccionado. Si autorizas el formulario y después
pulsas AGREGAR CURP, la autorización se mueve solo al folio que acabas de crear.
No se copia a los demás folios. Las autorizaciones están en memoria y no sobreviven
al cierre de la aplicación ni a DETENER. El siguiente intento necesita autorización
propia; el consentimiento no se confunde con aceptar el Aviso de Privacidad.

El botón AUTORIZAR CAMBIO DE DISPOSITIVO sigue disponible como alternativa manual.
No es necesario pulsarlo además de marcar la autorización automática.

## Qué se comprueba

- El aviso específico debe corresponder a vinculación de CURP/dispositivo.
- Debe existir un único control afirmativo identificable y habilitado. No se elige NO.
- No se usan posiciones fijas ni coordenadas tomadas de la foto.
- Se marca el intento antes de enviar el comando; un error parcial no produce otro clic.
- Después del clic se permiten lecturas del estado durante unos segundos. Si el aviso
  persiste, se detiene para revisión y no repite. Un clic no equivale a un cambio confirmado.
- DETENER después de leer la pantalla también impide el clic automático pendiente.
- PIN, identidad y las restricciones Microsoft se conservan; esta opción no las omite.

## Vista previa

El registro de la captura mostraba un error de Tk sobre un nombre de color. Ahora se
valida que los bytes sean un PNG completo con dimensiones y CRC válidos antes de
mostrarlo y se indica explícitamente el formato PNG a Tk.
Si Android devuelve un error o una captura no utilizable, se muestra una advertencia
separada, se retira la imagen vieja para evitar toques sobre una vista desactualizada
y el trámite puede continuar. No se registran bytes de captura ni mensajes de imagen
que puedan contener datos personales. No se afirma conocer la salida ADB exacta del
HONOR porque no se recibió esa salida; se cubren ambos caminos de fallo en pruebas.

## Compatibilidad y pruebas

Conserva el arranque V10.2 con correo escrito aunque Outlook no esté disponible,
el enlace con Outlook V14, el folio, la CURP cifrada y el resto de la navegación.
Outlook V14 no requiere reinstalación por este cambio.

122 pruebas IMSS superadas, incluidas 15 de autorización automática y vista previa.
El caso de flujo completo activa la casilla del panel, ejecuta start/run_flow, detecta
el diálogo, comprueba el único toque al botón afirmativo y llega al estado final
simulado incluso cuando la captura falla. También se probaron revocación, alcance
por folio, ausencia de consentimiento, error de imagen y parada antes del clic.
La comunicación Outlook/IMSS en procesos separados volvió a pasar.

El teléfono y la interfaz Tk se simularon. Falta probar Windows, el clic y la captura
reales en el HONOR y el trámite remoto. No se incluye la foto ni sus datos personales.
Las notas V10.0/V10.1/V10.2 son históricas; el resultado actual está en RESULTADOS_PRUEBAS.json.
