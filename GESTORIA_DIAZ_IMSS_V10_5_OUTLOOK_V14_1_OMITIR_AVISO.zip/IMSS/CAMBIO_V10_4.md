# IMSS V10.4: correcciones acotadas y diagnóstico del HONOR

La V10.3 sigue fallando en el teléfono del usuario. Esta actualización no acredita
que el trámite completo ni el clic real funcionen: falta la lectura real del HONOR.

## Fallos reproducidos y corregidos

- El botón manual ENVIAR PIN AHORA podía enviar dígitos sobre el aviso de cambio o
  el formulario IMSS. Ahora consulta una jerarquía nueva y bloquea esos casos. El
  respaldo manual sigue disponible para identidad OEM no legible, tras confirmación
  expresa. DETENER o cambiar la conexión antes del envío cancela el comando.
- Al iniciar se desmarcaba la autorización aunque siguiera concedida en memoria.
  Ahora permanece marcada mientras está pendiente y explica cuándo se utiliza.
- La detección del aviso usaba un resumen de 1200 caracteres; un formulario largo
  podía ocultarlo. Ahora comprueba el texto de los nodos completos para ese aviso.
  No se añadieron coordenadas fijas ni se relajó la selección del botón afirmativo.

Antes de corregir, cinco de las siete primeras regresiones fallaron en V10.3.
Después: 137 pruebas locales aprobadas, de las cuales 15 cubren esta actualización.
El intercambio entre procesos IMSS y Outlook V14 también pasó. Son pruebas con
Android simulado y servicios locales; Windows/Tk, DPAPI, HONOR e IMSS real siguen
sin validación en este entorno. Las pruebas no demuestran el clic en tu teléfono.

## Uso y evidencia pendiente

1. Conserva la instalación anterior. Extrae este ZIP en otra carpeta; cierra las
   otras ventanas IMSS que controlen el teléfono. Abre IMSS/ABRIR_BOT.bat.
2. Conecta el HONOR, prepara los datos y el aviso de privacidad. Si el titular
   autoriza el cambio para ese trámite, marca su casilla de cambio automático.
   Inicia o reanuda. La autorización sigue siendo individual y de un solo intento.
3. El botón PIN es exclusivamente para la pantalla de identidad de Android.
4. Si vuelve a quedarse en el aviso, pulsa COPIAR DIAGNÓSTICO SIN DATOS, situado
   bajo ACTUALIZAR VISTA, y pega el resultado en el chat antes de cerrar el panel.
   Si dice teléfono ocupado, espera a que termine su lectura y vuelve a copiar.

El diagnóstico solo lee Android: indica si hay flujo, consentimiento pendiente,
intento enviado, aviso detectado y control afirmativo único. Incluye coordenadas
de controles y banderas técnicas; nunca exporta texto de nodos, identificadores,
CURP, correo, PIN, códigos, XML ni capturas. No envía toques ni modifica la vinculación.
Un comando enviado no equivale a una aceptación confirmada por Android.

Outlook V14 se conserva. Con correo escrito, su enlace sigue siendo opcional;
sin enlace, introduce el código manualmente. No se cambiaron los motores originales
de navegación, el cifrado ni la conservación de CURP y folio.

Copia previa al cambio guardada fuera del paquete; la distribución no incluye
respaldos privados, contraseñas, PIN personales, tokens ni datos de clientes.
