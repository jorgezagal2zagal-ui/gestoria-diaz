# IMSS V10.1: botón SÍ, QUIERO HACER EL CAMBIO

Esta actualización se limita al reconocimiento del botón y al control de autorización,
con una mejora de disposición de botones de conexión. Outlook V14 sigue siendo compatible.

## Cómo usarlo

1. Cierra la versión anterior y conserva su carpeta como respaldo. Extrae esta copia
   en otra carpeta. No incluyas PIN, cuentas ni bases locales dentro del programa.
2. Ejecuta ABRIR_BOT.bat, conecta el HONOR y carga/inicia el mismo trámite para que
   detecte el aviso de vinculación. Si proviene de la cola, revisa su folio existente;
   no agregues otra CURP para sustituirlo. Los datos cifrados del perfil se conservan.
3. Pulsa AUTORIZAR CAMBIO DE DISPOSITIVO o AUTORIZAR CAMBIO IMSS junto a la vista.
   Confirma solo si el titular de esa solicitud autorizó expresamente la vinculación.
4. El programa lee de nuevo el aviso y pulsa una vez el botón afirmativo identificado.
   Si reconoce la siguiente pantalla, reanuda el mismo flujo. Si el aviso continúa o
   Android no permite comprobarlo, exige revisión y no repite el toque automáticamente.

## Corrección

- Reconoce el texto exacto «SÍ, QUIERO HACER EL CAMBIO», variantes de puntuación/saltos
  de línea, el SI corto y controles positivos Android identificados sin texto.
- No usa posiciones fijas ni coordenadas de la fotografía: toca el centro del control
  expuesto por Android. Rechaza botones negativos, deshabilitados o ambiguos.
- La confirmación pertenece explícitamente a la ventana IMSS. No hay salidas silenciosas
  si falta conexión/trámite o ya hubo un intento; se muestra la causa.
- Desactiva el botón durante la comprobación, fija la autorización al mismo flujo y
  dispositivo, y rechaza respuestas tardías después de DETENER o de cambiar el trámite.
- Revisa el estado después del toque; no presenta un clic como vinculación completada.
- Los cuatro botones de conexión van en dos filas para evitar el recorte observado.

## Evidencia y límites

94 pruebas IMSS superadas, incluidas 17 específicas de esta corrección. Una prueba usa
solo el texto público del diálogo de la foto, con posiciones ficticias: comprueba que
el comando ADB apunta al botón afirmativo y nunca a NO. No se copiaron CURP, correo,
imagen ni otros datos personales de la foto en esta distribución.

El control ADB del teléfono está simulado en las pruebas. No se ha comprobado el clic
real en el HONOR ni la visualización Windows. No se asegura que la vinculación real
termine. Si Android no expone un control inequívoco, el programa no pulsa a ciegas.
La navegación restante, el cifrado, el folio y la CURP no se cambian con esta corrección.

Los informes de 77 pruebas IMSS/116 totales corresponden a la versión V10.0 anterior.
RESULTADOS_PRUEBAS.json contiene el resultado actual de V10.1.
