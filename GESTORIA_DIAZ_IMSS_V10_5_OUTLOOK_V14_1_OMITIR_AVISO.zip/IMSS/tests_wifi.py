"""Pruebas aisladas: nunca intenta comunicarse con un celular real."""
import unittest
from unittest.mock import patch
from adb_imss import ADB, DeviceError, connect_wifi

IP = '192.168.100.8'

class FakeADB:
    def __init__(self, binary, serial=''):
        self.binary, self.serial = binary, serial
    def connected_serials(self, ip):
        assert ip == IP
        return self.existing
    def is_online(self):
        return self.serial in self.online
    def tls_connection_ports(self, ip):
        assert ip == IP
        return self.discovered.copy()
    def connect(self, ip, port):
        assert ip == IP
        self.tried.append(port)
        if port not in self.accept:
            raise DeviceError('Connection refused')
        return f'connected to {ip}:{port}'

class TestWifi(unittest.TestCase):
    def test_mdns_filters_pair_port_and_other_ip(self):
        sample = '''List of discovered mdns services
adb-123 _adb-tls-pairing._tcp 192.168.100.8:42507
adb-123-a _adb-tls-connect._tcp 192.168.100.9:45123
adb-123-b _adb-tls-connect._tcp 192.168.100.8:41789
adb-123-c _adb-tls-connect._tcp. 192.168.100.8:41789
'''
        with patch.object(ADB, 'run', return_value=sample):
            self.assertEqual(ADB('adb').tls_connection_ports(IP), ['41789'])

    def test_mdns_no_service(self):
        with patch.object(ADB, 'run', return_value='List of discovered mdns services'):
            self.assertEqual(ADB('adb').tls_connection_ports(IP), [])

    def test_connected_serials_only_requested_ip_and_online(self):
        text = '''List of devices attached
192.168.100.9:41789 device
192.168.100.8:41789 device
192.168.100.8:42788 offline
R58xyz device
'''
        with patch.object(ADB, 'run', return_value=text):
            self.assertEqual(ADB('adb').connected_serials(IP), [IP + ':41789'])

    def test_stale_manual_port_uses_discovered_one(self):
        FakeADB.existing=[]; FakeADB.online=[IP+':41789']; FakeADB.accept=['41789']
        FakeADB.discovered=['41789']; FakeADB.tried=[]
        with patch('adb_imss.ADB', FakeADB):
            device, events = connect_wifi('adb', IP, '41787')
            self.assertEqual(device.serial, IP+':41789')
            self.assertEqual(FakeADB.tried, ['41789'])
            self.assertTrue(any('automáticamente' in x for x in events))

    def test_reuses_existing_connection_without_mdns(self):
        FakeADB.existing=[IP+':44111']; FakeADB.online=[IP+':44111']
        FakeADB.discovered=[]; FakeADB.accept=[]; FakeADB.tried=[]
        with patch('adb_imss.ADB', FakeADB):
            device, events = connect_wifi('adb', IP, '41787')
            self.assertEqual(device.serial, IP+':44111')
            self.assertEqual(FakeADB.tried, [])

    def test_manual_port_works_when_mdns_unavailable(self):
        FakeADB.existing=[]; FakeADB.online=[IP+':50002']
        FakeADB.discovered=[]; FakeADB.accept=['50002']; FakeADB.tried=[]
        with patch('adb_imss.ADB', FakeADB):
            device, events = connect_wifi('adb', IP, '50002')
            self.assertEqual(device.serial, IP+':50002')

    def test_helpful_error_without_port(self):
        FakeADB.existing=[]; FakeADB.online=[]
        FakeADB.discovered=[]; FakeADB.accept=[]; FakeADB.tried=[]
        with patch('adb_imss.ADB', FakeADB):
            with self.assertRaisesRegex(DeviceError, 'puerto de conexión'):
                connect_wifi('adb', IP, '')

    def test_failure_when_adb_prints_connection_failed_with_exit_zero(self):
        with patch.object(ADB, 'run', return_value='failed to connect to 192.168.100.8:41787'):
            with self.assertRaises(DeviceError):
                ADB('adb').connect(IP, '41787')

if __name__ == '__main__':
    unittest.main()
