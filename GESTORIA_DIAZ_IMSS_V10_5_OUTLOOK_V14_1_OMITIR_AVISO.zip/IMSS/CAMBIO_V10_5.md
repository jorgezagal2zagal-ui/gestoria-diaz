# IMSS V10.5 / Outlook V14.1: cerrar y omitir el fallo de actualización

Se añade el tratamiento del mensaje público confirmado por el usuario:
«Por el momento, no se pudo realizar la actualización del dispositivo.
Favor de intentar más tarde.» También reconoce «intentarlo más tarde».

## Comportamiento

- Envía un solo toque a un único botón CERRAR habilitado detectado por Android.
  No usa las coordenadas de la fotografía ni cierra mensajes de error desconocidos.
- Comprueba con una lectura nueva que el aviso desapareció y que está el formulario
  de inicio con dos campos. No vuelve a enviar la misma solicitud al formulario.
- Conserva el folio, CURP y correo bajo OMITIDA_DISPOSITIVO. Si se inició de manera
  individual, crea un folio de historial con la CURP cifrada usando el mecanismo
  Windows existente. No se registra como SOLICITUD_ENVIADA ni como constancia obtenida.
- Cancela y verifica únicamente la reserva Outlook correspondiente al folio omitido.
  Si no puede comprobarlo, queda REQUIERE_ATENCION y detiene la cola para revisión.
- Si Procesar cola está activado, pasa al siguiente folio pendiente. Un folio omitido
  no bloquea por sí solo la cola y no se vuelve a intentar automáticamente.
- Puedes seleccionar el omitido y usar REVISAR FOLIO para un reintento deliberado,
  conservando exactamente el mismo folio y CURP. La vinculación requiere una nueva
  autorización expresa, como antes.

Outlook V14.1 añade solo el cierre de la sesión privada que él mismo abrió
AUTOMÁTICAMENTE para el folio cancelado. Comprueba folio, correo y modo automático;
no cierra una sesión manual ni otra cuenta. Usa el cierre original y mantiene la
pausa de 60 segundos entre cuentas y cualquier bloqueo de Microsoft. La siguiente
cuenta espera ese enfriamiento y la disponibilidad del navegador. La navegación,
las verificaciones de identidad y la lectura original del correo se conservan.

Si CERRAR no se identifica, el aviso sigue visible, aparece otra ventana o no se
confirma el formulario, pide revisión y no lanza otro trámite sobre esa pantalla.
COPIAR DIAGNÓSTICO SIN DATOS sigue disponible para informar del caso sin datos privados.

## Instalación

1. Conserva tus carpetas actuales. Extrae este paquete en otra carpeta.
2. Cierra las ventanas anteriores. Abre IMSS/ABRIR_BOT.bat y, si usas el enlace,
   OUTLOOK/ABRIR_OUTLOOK.bat. Los dos componentes permanecen separados y conectados.
3. Activa la cola IMSS solo si deseas avanzar automáticamente. Para cuentas
   automáticas activa también el modo correspondiente en Outlook.
4. No copies PIN, contraseñas, tokens ni bases de clientes a estas carpetas.
   El paquete utiliza los mecanismos existentes para los datos locales del usuario.

Este cambio cubre el aviso confirmado de actualización fallida. No se añadió una
regla para otro mensaje de correo/48 horas: no se proporcionó su texto exacto.

## Verificación y límites

Antes del cambio fallaron 5 de las 7 primeras regresiones específicas en V10.4.
Después pasaron 153 pruebas IMSS y 43 pruebas Outlook (196 en total), además de
los scripts de aserciones existentes y la prueba de comunicación en procesos
separados: código, envío, cancelación de omitido y reserva siguiente.
Las regresiones nuevas comprueban cierre único, errores desconocidos, falta de
avance, fallo parcial de ADB, conservación y recuperación SQLite, paso inmediato
al siguiente folio, cancelación HTTP real, rechazo de otro folio y cierre de la
sesión automática con el mecanismo de pausa original.

El teléfono, el navegador Microsoft y las variables de interfaz se simularon en
estas pruebas. No se ejecutaron Windows/Tk, DPAPI nativo, HONOR, sesión Microsoft ni
el trámite IMSS real. Que las pruebas locales pasen no acredita el clic en el equipo.
Las copias previas de ambos componentes están fuera de la distribución. No se
incluyen fotografías, datos de clientes, secretos, sesiones, bases ni respaldos.
