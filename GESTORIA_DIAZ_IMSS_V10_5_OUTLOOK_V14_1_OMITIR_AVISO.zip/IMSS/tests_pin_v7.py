import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import pin_vault
from adb_imss import ADB, DeviceError

class MoreADB(ADB):
    def __init__(self, window, activity='', lock='mKeyguardShowing=false'):
        super().__init__('adb', 'test')
        self.window, self.activity, self.lock = window, activity, lock
        self.events = []
    def run(self, *cmd, **kwargs):
        self.events.append(cmd)
        if cmd[:4] == ('shell','dumpsys','window','windows'):
            return 'mCurrentFocus=' + self.window
        if cmd[:4] == ('shell','dumpsys','activity','activities'):
            return 'mResumedActivity=' + self.activity
        if cmd[:4] == ('shell','dumpsys','window','policy'):
            return self.lock
        return ''

class TestPinV7(unittest.TestCase):
    def test_honor_identity_foreground_recognized(self):
        d = MoreADB('com.hihonor.systemmanager/.password.ConfirmLockPassword')
        self.assertEqual(d.security_prompt(), 'identidad')
    def test_android_identity_activity_fallback(self):
        d = MoreADB('null', 'com.android.settings/.ConfirmDeviceCredentialActivity')
        self.assertEqual(d.security_prompt(), 'identidad')
    def test_plain_imss_never_types_pin(self):
        d = MoreADB('st.android.imsspublico/.MainActivity')
        self.assertIsNone(d.security_prompt())
        with self.assertRaises(DeviceError):
            d.confirm_identity_pin('2468')
        self.assertFalse(any(x[:3] == ('shell','input','keyevent') for x in d.events))
    def test_store_is_encrypted_and_reloads(self):
        with tempfile.TemporaryDirectory() as folder:
            location = Path(folder) / 'pin.dpapi'
            # Simulated cryptographic primitive. Real Windows builds call DPAPI.
            fake_crypt = lambda payload, encrypt: bytes(b ^ 0xAA for b in payload)
            with patch.object(pin_vault, 'path', return_value=location), patch.object(pin_vault, '_crypt', side_effect=fake_crypt):
                self.assertIsNone(pin_vault.load())
                pin_vault.save('2468')
                self.assertNotEqual(location.read_bytes(), b'2468')
                self.assertEqual(pin_vault.load(), '2468')
                pin_vault.forget()
                self.assertIsNone(pin_vault.load())
    def test_invalid_pin_never_stored(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch.object(pin_vault, 'path', return_value=Path(folder) / 'pin.dpapi'):
                with self.assertRaises(pin_vault.VaultError):
                    pin_vault.save('1;rm -rf')
if __name__ == '__main__': unittest.main()
