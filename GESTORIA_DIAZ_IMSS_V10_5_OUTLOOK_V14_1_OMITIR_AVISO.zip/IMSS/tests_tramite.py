"""Pruebas de la detección de consentimiento y pasos sin tocar un celular."""
import unittest
from adb_imss import IMSSFlow, Node, parse_hierarchy

class FakeDevice:
    def __init__(self):
        self.taps=[]
        self.typed=[]
    def hierarchy(self):
        return TestPrivacy().make_nodes(checked=True)
    def tap_node(self, node):
        self.taps.append((node.cx, node.cy))
    def tap(self, x, y):
        self.taps.append((x, y))
    def key(self, name):
        pass
    def text(self, text):
        self.typed.append(text)

class TestPrivacy(unittest.TestCase):
    def make_nodes(self, checked=False):
        return [
            Node('Inicia sesión', '', '', 'android.widget.TextView',(40,25,200,60)),
            Node('CURP', '', '', 'android.widget.TextView',(80,120,230,155)),
            Node('Correo electrónico', '', '', 'android.widget.TextView',(80,210,230,240)),
            Node('', '', '', 'android.widget.EditText',(30,160,280,205)),
            Node('', '', '', 'android.widget.EditText',(30,250,280,295)),
            Node('He leído y acepto el Aviso de Privacidad', '', '', 'android.widget.TextView',(70,320,290,355)),
            Node('', '', 'privacy_checkbox', 'android.widget.CheckBox',(20,320,50,355), True, True, False, True, checked),
            Node('Mantener sesión iniciada','','','android.widget.Switch',(250,380,290,410),True,True,False,True,False),
            Node('Iniciar sesión','','','android.widget.Button',(40,450,280,500),True),
        ]

    def test_checked_parsing(self):
        nodes = parse_hierarchy('''<?xml version="1.0" encoding="UTF-8"?>
        <hierarchy><node text="" content-desc="" resource-id="privacy" class="android.widget.CheckBox"
        bounds="[20,320][50,355]" clickable="true" enabled="true" focused="false"
        checkable="true" checked="true" /></hierarchy>''')
        self.assertTrue(nodes[0].checkable)
        self.assertTrue(nodes[0].checked)

    def test_does_not_click_before_permission(self):
        adb=FakeDevice(); f=IMSSFlow(adb, 'AAAA000000HAAAAA00', 'demo@example.com', lambda _:None)
        self.assertEqual(f.step(self.make_nodes()),'paused')
        self.assertEqual(adb.taps, [])

    def test_clicks_privacy_not_keep_session(self):
        adb=FakeDevice(); f=IMSSFlow(adb, 'AAAA000000HAAAAA00', 'demo@example.com', lambda _:None)
        f.privacy_approved=True
        self.assertEqual(f.step(self.make_nodes()), 'action')
        self.assertEqual(adb.taps, [(35,337)])
        # Hasta que se confirme la casilla, no enviar datos.
        self.assertEqual(adb.typed, [])

    def test_already_checked_moves_to_data(self):
        adb=FakeDevice(); f=IMSSFlow(adb, 'AAAA000000HAAAAA00', 'demo@example.com', lambda _:None)
        f.privacy_approved=True
        self.assertEqual(f.step(self.make_nodes(True)), 'action')
        self.assertIn('AAAA000000HAAAAA00',adb.typed)
        self.assertIn('demo@example.com',adb.typed)
        self.assertNotIn((35,337),adb.taps)

    def test_webview_label_fallback_only_once(self):
        adb=FakeDevice(); f=IMSSFlow(adb,'AAAA000000HAAAAA00','demo@example.com',lambda _:None)
        f.privacy_approved=True
        nodes=[n for n in self.make_nodes() if not n.checkable]
        self.assertEqual(f.step(nodes), 'action')
        self.assertEqual(adb.taps, [(48,337)])
        self.assertEqual(f.step(nodes), 'action')
        self.assertEqual(adb.taps.count((48,337)), 1)

    def test_no_flip_when_same_screen_does_not_update(self):
        adb=FakeDevice(); f=IMSSFlow(adb,'AAAA000000HAAAAA00','demo@example.com',lambda _:None)
        f.privacy_approved=True
        self.assertEqual(f.step(self.make_nodes()),'action')
        self.assertEqual(f.step(self.make_nodes()),'paused')
        self.assertEqual(adb.taps,[(35,337)])

if __name__ == '__main__':
    unittest.main()
