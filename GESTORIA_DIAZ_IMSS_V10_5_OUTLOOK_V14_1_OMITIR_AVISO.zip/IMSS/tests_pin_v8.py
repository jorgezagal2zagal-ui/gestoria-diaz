"""V10 policy replaces the old embedded-PIN requirement; never restore a secret."""
import unittest
from unittest.mock import Mock
from pin_default import configured_pin, DEFAULT_PHONE_PIN
from adb_imss import ADB

class TestPrivatePin(unittest.TestCase):
    def vault(self):
        v=Mock();v.VaultError=type('VaultError',(Exception,),{});return v
    def test_first_launch_has_no_default_and_does_not_persist(self):
        v=self.vault();v.load.return_value=None
        self.assertEqual(DEFAULT_PHONE_PIN,'')
        self.assertIsNone(configured_pin(v)[0]);v.save.assert_not_called()
    def test_saved_explicit_custom_pin_still_loads(self):
        v=self.vault();v.load.return_value='9876'
        self.assertEqual(configured_pin(v)[0],'9876');v.save.assert_not_called()
    def test_vault_failure_requires_manual_identity(self):
        v=self.vault();v.load.side_effect=v.VaultError('unavailable')
        self.assertIsNone(configured_pin(v)[0]);v.save.assert_not_called()
    def test_button_sends_only_explicit_synthetic_pin(self):
        class FakeADB(ADB):
            def __init__(self):super().__init__('adb','phone');self.events=[]
            def key(self,name):self.events.append(name)
        d=FakeADB();d.enter_pin_on_confirmation('2468')
        self.assertEqual(d.events,['KEYCODE_2','KEYCODE_4','KEYCODE_6','KEYCODE_8','KEYCODE_ENTER'])
if __name__=='__main__':unittest.main()
