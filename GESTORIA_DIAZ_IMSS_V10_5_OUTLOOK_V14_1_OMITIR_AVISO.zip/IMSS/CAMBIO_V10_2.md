# IMSS V10.2: arranque independiente cuando Outlook no responde

## Qué fallaba

V10/V10.1 intentaban registrar el trámite en Outlook ANTES de crear y lanzar el
flujo del teléfono, incluso con un correo escrito. Si el enlace fallaba, INICIAR
TRÁMITE devolvía False y no se abría IMSS. El panel mostraba solo LinkError.
Si además no había un folio en la cola, el supuesto reintento automático no existía.
AUTORIZAR CAMBIO indicaba correctamente que aún no se había creado un trámite.
La captura aportada demuestra el bloqueo del arranque por el enlace; no identifica
por sí sola por qué Outlook no estaba disponible.

La prueba de regresión reproduce ese False en V10.1. Las pruebas anteriores no
cubrían el recorrido completo de INICIAR con Outlook no disponible.

## Corrección

- Con un correo válido escrito, INICIAR crea el flujo IMSS sin exigir primero
  el éxito de Outlook. El intento opcional de conexión se hace una vez en el hilo
  de trabajo, antes de lanzar Android y sin mantener bloqueado el acceso ADB.
- Si falla Outlook, el bot conserva el correo, folio y CURP y continúa en modo
  código manual. Lo indica expresamente junto al enlace y bajo la cola. No recibe
  ni confirma códigos de otra solicitud ni afirma que Outlook esté conectado.
- Si Outlook sí responde, conserva el modo conectado y comunica la finalización.
- Si el correo está vacío y se solicita asignación automática, sigue siendo
  necesario Outlook: no se inventa un correo ni se inicia un formulario incompleto.
- La cola con un correo explícito también puede arrancar sin Outlook. Una reserva
  incierta conserva su identificador para revisión; no se cancela otro folio.
- Los errores del enlace muestran una causa segura: conexión, clave local,
  versión de Outlook, otro folio activo, disponibilidad o falta de cuenta.
  Ya no se muestra solamente el nombre LinkError.
- DETENER durante la conexión sigue impidiendo que después se lance IMSS.
- Se mantiene la corrección V10.1 del botón SÍ, QUIERO HACER EL CAMBIO, con la
  autorización expresa del titular antes de pulsarlo una sola vez.

## Uso

1. Cierra el IMSS anterior y extrae esta copia en otra carpeta; conserva el respaldo.
2. Ejecuta ABRIR_BOT.bat, conecta el HONOR y escribe un correo y la CURP.
3. Revisa el Aviso de Privacidad y pulsa INICIAR TRÁMITE. La cola es opcional para
   una solicitud individual; no es necesario activar Procesar cola.
4. Con Outlook cerrado o su enlace no disponible, continúa IMSS e introduce el
   código manualmente cuando lo solicite. El aviso del enlace indicará ese modo.
5. Para asignación de cuentas o lectura automática, abre también Outlook V14 en
   esta misma PC/usuario, prepara sus cuentas y activa su modo automático. No es
   necesario reinstalarlo por esta corrección.
6. Para pasar de manual a automático, termina o detén y revisa el intento actual;
   no se conecta tardíamente a otra cuenta a mitad de una solicitud.

No se borran PIN privados, contraseñas, folios ni bases del perfil de Windows.
No se incluyen datos de las capturas ni los respaldos personales en el paquete.

## Resultado de pruebas

107 pruebas IMSS superadas, incluidas 13 específicas de arranque/diagnóstico y
las 17 del cambio de dispositivo. Las pruebas de arranque recorren los métodos
reales start y run_flow, con el teléfono simulado; verifican que se invoque launch
cuando falla Outlook y que no se invoque sin correo o sin aceptar privacidad.
También se probaron un servidor HTTP real ocupado, otro disponible, la orden
DETENER durante la conexión y la conservación de folio/CURP con SQLite.

El intercambio entre procesos Outlook V14 e IMSS volvió a pasar. No se han probado
el inicio físico en el HONOR, Windows nativo ni el acceso real a Microsoft/IMSS.
Los informes V10.0/V10.1 anteriores son históricos: el resultado vigente de este
paquete figura en RESULTADOS_PRUEBAS.json.
