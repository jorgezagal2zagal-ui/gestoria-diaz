import unittest
from unittest.mock import patch
from adb_imss import ADB, Node, IMSSFlow, DeviceError

def node(text, x=0, y=0, clickable=False):
    return Node(text,'','','android.widget.Button' if clickable else 'android.widget.TextView', (x,y,x+50,y+50),clickable)

class IdentityV9Tests(unittest.TestCase):
    def test_identity_from_explicit_labels(self):
        n=[node('Validación de identidad'),node('Confirma tu identidad para ingresar')]
        self.assertTrue(ADB.credential_labels(n))
        self.assertEqual(ADB('/fake').security_prompt(n),'identidad')
    def test_does_not_confuse_imss_buttons(self):
        n=[node('Constancia de semanas cotizadas'),node('Iniciar sesión')]
        self.assertFalse(ADB.credential_labels(n))
    def test_flow_pauses_specific_identity(self):
        n=[node('Validación de identidad'),node('Confirma tu identidad para ingresar')]
        flow=IMSSFlow(object(),'XXXX','x@y.com',lambda x:None)
        self.assertEqual(flow.step(n),'identity')
    def test_pin_entry_uses_accessible_keypad(self):
        n=[node('Validación de identidad'),node('Confirma tu identidad para ingresar')]
        n.extend(node(str(d),d*50,200,True) for d in range(10))
        a=ADB('/fake')
        touches=[]
        a.tap_node=lambda item:touches.append(item.text)
        a.key=lambda item:self.fail('Keyevent unnecessary when keypad is accessible')
        a.hierarchy=lambda: [node('IMSS Digital')]
        self.assertTrue(a.confirm_identity_pin('2468',n))
        self.assertEqual(touches,list('2468'))
    def test_no_pin_if_not_identity(self):
        a=ADB('/fake')
        with patch.object(a,'security_prompt',return_value=None):
            with self.assertRaises(DeviceError):
                a.confirm_identity_pin('2468',[node('IMSS Digital')])

if __name__=='__main__':unittest.main()
