"""Regressions from incorrect PIN status and ambiguous consent indicators."""
import json, threading, unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch, call
from adb_imss import IMSSFlow, Node
from panel import IMSSPanel
import tests_arranque_v102 as startup
import tests_automatico_v103 as automatic

class ObservedFailures(unittest.TestCase):
    def pin_panel(self,nodes):
        adb=Mock();adb.hierarchy.return_value=nodes
        f=SimpleNamespace(connected=True,adb=adb,root=Mock(),lock=threading.Lock(),
            put=Mock(),_capture_session_pin=Mock(return_value='1234'),
            capture_preview=Mock(),advance=threading.Event(),stop=threading.Event())
        f._thread=lambda fn:fn()
        return f
    def test_pin_fallback_does_not_type_on_device_transfer_dialog(self):
        f=self.pin_panel(automatic.dialog())
        with patch('panel.messagebox.askyesno',return_value=True),patch('panel.record'):
            IMSSPanel.send_pin_confirmed(f)
        f.adb.enter_pin_on_confirmation.assert_not_called()
        self.assertFalse(f.advance.is_set())
        messages=' '.join(str(c.args) for c in f.put.call_args_list)
        self.assertIn('cambio de dispositivo',messages)
        self.assertNotIn('PIN enviado',messages)
    def test_pin_fallback_does_not_type_in_known_imss_form(self):
        f=self.pin_panel([Node('Inicia sesión CURP correo electrónico','','','android.widget.TextView',(0,0,100,100))])
        f.adb.security_prompt.return_value=None
        with patch('panel.messagebox.askyesno',return_value=True),patch('panel.record'):
            IMSSPanel.send_pin_confirmed(f)
        f.adb.enter_pin_on_confirmation.assert_not_called()
    def test_pin_confirmation_canceled_never_sends_or_reads_phone(self):
        f=self.pin_panel(automatic.dialog())
        with patch('panel.messagebox.askyesno',return_value=False):IMSSPanel.send_pin_confirmed(f)
        f.adb.hierarchy.assert_not_called();f.adb.enter_pin_on_confirmation.assert_not_called()
    def test_stopped_during_read_does_not_send_pin(self):
        f=self.pin_panel([])
        def read():f.stop.set();return []
        f.adb.hierarchy.side_effect=read
        with patch('panel.messagebox.askyesno',return_value=True),patch('panel.record'):
            IMSSPanel.send_pin_confirmed(f)
        f.adb.enter_pin_on_confirmation.assert_not_called()
    def test_approval_remains_visible_after_start(self):
        case=startup.StartupRegression('test_independent_mode_never_calls_outlook')
        f,_=case.panel(linked=False);f._thread=lambda fn:None
        f.transfer_consents.grant_manual(automatic.CURP,automatic.EMAIL)
        with patch('panel.messagebox.showerror'):self.assertTrue(IMSSPanel.start(f))
        self.assertTrue(f.flow.auto_transfer_approved)
        self.assertTrue(f.auto_transfer.get())
    def test_background_text_does_not_hide_device_dialog(self):
        flow=IMSSFlow(Mock(),automatic.CURP,automatic.EMAIL,Mock())
        background=[Node('Texto de fondo '+('x'*75),'','','android.widget.TextView',(0,0,200,50)) for _ in range(30)]
        self.assertTrue(flow.device_transfer_dialog(background+automatic.dialog()))
        flow.auto_transfer_approved=True
        self.assertEqual(flow.step(background+automatic.dialog()),'action')
        flow.adb.tap_node.assert_called_once()
        self.assertEqual(flow.adb.tap_node.call_args.args[0].text,'SÍ, QUIERO HACER EL CAMBIO')
    def test_partial_vinculation_message_is_not_enough(self):
        flow=IMSSFlow(Mock(),automatic.CURP,automatic.EMAIL,Mock())
        self.assertFalse(flow.device_transfer_dialog([Node('CURP dispositivo vinculado','','','android.widget.TextView',(0,0,300,100))]))

class SafeDiagnostics(unittest.TestCase):
    def test_report_contains_no_node_strings_or_request_data_and_sends_no_input(self):
        from screen_diagnostic import technical_snapshot
        adb=Mock();nodes=automatic.dialog()
        nodes.append(Node('PRIVATE_CUSTOMER','PRIVATE_PIN','PRIVATE_RESOURCE','PRIVATE_CLASS',(0,0,5,5)))
        adb.hierarchy.return_value=nodes
        flow=IMSSFlow(adb,'PRIVATE_CURP','PRIVATE_EMAIL',Mock());flow.auto_transfer_approved=True
        report=technical_snapshot(adb,flow,True);encoded=json.dumps(report)
        self.assertNotIn('PRIVATE',encoded)
        self.assertTrue(report['transfer_dialog']);self.assertTrue(report['unique_yes_control'])
        self.assertEqual(report['target']['bounds'],[120,130,300,180])
        self.assertEqual(adb.mock_calls,[call.hierarchy()])
    def test_unreadable_phone_does_not_export_error_message(self):
        from screen_diagnostic import technical_snapshot
        from adb_imss import DeviceError
        adb=Mock();adb.hierarchy.side_effect=DeviceError('PRIVATE_CUSTOMER')
        report=technical_snapshot(adb)
        self.assertEqual(report['read'],'unavailable');self.assertNotIn('PRIVATE',json.dumps(report))
        self.assertEqual(adb.mock_calls,[call.hierarchy()])
    def test_unrelated_screen_never_produces_a_target(self):
        from screen_diagnostic import technical_snapshot
        adb=Mock();adb.hierarchy.return_value=[automatic.dialog()[-1]]
        report=technical_snapshot(adb)
        self.assertFalse(report['transfer_dialog']);self.assertFalse(report['unique_yes_control'])
        self.assertNotIn('target',report)
    def test_nonclickable_public_label_is_exposed_structurally_without_guessing_a_target(self):
        from screen_diagnostic import technical_snapshot
        adb=Mock();nodes=automatic.dialog();nodes[-1].clickable=False
        nodes[-1].clazz='android.widget.TextView';nodes[-1].rid=''
        adb.hierarchy.return_value=nodes
        report=technical_snapshot(adb)
        self.assertTrue(report['transfer_dialog']);self.assertFalse(report['unique_yes_control'])
        self.assertEqual(len([n for n in report['controls'] if n['public_yes']]),1)
    def test_copy_button_uses_current_phone_and_emits_readonly_safe_report(self):
        adb=Mock();adb.hierarchy.return_value=automatic.dialog()
        f=SimpleNamespace(adb=adb,flow=None,running=False,connected=True,
            lock=threading.Lock(),put=Mock(),status=Mock(),_thread=lambda fn:fn())
        IMSSPanel.copy_diagnostic(f)
        kind,payload=f.put.call_args.args
        self.assertEqual(kind,'technical_diagnostic');self.assertTrue(json.loads(payload)['transfer_dialog'])
        self.assertEqual(adb.mock_calls,[call.hierarchy()])
    def test_consumed_consent_is_unchecked_with_explanation(self):
        flow=IMSSFlow(Mock(),automatic.CURP,automatic.EMAIL,Mock());flow.transfer_attempted=True
        f=SimpleNamespace(flow=flow,auto_transfer=startup.Var(True),transfer_consent_status=startup.Var(''))
        IMSSPanel.sync_transfer_state(f,flow)
        self.assertFalse(f.auto_transfer.get());self.assertIn('Autorización utilizada',f.transfer_consent_status.get())
    def test_unknown_oem_identity_keeps_manual_confirmed_pin_fallback(self):
        case=ObservedFailures();f=case.pin_panel([])
        with patch('panel.messagebox.askyesno',return_value=True),patch('panel.record'):
            IMSSPanel.send_pin_confirmed(f)
        f.adb.enter_pin_on_confirmation.assert_called_once_with('1234')
        self.assertTrue(f.advance.is_set())
    def test_known_identity_with_edit_field_still_accepts_confirmed_pin(self):
        case=ObservedFailures();f=case.pin_panel([Node('PIN','','','android.widget.EditText',(0,0,200,50))])
        f.adb.security_prompt.return_value='identidad'
        with patch('panel.messagebox.askyesno',return_value=True),patch('panel.record'):
            IMSSPanel.send_pin_confirmed(f)
        f.adb.enter_pin_on_confirmation.assert_called_once_with('1234')


if __name__=='__main__':unittest.main()
