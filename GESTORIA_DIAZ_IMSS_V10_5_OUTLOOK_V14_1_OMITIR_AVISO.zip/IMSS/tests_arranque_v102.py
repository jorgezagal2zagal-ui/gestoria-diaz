"""Full start->run_flow regression with a simulated phone and optional Outlook API."""
import threading, unittest, tempfile
from pathlib import Path
import enlace
from types import SimpleNamespace
from unittest.mock import Mock,patch,call
from adb_imss import APP_PACKAGE,IMSSFlow,Node
from enlace import LinkError
from mail_link import Session
from panel import IMSSPanel
from transfer_consent import TransferConsent

class Var:
    def __init__(self,value):self.value=value
    def get(self):return self.value
    def set(self,value):self.value=value

class StartupRegression(unittest.TestCase):
    def setUp(self):
        for target in ('panel.record','panel.time.sleep','panel.messagebox.showerror','panel.messagebox.showwarning'):
            p=patch(target);p.start();self.addCleanup(p.stop)
    def panel(self,email='synthetic@example.invalid',linked=True):
        events=[]
        adb=Mock();adb.packages.return_value=APP_PACKAGE
        adb.launch.side_effect=lambda:events.append('launch')
        adb.hierarchy.return_value=[Node('Solicitud exitosa','','','android.widget.TextView',(0,0,200,100))]
        adb.screenshot.return_value=b'synthetic preview';adb.security_prompt.return_value=None
        f=SimpleNamespace(_dispatch_busy=False,connected=True,adb=adb,running=False,
            curp=Var('AAAA000101HDFBBB01'),email=Var(email),link_enabled=Var(linked),
            _prepared_form=None,_prepare=Mock(),accept_privacy=Var(True),
            _capture_session_pin=Mock(),_session=None,_current_job=None,
            log_line=Mock(),stop=threading.Event(),advance=threading.Event(),put=Mock(),
            lock=threading.Lock(),_try_unlock_if_locked=Mock(),flow=None,
            link_status=Var(''),queue_status=Var(''),_jobs=lambda:Mock(),
            transfer_consents=TransferConsent(),auto_transfer=Var(False),transfer_consent_status=Var(''))
        f.validate_input=lambda:IMSSPanel.validate_input(f)
        f.capture_preview=lambda adb=None:IMSSPanel.capture_preview(f,adb)
        f.run_flow=lambda:IMSSPanel.run_flow(f)
        f._thread=lambda fn:fn()
        return f,events
    def test_supplied_email_launches_imss_when_outlook_is_unavailable(self):
        f,events=self.panel();client=Mock()
        def unavailable(*args):events.append('begin');raise LinkError('offline')
        client.begin.side_effect=unavailable;client.done.side_effect=LinkError('offline')
        session=Session(client,email=f.email.get())
        with patch('panel.Session',return_value=session):result=IMSSPanel.start(f)
        self.assertTrue(result)
        f._prepare.assert_not_called()
        self.assertIsInstance(f.flow,IMSSFlow)
        f.adb.launch.assert_called_once()
        self.assertEqual(events,['begin','launch'])
        self.assertTrue(session.manual)
        self.assertIn(call('flow_end',(None,'finished')),f.put.call_args_list)
    def test_available_outlook_is_registered_before_phone_and_notified_after_finish(self):
        f,events=self.panel();client=Mock();session=Session(client,email=f.email.get())
        def begin(email,request_id):
            events.append('begin')
            return {'email':email,'request_id':request_id,'status':'ESPERANDO_CODIGO'}
        client.begin.side_effect=begin
        with patch('panel.Session',return_value=session):self.assertTrue(IMSSPanel.start(f))
        self.assertEqual(events,['begin','launch']);self.assertTrue(session.prepared)
        self.assertFalse(session.manual);client.done.assert_called_once_with(session.request_id)
    def test_stop_during_optional_link_preparation_prevents_adb_launch(self):
        f,events=self.panel();client=Mock();session=Session(client,email=f.email.get())
        def stop_during_request(email,request_id):
            f.stop.set();raise LinkError('offline')
        client.begin.side_effect=stop_during_request
        with patch('panel.Session',return_value=session):IMSSPanel.start(f)
        f.adb.launch.assert_not_called()
        self.assertIn(call('flow_end',(None,None)),f.put.call_args_list)
    def test_unknown_email_still_waits_for_real_assignment_and_reports_cause(self):
        f,events=self.panel(email='');f._prepare_generation=1
        f._pending_session=None;f._pending_identity=None
        f._prepare=lambda *args:IMSSPanel._prepare(f,*args)
        client=Mock();client.reserve.side_effect=LinkError('offline')
        session=Session(client)
        with patch('panel.Session',return_value=session):self.assertFalse(IMSSPanel.start(f))
        f.adb.launch.assert_not_called();self.assertIsNone(f.flow)
        failures=[args.args[1] for args in f.put.call_args_list if args.args[0]=='prepare_failed']
        self.assertEqual(len(failures),1)
        self.assertIn('Outlook',failures[0][3]);self.assertNotEqual(failures[0][3],'LinkError')
    def test_supplied_email_handles_real_http_busy_reply_without_replacing_other_folio(self):
        with tempfile.TemporaryDirectory() as d,patch.multiple(enlace,BASE=Path(d),KEYFILE=Path(d)/'key'):
            state=enlace.State();state.start('other@example.invalid','a'*32)
            server=enlace.Server(state,port=0);server.start();self.addCleanup(server.close)
            f,events=self.panel()
            session=Session(enlace.Client(port=server.server.server_address[1]),email=f.email.get())
            with patch('panel.Session',return_value=session):self.assertTrue(IMSSPanel.start(f))
            f.adb.launch.assert_called_once();self.assertTrue(session.manual)
            self.assertEqual(state.status()['request_id'],'a'*32)
            self.assertEqual(state.status()['status'],'ESPERANDO_CODIGO')
    def test_supplied_email_handles_real_outlook_http_start_and_completion(self):
        with tempfile.TemporaryDirectory() as d,patch.multiple(enlace,BASE=Path(d),KEYFILE=Path(d)/'key'):
            state=enlace.State();server=enlace.Server(state,port=0);server.start();self.addCleanup(server.close)
            f,events=self.panel()
            session=Session(enlace.Client(port=server.server.server_address[1]),email=f.email.get())
            with patch('panel.Session',return_value=session):self.assertTrue(IMSSPanel.start(f))
            f.adb.launch.assert_called_once();self.assertTrue(session.prepared);self.assertFalse(session.manual)
            self.assertEqual(state.status(session.request_id)['status'],'SOLICITUD_IMSS_ENVIADA')
    def test_queued_explicit_email_keeps_same_folio_and_curp_with_outlook_down(self):
        from solicitudes import Requests
        class Protector:
            def protect(self,value):return bytes(b^0xAA for b in value.encode())
            def unprotect(self,value):return bytes(b^0xAA for b in value).decode()
        with tempfile.TemporaryDirectory() as d:
            jobs=Requests(Protector(),Path(d)/'jobs.db')
            jid=jobs.enqueue('AAAA000101HDFBBB01')
            jobs.set(jid,'PENDIENTE',email='synthetic@example.invalid')
            f,events=self.panel();f._jobs=lambda:jobs;f._prepare_generation=1;f._refresh_jobs=Mock()
            f.start=lambda:IMSSPanel.start(f)
            f._on_prepared=lambda *args:IMSSPanel._on_prepared(f,*args)
            client=Mock();client.begin.side_effect=LinkError('offline')
            session=Session(client,email=f.email.get())
            with patch('panel.Session',return_value=session):IMSSPanel._prepare(f,f.curp.get(),f.email.get(),jid)
            f.adb.launch.assert_called_once();self.assertEqual(f._current_job,jid)
            IMSSPanel._on_flow_end(f,jid,'finished')
            stored=jobs.get(jid)
            self.assertEqual(stored['id'],jid);self.assertEqual(stored['curp'],'AAAA000101HDFBBB01')
            self.assertEqual(stored['email'],'synthetic@example.invalid')
            self.assertEqual(stored['status'],'SOLICITUD_ENVIADA')
    def test_independent_mode_never_calls_outlook(self):
        f,events=self.panel(linked=False)
        with patch('panel.Session') as constructor:result=IMSSPanel.start(f)
        self.assertTrue(result);constructor.assert_not_called();self.assertEqual(events,['launch'])
    def test_missing_email_requires_assignment_and_does_not_launch_phone(self):
        f,events=self.panel(email='')
        self.assertFalse(IMSSPanel.start(f))
        f._prepare.assert_called_once_with('AAAA000101HDFBBB01','')
        f.adb.launch.assert_not_called();self.assertEqual(events,[])
    def test_privacy_not_approved_prevents_launch_and_link(self):
        f,events=self.panel();f.accept_privacy.set(False)
        with patch('panel.Session') as constructor:self.assertFalse(IMSSPanel.start(f))
        constructor.assert_not_called();f.adb.launch.assert_not_called()

class FailureMessages(unittest.TestCase):
    def test_connection_failure_and_http_auth_failure_have_distinct_safe_messages(self):
        from urllib.error import HTTPError, URLError
        from mail_link import link_failure_message
        offline=LinkError('El enlace local está ocupado');offline.__cause__=URLError('PRIVATE_DETAIL')
        denied=LinkError('PRIVATE_DETAIL');denied.__cause__=HTTPError('http://127.0.0.1',401,'private',{},None)
        a=link_failure_message(offline);b=link_failure_message(denied)
        self.assertIn('no responde',a);self.assertIn('clave local',b)
        self.assertNotIn('PRIVATE_DETAIL',a+b)
    def test_missing_email_failure_does_not_claim_retry_without_queued_job(self):
        f=SimpleNamespace(_dispatch_busy=True,_prepare_generation=1,_queue_retry=2,queue_status=Var(''))
        IMSSPanel._on_prepare_failed(f,None,'LinkError',1,'Outlook no responde.')
        self.assertIn('Outlook no responde',f.queue_status.get())
        self.assertIn('escribir uno',f.queue_status.get());self.assertNotIn('LinkError',f.queue_status.get())
    def test_invalid_queue_binding_requires_review_instead_of_claiming_automatic_retry(self):
        jobs=Mock();f=SimpleNamespace(_dispatch_busy=True,_prepare_generation=1,_queue_retry=2,
            queue_status=Var(''),_jobs=lambda:jobs)
        IMSSPanel._on_prepare_failed(f,'folio','SessionInvalid',1,'Reserva caducada.')
        self.assertEqual(jobs.set.call_args.args[:2],('folio','REQUIERE_ATENCION'))
        self.assertIn('no se reintentará automáticamente',f.queue_status.get())

if __name__=='__main__':unittest.main()
