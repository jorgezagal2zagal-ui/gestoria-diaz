"""Cross-process IPC test: real Outlook server module + actual IMSS client module.
No Microsoft account, DPAPI call or physical phone is used.
"""
import json, os, subprocess, sys, tempfile, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SERVER='''import json,sys,time
from pathlib import Path
from enlace import State,Server
s=State();server=Server(s,port=0,resolver=lambda:'synthetic@example.invalid')
server.start()
Path(sys.argv[1]).write_text(json.dumps({'port':server.server.server_address[1]}))
try:sys.stdin.readline()
finally:server.close()
'''
CLIENT='''import sys
from enlace import Client
from mail_link import Session
c=Client(port=int(sys.argv[1]));session=Session(c)
assert session.prepare()=='synthetic@example.invalid'
c.call('/v1/codigo',{'id':session.request_id,'email':session.email,'code':'001234'})
phone=[]
assert session.exchange(phone.append)
assert phone==['001234']
assert c.status(session.request_id)['code'] is None
session.done()
assert c.status(session.request_id)['status']=='SOLICITUD_IMSS_ENVIADA'
omitted=Session(c)
omitted.prepare()
omitted.cancel()
assert c.status(omitted.request_id)['status']=='CANCELADA'
following=Session(c)
following.prepare()
assert c.status(following.request_id)['status']=='ESPERANDO_CODIGO'
assert following.request_id!=omitted.request_id
print('CROSS-PROCESS IPC PASSED: code/completion + cancel omitted folio + reserve next; phone submission simulated.')
'''
with tempfile.TemporaryDirectory() as temporary:
    env=dict(os.environ,LOCALAPPDATA=temporary)
    ready=Path(temporary)/'ready.json'
    process=subprocess.Popen([sys.executable,'-c',SERVER,str(ready)],cwd=ROOT/'OUTLOOK',env=env,
                             stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        deadline=time.monotonic()+8
        while not ready.exists() and process.poll() is None and time.monotonic()<deadline:time.sleep(.05)
        if not ready.exists():raise RuntimeError('The Outlook test server did not start.')
        port=json.loads(ready.read_text())['port']
        subprocess.run([sys.executable,'-c',CLIENT,str(port)],cwd=ROOT/'IMSS',env=env,check=True,timeout=15)
    finally:
        try:
            process.communicate('\n',timeout=5)
        except subprocess.TimeoutExpired:
            process.kill();process.communicate()
