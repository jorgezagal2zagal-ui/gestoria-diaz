# IMSS V10.5 y Outlook V14.1: omitir fallo de actualización

Lee CAMBIO_V10_5.md en IMSS o CAMBIO_V14_1.md en Outlook. Se agrega CERRAR y
omitir el fallo de actualización del dispositivo confirmado, conservando el folio.
Para avanzar automáticamente activa la cola. Se conserva la pausa entre cuentas.
Las notas que siguen describen versiones anteriores.

# Gestoría Díaz: dos aplicaciones independientes y conectables

Este paquete contiene **IMSS V10**, basado en el IMSS V9 adjuntado, y **Outlook V14**,
basado en Outlook V13. Cada uno tiene su propio instalador, ventana y pruebas.
No necesita el coordinador anterior. ABRIR_AMBOS.bat solo abre las dos ventanas.

**Estado:** pruebas locales e intercambio entre procesos comprobados. Pendiente probar
las ventanas en Windows, el cifrado DPAPI real, el HONOR, la sesión Microsoft y el
trámite IMSS completo. No se garantiza el funcionamiento de esas integraciones.

## Preparación en Windows

1. Conserva tu ZIP original y respalda los datos locales antes de cambiar de versión.
   No copies contraseñas, PIN, tokens ni bases de clientes al directorio del programa.
2. Extrae ambos ZIP en una misma carpeta: deben quedar dos carpetas hermanas,
   `IMSS` y `OUTLOOK`. También puedes extraer el paquete completo.
3. Usa Python 3.10 o posterior con Tk; las pruebas aquí se ejecutaron con Python 3.12.
4. Ejecuta `OUTLOOK/INSTALAR.bat`: crea un entorno propio, instala las dependencias
   fijadas a las versiones usadas en las pruebas, instala Chromium y ejecuta las pruebas.
5. Ejecuta `IMSS/INSTALAR.bat`: crea su entorno propio y ejecuta las pruebas locales.
   IMSS utiliza la biblioteca estándar; prepara ADB con el botón Instalar ADB si hace falta.
6. Abre `OUTLOOK/ABRIR_OUTLOOK.bat` y `IMSS/ABRIR_BOT.bat`. Cierra versiones anteriores
   que puedan ocupar el enlace o controlar el mismo celular. No abras dos instancias IMSS.

Los instaladores BAT, las ventanas y el Chromium de Windows no se ejecutaron en Linux.
Una instalación fallida conserva su resultado de error; revisa el mensaje antes de seguir.

## Usarlos por separado

- **IMSS:** deja desmarcado Conectar con Outlook. Conecta el HONOR, introduce CURP y
  correo, revisa el Aviso de Privacidad e inicia. Puedes introducir el código manualmente.
- **Outlook:** abre su ventana, importa y selecciona las cuentas que tengas autorización
  de usar. El inicio usa Microsoft oficialmente; las verificaciones de seguridad se
  completan allí. El permiso OAuth es opcional y requiere un Client ID autorizado.

El teléfono puede confirmar su identidad manualmente. No viene ningún PIN incorporado.
Si eliges escribir uno, permanece en memoria salvo que pulses GUARDAR PIN CIFRADO.
El guardado usa DPAPI del usuario Windows; OLVIDAR PIN GUARDADO lo elimina.
El uso automático del PIN está desactivado por defecto.

## Conectarlos y procesar solicitudes

1. Abre Outlook primero; importa tus cuentas en su ventana y selecciona las NUEVAS
   que deban utilizarse. Guarda sus contraseñas cifradas si deseas asignación automática.
2. Activa en Outlook la entrada automática por solicitud IMSS. Configura el remitente
   exacto del código real para la lectura automática; no se inventa un remitente ni se
   aceptan códigos de otra cuenta o anteriores al inicio de la solicitud.
3. En IMSS conecta el HONOR por Wi-Fi. Activa Conectar con Outlook independiente.
   Para usar la cola, introduce una CURP y pulsa AGREGAR CURP. El correo puede quedar
   vacío para que Outlook asigne una cuenta. Si escribes un correo, se conserva esa elección.
4. Revisa el Aviso de Privacidad y activa Procesar cola. El arranque no requiere otro
   clic cuando teléfono y sesión Outlook están disponibles. Los reintentos del enlace
   esperan entre 2 y 30 segundos; no generan nuevos folios al perderse una respuesta.
5. El folio, la CURP cifrada y el correo asignado se conservan ante fallos. DETENER
   apaga la cola y evita que una preparación tardía inicie el teléfono. Una interrupción
   incierta queda en REQUIERE_ATENCION; no se repite automáticamente.
6. Una vez confirmado el envío por IMSS, revisa el correo/PDF. La sesión Outlook no se
   cierra automáticamente para no perder esa revisión: ciérrala desde su botón cuando
   termines. Se conserva la espera de seguridad de 60 segundos entre sesiones.
   Esa espera, una sesión abierta o Microsoft 429 pueden detener el siguiente folio
   aunque el teléfono ya esté libre; la interfaz no los declara terminados.

Si no deseas la cola, INICIAR TRÁMITE también permite conectar una sola solicitud.
La conexión es local, entre el mismo equipo y usuario Windows; no expone servicios
al celular ni a Internet. El teléfono se comunica con IMSS mediante ADB Wi-Fi.

## Errores, correo y autorizaciones

- Selecciona un folio REQUIERE_ATENCION y pulsa REVISAR FOLIO solo después de comprobar
  el HONOR y devolver el trámite al inicio. Se libera la reserva anterior de Outlook
  antes de crear otro intento; no se cancela el folio de otra persona.
- CAMBIAR CORREO DEL FOLIO conserva la CURP y el folio. Requiere tu confirmación y
  una lectura reciente que identifique ACCESO con campos CURP/correo. Se bloquea
  en pantallas de código, identidad o vinculación y ante lecturas inciertas.
  El correo nuevo debe estar preparado en Outlook si deseas su inicio automático.
- AUTORIZAR CAMBIO DE DISPOSITIVO exige autorización expresa del titular de ESA
  solicitud. Comprueba de nuevo el aviso específico y permite un solo intento por
  flujo. Reanudar no concede otra autorización. Si no se confirma avance, revisa
  el HONOR; no se asegura que el cambio haya terminado.
- No se omiten PIN, identidad, MFA ni CAPTCHA, ni se rota automáticamente ante 429.
- Si Outlook se cierra, revisa el diagnóstico técnico. La causa específica del cierre
  previamente observado sigue sin reproducirse con la cuenta/dispositivo reales.

## Pruebas y diagnóstico

Ejecuta PRUEBAS.bat en cada aplicación, o `python validar.py` con sus dependencias.
El paquete completo permite `python probar_ambos.py`: inicia un servidor Outlook y
un cliente IMSS en procesos distintos, con HTTP real y datos ficticios. La escritura
al teléfono se simula. No introduce solicitudes en cuentas reales ni consulta clientes.

Los eventos técnicos rotan en `%LOCALAPPDATA%/GestoriaDiaz/Diagnostico/`.
Registran hora, tipo de error y ubicaciones de código; no guardan mensajes de excepción,
variables locales, CURP, cuentas, PIN ni códigos. El diagnóstico del motor Outlook en
el directorio personal se mantiene en `GestoriaDiaz_Outlook_error.txt`, ahora en JSON
sin mensajes completos de excepción. Revisa registros históricos antes de compartirlos.

No se incluye recepción por WhatsApp/Telegram, entrega a clientes, validación automática
de identidad del PDF ni descarga desde correos reales comprobada. La extracción de
PDF del celular conserva el mecanismo original y requiere selección manual.
