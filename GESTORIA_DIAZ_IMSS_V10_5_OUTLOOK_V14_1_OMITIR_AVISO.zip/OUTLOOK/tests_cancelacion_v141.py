"""Release only an auto-started canceled folio; preserve browser engine and cooldown."""
from types import SimpleNamespace
from unittest.mock import Mock
import unittest
from app import App
from navegador import BrowserLogin

class CancelledRequest(unittest.TestCase):
    def panel(self):
        f=SimpleNamespace(auto_queue=Mock(get=lambda:True),_auto_started_request='a'*32,
            active_email='synthetic@example.invalid',browser=BrowserLogin(Mock()),cooldown=Mock(),
            info=Mock(),link_status=Mock())
        f.browser.running=True
        f.close_private=lambda:App.close_private(f)
        return f
    def state(self):return {'status':'CANCELADA','request_id':'a'*32,'email':'synthetic@example.invalid'}
    def test_canceled_auto_request_stops_own_session_once_using_existing_cooldown(self):
        f=self.panel();state=self.state()
        App._finish_cancelled_request(f,state);App._finish_cancelled_request(f,state)
        self.assertTrue(f.browser.stop_event.is_set());f.cooldown.begin.assert_called_once()
        self.assertIsNone(f._auto_started_request)
    def test_manual_disabled_or_different_folio_and_account_remain_open(self):
        for variant in ('manual','disabled','folio','email','active'):
            f=self.panel();state=self.state()
            if variant=='manual':f._auto_started_request=None
            elif variant=='disabled':f.auto_queue=Mock(get=lambda:False)
            elif variant=='folio':state['request_id']='b'*32
            elif variant=='email':state['email']='other@example.invalid'
            else:state['status']='ESPERANDO_CODIGO'
            App._finish_cancelled_request(f,state)
            self.assertFalse(f.browser.stop_event.is_set());f.cooldown.begin.assert_not_called()
    def test_rate_limit_is_preserved_and_still_blocks_following_reservation(self):
        f=self.panel();f.browser.rate_limited=True
        App._finish_cancelled_request(f,self.state());self.assertTrue(f.browser.rate_limited)
        f.browser.running=False;f._auto_queue_enabled=Mock(is_set=lambda:True)
        self.assertFalse(App._reservation_available(f))
    def test_closed_auto_browser_does_not_restart_or_extend_cooldown(self):
        f=self.panel();f.browser.running=False
        App._finish_cancelled_request(f,self.state())
        f.cooldown.begin.assert_not_called();self.assertFalse(f.browser.stop_event.is_set())

if __name__=='__main__':unittest.main()
