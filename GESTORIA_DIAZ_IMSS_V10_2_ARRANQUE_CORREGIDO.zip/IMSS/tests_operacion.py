import io, json, os, tempfile, threading, unittest, zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from instalar_adb import install_archive
from solicitudes import Requests
from panel import IMSSPanel
import diagnostico

class Protector:
    def protect(self,s):return bytes(value^0xAA for value in s.encode())
    def unprotect(self,s):return bytes(value^0xAA for value in s).decode()

class QueueRecovery(unittest.TestCase):
    def test_encrypted_request_survives_mail_failure_and_restart(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'jobs.db';store=Requests(Protector(),path)
            jid=store.enqueue('AAAA000101HDFBBB01')
            store.set(jid,'ESPERANDO_CODIGO',email='one@example.com')
            self.assertNotIn(b'AAAA000101HDFBBB01',path.read_bytes())
            reopened=Requests(Protector(),path);reopened.recover();reopened.recover()
            self.assertEqual(reopened.get(jid)['status'],'REQUIERE_ATENCION')
            self.assertEqual(reopened.get(jid)['curp'],'AAAA000101HDFBBB01')
            reopened.skip_email(jid,'one@example.com')
            reopened.set(jid,'PENDIENTE',email='two@example.com')
            self.assertEqual(reopened.get(jid)['id'],jid)
            self.assertEqual(reopened.get(jid)['curp'],'AAAA000101HDFBBB01')
    def test_reserved_pending_job_requires_review_after_crash(self):
        with tempfile.TemporaryDirectory() as d:
            store=Requests(Protector(),Path(d)/'jobs.db');jid=store.enqueue('AAAA000101HDFBBB01')
            store.set(jid,'PENDIENTE',link_id='a'*32)
            store.recover()
            self.assertEqual(store.get(jid)['status'],'REQUIERE_ATENCION')
            self.assertEqual(store.get(jid)['link_id'],'a'*32)
    def test_completed_job_is_not_recovered_or_replayed(self):
        with tempfile.TemporaryDirectory() as d:
            s=Requests(Protector(),Path(d)/'jobs.db');jid=s.enqueue('AAAA000101HDFBBB01')
            s.set(jid,'SOLICITUD_ENVIADA');s.recover()
            self.assertEqual(s.get(jid)['status'],'SOLICITUD_ENVIADA')
            self.assertEqual(s.oldest_pending(),(None,None))

class QueueDispatch(unittest.TestCase):
    def ready(self):
        rows=[{'id':'folio','status':'PENDIENTE'}]
        store=Mock();store.oldest_pending.return_value=('folio','AAAA000101HDFBBB01');store.get.return_value={'email':''}
        return SimpleNamespace(queue_enabled=Mock(get=lambda:True),running=False,_dispatch_busy=False,_closed=False,
            connected=True,accept_privacy=Mock(get=lambda:True),_next_queue_check=0,
            _refresh_jobs=Mock(return_value=rows),_jobs=lambda:store,link_enabled=Mock(get=lambda:True),
            queue_status=Mock(),_prepare=Mock())
    def test_free_phone_dispatches_without_another_button(self):
        f=self.ready();IMSSPanel._queue_tick(f)
        f._prepare.assert_called_once_with('AAAA000101HDFBBB01','','folio')
    def test_busy_phone_and_missing_privacy_do_not_dispatch(self):
        for name in ('running','_dispatch_busy','privacy'):
            f=self.ready()
            if name=='privacy':f.accept_privacy=Mock(get=lambda:False)
            else:setattr(f,name,True)
            IMSSPanel._queue_tick(f);f._prepare.assert_not_called()
    def test_unreviewed_failure_blocks_the_queue(self):
        f=self.ready();f._refresh_jobs.return_value=[{'status':'REQUIERE_ATENCION'}]
        IMSSPanel._queue_tick(f);f._prepare.assert_not_called()
    def test_prepared_job_keeps_its_session_through_flow_start(self):
        store=Mock();session=SimpleNamespace(email='one@example.com')
        f=SimpleNamespace(_dispatch_busy=True,_prepare_generation=0,_jobs=lambda:store,
            curp=Mock(),email=Mock(),start=Mock(return_value=True),_refresh_jobs=Mock())
        IMSSPanel._on_prepared(f,'folio','AAAA000101HDFBBB01','',session,generation=0)
        self.assertEqual(f._current_job,'folio');self.assertIs(f._session,session)
        self.assertEqual(f._prepared_form,('AAAA000101HDFBBB01','one@example.com'))
        f.start.assert_called_once()
    def test_prepared_job_that_cannot_start_requires_review(self):
        store=Mock();f=SimpleNamespace(_dispatch_busy=True,_prepare_generation=0,_jobs=lambda:store,
            curp=Mock(),email=Mock(),start=Mock(return_value=False),_refresh_jobs=Mock())
        IMSSPanel._on_prepared(f,'folio','AAAA000101HDFBBB01','one@example.com',None,generation=0)
        self.assertIsNone(f._current_job);self.assertIsNone(f._session)
        self.assertEqual(store.set.call_args.args[:2],('folio','REQUIERE_ATENCION'))
    def test_stop_invalidates_in_flight_preparation(self):
        store=Mock()
        f=SimpleNamespace(_dispatch_busy=True,_prepare_generation=2,_jobs=lambda:store,queue_status=Mock(),start=Mock())
        session=SimpleNamespace(email='one@example.com')
        IMSSPanel._on_prepared(f,'folio','AAAA000101HDFBBB01','',session,generation=1)
        f.start.assert_not_called()
        self.assertEqual(store.set.call_args.args[:2],('folio','REQUIERE_ATENCION'))
    def test_ui_error_does_not_kill_future_flushes(self):
        f=SimpleNamespace(_flush_once=Mock(side_effect=RuntimeError('private exception')),
            _queue_tick=Mock(),running=True,stop=threading.Event(),advance=threading.Event(),
            _closed=False,root=Mock(),flush=Mock())
        with patch('panel.record') as record:IMSSPanel.flush(f)
        self.assertTrue(f.stop.is_set());record.assert_called_once()
        f.root.after.assert_called_once_with(170,f.flush)
    def test_denied_device_consent_never_queries_phone(self):
        f=SimpleNamespace(flow=SimpleNamespace(transfer_attempted=False),connected=True,adb=Mock(),_thread=Mock(),
            _transfer_busy=False,_prepare_generation=0,root=Mock(),status=Mock())
        f._set_transfer_busy=lambda value:setattr(f,'_transfer_busy',value)
        with patch('panel.messagebox.askyesno',return_value=False):IMSSPanel.authorize_transfer(f)
        f._thread.assert_not_called();f.adb.hierarchy.assert_not_called()
    def test_retry_preparation_reuses_folio_after_lost_response(self):
        pending=Mock();f=SimpleNamespace(_dispatch_busy=False,link_enabled=Mock(get=lambda:True),
            _pending_session=pending,_pending_identity=('job','CURP',''),_prepare_generation=0,_jobs=lambda:Mock(),
            queue_status=Mock(),_thread=Mock())
        IMSSPanel._prepare(f,'CURP','','job')
        worker=f._thread.call_args.args[0]
        f.put=Mock();worker();pending.prepare.assert_called_once()
        self.assertIs(f.put.call_args.args[1][3],pending)

class FlowWakeups(unittest.TestCase):
    def test_manual_response_during_preview_is_not_lost(self):
        from adb_imss import APP_PACKAGE
        class CheckedEvent(threading.Event):
            def wait(self,timeout=None):
                if not self.is_set():raise AssertionError('A manual response was erased before waiting')
                return True
        advance=CheckedEvent()
        adb=Mock();adb.packages.return_value=APP_PACKAGE;adb.hierarchy.return_value=[]
        adb.screenshot.side_effect=lambda:(advance.set() or b'preview')
        flow=SimpleNamespace(step=Mock(side_effect=['code','finished']),pause_reason='code required')
        f=SimpleNamespace(_current_job=None,_session=None,lock=threading.Lock(),_try_unlock_if_locked=Mock(),
            adb=adb,stop=threading.Event(),advance=advance,flow=flow,put=Mock(),log_line=Mock())
        with patch('panel.time.sleep'),patch('panel.record'):
            IMSSPanel.run_flow(f)
        self.assertIn(unittest.mock.call('flow_end',(None,'finished')),f.put.call_args_list)
        self.assertEqual(flow.step.call_count,2)

class MailReplacement(unittest.TestCase):
    def fake(self):
        store=Mock();store.get.return_value={'status':'REQUIERE_ATENCION','email':'old@example.com'}
        return SimpleNamespace(_jobs=lambda:store,running=False,_dispatch_busy=True,
            queue_status=Mock(),_release_job_link=Mock(),_refresh_jobs=Mock()),store
    def test_confirmed_access_changes_only_mail_on_same_folio(self):
        f,store=self.fake();IMSSPanel._on_email_change_ready(f,'folio','old@example.com','new@example.com',True)
        f._release_job_link.assert_called_once_with('folio')
        store.skip_email.assert_called_once_with('folio','old@example.com')
        store.set.assert_called_once_with('folio','PENDIENTE',email='new@example.com',error='')
    def test_code_screen_or_identity_never_changes_email(self):
        f,store=self.fake();IMSSPanel._on_email_change_ready(f,'folio','old@example.com','new@example.com',False)
        f._release_job_link.assert_not_called();store.set.assert_not_called()
    def test_releasing_a_reservation_never_cancels_another_folio(self):
        from enlace import LinkError
        store=Mock();store.get.return_value={'link_id':'a'*32,'status':'REQUIERE_ATENCION'}
        f=SimpleNamespace(_jobs=lambda:store,_pending_identity=None)
        with patch('panel.Client') as client:
            client.return_value.status.return_value={'request_id':'b'*32,'status':'ESPERANDO_CODIGO'}
            with self.assertRaises(LinkError):IMSSPanel._release_job_link(f,'folio')
            client.return_value.cancel.assert_not_called();store.set.assert_not_called()
    def test_operator_stop_disables_queue_and_wakes_paused_flow(self):
        f=SimpleNamespace(_prepare_generation=3,queue_enabled=Mock(),stop=threading.Event(),
            advance=threading.Event(),phone_pin=Mock(),put=Mock())
        IMSSPanel.halt(f)
        self.assertEqual(f._prepare_generation,4);f.queue_enabled.set.assert_called_once_with(False)
        self.assertTrue(f.stop.is_set());self.assertTrue(f.advance.is_set())

class InputValidation(unittest.TestCase):
    def test_non_ascii_and_out_of_range_ports_rejected(self):
        from panel import valid_port
        for value in ('²','１２３','0','65536','1;exit','-1',''):
            self.assertFalse(valid_port(value))
        self.assertTrue(valid_port('65535'));self.assertTrue(valid_port('1'))
    def test_invalid_curp_never_reserves_account(self):
        from adb_imss import DeviceError
        f=SimpleNamespace(email=Mock(get=lambda:'one@example.com'),curp=Mock(get=lambda:'A'*18))
        with self.assertRaises(DeviceError):IMSSPanel.validate_input(f)

class Installer(unittest.TestCase):
    def archive(self,entries):
        stream=io.BytesIO()
        with zipfile.ZipFile(stream,'w') as z:
            for name,data in entries:z.writestr(name,data)
        return stream.getvalue()
    def test_complete_install_and_existing_copy_preserved(self):
        data=self.archive([('platform-tools/adb.exe',b'synthetic exe'),('platform-tools/lib.dll',b'library')])
        with tempfile.TemporaryDirectory() as d:
            target=install_archive(data,d);self.assertEqual((target/'adb.exe').read_bytes(),b'synthetic exe')
            with self.assertRaises(ValueError):install_archive(data,d)
            self.assertEqual((target/'lib.dll').read_bytes(),b'library')
    def test_traversal_and_missing_executable_leave_no_partial_install(self):
        for entries in ([('platform-tools/../outside',b'x')],[('platform-tools/other',b'x')],
                        [('platform-tools/adb.exe',b'x'),('platform-tools/..\\outside',b'y')]):
            with tempfile.TemporaryDirectory() as d:
                with self.assertRaises(ValueError):install_archive(self.archive(entries),d)
                self.assertEqual(list(Path(d).iterdir()),[])
    def test_corrupt_archive_is_not_installed(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(zipfile.BadZipFile):install_archive(b'not a zip',d)
            self.assertEqual(list(Path(d).iterdir()),[])

if __name__=='__main__':unittest.main()
