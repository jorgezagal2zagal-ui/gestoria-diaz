"""Synthetic controls only; no personal data from screenshots or device access."""
import threading, unittest
from types import SimpleNamespace
from unittest.mock import Mock,patch
from adb_imss import ADB,IMSSFlow,Node,DeviceError
from panel import IMSSPanel

def button(text='',rid='',bounds=(150,140,320,190),enabled=True,clazz='android.widget.Button',clickable=True):
    return Node(text,'',rid,clazz,bounds,clickable,enabled)
def dialog(positive):
    return [Node('Esta CURP está vinculada a otro dispositivo. ¿Deseas hacer el cambio?','','',
                 'android.widget.TextView',(10,10,340,130)),button('NO',bounds=(10,140,130,190)),positive]

class ButtonRecognition(unittest.TestCase):
    def setUp(self):self.adb=Mock();self.flow=IMSSFlow(self.adb,'','',Mock())
    def test_dialog_and_exact_caption_from_photo_send_adb_tap_to_yes_not_no(self):
        # Only public dialog text is reproduced. Bounds are synthetic, not photo coordinates.
        adb=ADB('synthetic-adb','synthetic-phone');adb.run=Mock(return_value='')
        flow=IMSSFlow(adb,'','',Mock())
        negative=button('NO',rid='android:id/button2',bounds=(10,200,130,250))
        affirmative=button('SÍ, QUIERO HACER EL CAMBIO',rid='android:id/button1',bounds=(150,200,400,250))
        nodes=[Node('IMSS Digital','','','android.widget.TextView',(10,10,400,60)),
               Node('Esta CURP está vinculada a otro dispositivo móvil ¿Deseas vincularla a este?',
                    '','','android.widget.TextView',(10,70,400,190)),negative,affirmative]
        self.assertTrue(flow.device_transfer_dialog(nodes))
        self.assertIs(flow.transfer_button(nodes),affirmative)
        flow.authorize_device_change(nodes,consent=True)
        adb.run.assert_called_once_with('shell','input','tap',affirmative.cx,affirmative.cy,timeout=12)
        self.assertNotEqual(affirmative.cx,negative.cx)
    def test_wrapping_punctuation_and_short_affirmative_are_recognized(self):
        for label in ('Sí, quiero hacer el cambio','SÍ\nQUIERO HACER EL CAMBIO','SI','Sí: quiero hacer el cambio'):
            with self.subTest(label=label):
                nodes=dialog(button(label));target=self.flow.transfer_button(nodes)
                self.assertIs(target,nodes[-1])
    def test_unlabelled_android_positive_control_is_supported(self):
        nodes=dialog(button(rid='android:id/button1'))
        self.assertIs(self.flow.transfer_button(nodes),nodes[-1])
    def test_negative_text_wins_over_positive_resource_id(self):
        nodes=dialog(button('NO',rid='android:id/button1'))
        with self.assertRaises(DeviceError):self.flow.authorize_device_change(nodes,consent=True)
        self.adb.tap_node.assert_not_called()
    def test_disabled_ambiguous_or_text_only_controls_are_not_tapped(self):
        cases=[dialog(button('SÍ',enabled=False)),
               dialog(button('SÍ'))+[button('SÍ',bounds=(140,210,320,260))],
               dialog(button('SÍ',clazz='android.widget.TextView',clickable=False))]
        for nodes in cases:
            with self.subTest(nodes=len(nodes)):
                with self.assertRaises(DeviceError):self.flow.authorize_device_change(nodes,consent=True)
        self.adb.tap_node.assert_not_called()
    def test_matching_label_without_specific_dialog_is_not_tapped(self):
        with self.assertRaises(DeviceError):self.flow.authorize_device_change([button('SI')],consent=True)
        self.adb.tap_node.assert_not_called()
    def test_partial_adb_failure_still_does_not_repeat_the_touch(self):
        nodes=dialog(button('SÍ'));self.adb.tap_node.side_effect=DeviceError('partial transport failure')
        with self.assertRaises(DeviceError):self.flow.authorize_device_change(nodes,consent=True)
        with self.assertRaises(DeviceError):self.flow.authorize_device_change(nodes,consent=True)
        self.adb.tap_node.assert_called_once()
    def test_no_automatic_action_without_explicit_consent(self):
        nodes=dialog(button('SÍ'))
        self.assertEqual(self.flow.step(nodes),'paused')
        with self.assertRaises(DeviceError):self.flow.authorize_device_change(nodes)
        self.adb.tap_node.assert_not_called()

class PanelAuthorization(unittest.TestCase):
    def fake(self,after=None):
        adb=Mock();nodes=dialog(button('SI',rid='android:id/button1'))
        adb.hierarchy.side_effect=[nodes,after if after is not None else nodes]
        flow=IMSSFlow(adb,'','',Mock())
        f=SimpleNamespace(_transfer_busy=False,connected=True,adb=adb,flow=flow,_prepare_generation=1,
            stop=threading.Event(),advance=threading.Event(),root=Mock(),status=Mock(),lock=threading.Lock(),
            put=Mock(),log_line=Mock(),_thread=lambda fn:fn())
        f._set_transfer_busy=lambda busy:IMSSPanel._set_transfer_busy(f,busy)
        return f
    def run_button(self,f,consent=True):
        with patch('panel.messagebox.askyesno',return_value=consent) as ask,patch('panel.time.sleep'),patch('panel.record'):
            IMSSPanel.authorize_transfer(f)
        return ask
    def apply_result(self,f):
        args=f.put.call_args.args
        self.assertEqual(args[0],'transfer_result')
        IMSSPanel._on_transfer_result(f,*args[1])
    def test_confirmation_is_parented_and_decline_does_not_touch_phone(self):
        f=self.fake();ask=self.run_button(f,False)
        self.assertIs(ask.call_args.kwargs['parent'],f.root)
        f.adb.hierarchy.assert_not_called();f.adb.tap_node.assert_not_called()
        self.assertFalse(f._transfer_busy);f.status.set.assert_called()
    def test_no_connection_or_no_flow_shows_explanation(self):
        for disconnected in (True,False):
            f=self.fake()
            if disconnected:f.connected=False
            else:f.flow=None
            with patch('panel.messagebox.showwarning') as warning,patch('panel.messagebox.showinfo') as info:
                IMSSPanel.authorize_transfer(f)
            self.assertEqual(warning.call_count+info.call_count,1)
            f.status.set.assert_called();f.adb.hierarchy.assert_not_called()
    def test_still_visible_dialog_does_not_report_completion_or_repeat(self):
        f=self.fake();self.run_button(f);self.apply_result(f)
        f.adb.tap_node.assert_called_once();self.assertFalse(f.advance.is_set())
        self.assertIn('sigue visible',f.status.set.call_args.args[0])
        with patch('panel.messagebox.showwarning'):self.run_button(f)
        f.adb.tap_node.assert_called_once()
    def test_known_next_screen_resumes_same_flow(self):
        after=[Node('Validación de identidad','Confirma tu identidad','','android.widget.TextView',(10,10,300,100))]
        f=self.fake(after);self.run_button(f)
        self.assertFalse(f.advance.is_set())
        self.apply_result(f);self.assertTrue(f.advance.is_set())
        f.adb.tap_node.assert_called_once()
    def test_unknown_or_unreadable_next_screen_requires_review(self):
        for after in ([],[Node('Cargando','','','android.widget.TextView',(10,10,300,100))]):
            f=self.fake(after);self.run_button(f);self.apply_result(f)
            self.assertFalse(f.advance.is_set());self.assertIn('No pude confirmar',f.status.set.call_args.args[0])
    def test_changed_flow_while_confirmation_is_open_is_not_authorized(self):
        f=self.fake();f._thread=Mock()
        def changed(*args,**kwargs):f.flow=IMSSFlow(f.adb,'','',Mock());return True
        with patch('panel.messagebox.askyesno',side_effect=changed):IMSSPanel.authorize_transfer(f)
        f._thread.assert_not_called();f.adb.tap_node.assert_not_called();self.assertFalse(f._transfer_busy)
    def test_duplicate_clicks_start_one_worker(self):
        f=self.fake();f._thread=Mock()
        with patch('panel.messagebox.askyesno',return_value=True) as ask,patch('panel.record'):
            IMSSPanel.authorize_transfer(f);IMSSPanel.authorize_transfer(f)
        ask.assert_called_once();f._thread.assert_called_once();f.adb.tap_node.assert_not_called()
    def test_adb_lock_timeout_is_visible_and_sends_no_touch(self):
        f=self.fake();f.lock=Mock();f.lock.acquire.return_value=False
        self.run_button(f);self.apply_result(f)
        self.assertIn('ocupado',f.status.set.call_args.args[0]);f.adb.tap_node.assert_not_called()
        f.lock.release.assert_not_called()
    def test_thread_failure_reenables_button_and_reports_no_touch(self):
        f=self.fake();f._thread=Mock(side_effect=RuntimeError('no worker'))
        self.run_button(f)
        self.assertFalse(f._transfer_busy);f.adb.tap_node.assert_not_called()
        self.assertIn('No se pudo iniciar',f.status.set.call_args.args[0])

if __name__=='__main__':unittest.main()
