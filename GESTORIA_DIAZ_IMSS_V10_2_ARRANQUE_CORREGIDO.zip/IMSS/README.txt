IMSS V10.2: arranque independiente con correo escrito.
Lee CAMBIO_V10_2.md. Ejecuta ABRIR_BOT.bat.
Si falla Outlook, IMSS continúa con código manual; se indica en el panel.
Para automatización, abre también Outlook V14 y prepara sus cuentas.
107 pruebas locales superadas; falta validar el arranque y el clic reales en HONOR.
No incluye PIN ni datos personales de las capturas.
