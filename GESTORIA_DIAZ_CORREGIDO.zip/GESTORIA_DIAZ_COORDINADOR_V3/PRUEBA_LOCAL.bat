@echo off
cd /d "%~dp0"
py -3 PROBAR_CONEXION_LOCAL.py
pause
