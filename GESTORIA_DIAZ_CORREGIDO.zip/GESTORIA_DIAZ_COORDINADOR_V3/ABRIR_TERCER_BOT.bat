@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% "COORDINADOR.py"
if errorlevel 1 (
 echo.
 echo Hubo un error. Revisa el mensaje anterior.
 pause
)
