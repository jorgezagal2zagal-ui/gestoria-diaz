@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title GESTORIA DIAZ - IMSS SIMPLE + OUTLOOK
if exist "platform-tools\adb.exe" goto run
if exist "RUTA_ADB.txt" goto run
if exist "%LOCALAPPDATA%\GestoriaDiaz\Android\platform-tools\adb.exe" goto run
if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" goto run
where adb.exe >nul 2>nul && goto run
echo.
echo  Preparando ADB automaticamente por primera vez...
echo  Si ya lo instalaste, el programa intentara encontrarlo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\PREPARAR_ADB.ps1" -Destino "%~dp0platform-tools\adb.exe"
if errorlevel 1 (
  echo.
  echo No se pudo preparar ADB. Consulta LEEME.txt.
  pause
  exit /b 1
)
:run
where py >nul 2>nul
if not errorlevel 1 (
   py -3 "%~dp0app.py"
) else (
   python "%~dp0app.py"
)
if errorlevel 1 (
   echo.
   echo El programa no inicio. Requiere Python 3 con tkinter.
   echo Revisa que Python este instalado: https://www.python.org/downloads/windows/
   pause
)
