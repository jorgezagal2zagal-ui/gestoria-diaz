# -*- coding: utf-8 -*-
"""Pruebas locales sin acceder a IMSS ni a Microsoft."""
import importlib, os, sqlite3, sys, tempfile, pathlib, unittest
from unittest.mock import patch
from outlook_queue_reader import next_new_selected

class TestQueue(unittest.TestCase):
    def test_missing_db(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(next_new_selected(d),(None,0))
            self.assertFalse(pathlib.Path(d,'GestoriaDiaz','OutlookV1','cola_simple.sqlite3').exists())

    def test_selected_new_in_import_order(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d,'GestoriaDiaz','OutlookV1','cola_simple.sqlite3')
            p.parent.mkdir(parents=True)
            with sqlite3.connect(p) as db:
                db.execute('CREATE TABLE correo (n INTEGER PRIMARY KEY, email TEXT UNIQUE, estado TEXT, seleccionado INTEGER)')
                db.executemany('INSERT INTO correo(email,estado,seleccionado) VALUES (?,?,?)',[
                    ('used@example.com','USADO',1),('skip@example.com','NUEVO',0),
                    ('new1@example.com','NUEVO',1),('new2@example.com','NUEVO',1)])
            self.assertEqual(next_new_selected(d),('new1@example.com',2))
            with sqlite3.connect(p) as db:
                db.execute("UPDATE correo SET estado='USADO' WHERE email='new1@example.com'")
            self.assertEqual(next_new_selected(d),('new2@example.com',1))
            with sqlite3.connect(p) as db:
                self.assertEqual(db.execute('SELECT COUNT(*) FROM correo').fetchone()[0],4)
                self.assertEqual(db.execute("SELECT estado FROM correo WHERE email='new2@example.com'").fetchone()[0],'NUEVO')

    def test_selected_none(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d,'GestoriaDiaz','OutlookV1','cola_simple.sqlite3');p.parent.mkdir(parents=True)
            with sqlite3.connect(p) as db:
                db.execute('CREATE TABLE correo (n INTEGER PRIMARY KEY, email TEXT, estado TEXT, seleccionado INTEGER)')
                db.execute("INSERT INTO correo VALUES(1,'used@example.com','USADO',1)")
            self.assertEqual(next_new_selected(d),(None,0))

class TestCompatibility(unittest.TestCase):
    def test_shared_link_file_compatible(self):
        import enlace
        self.assertTrue(callable(enlace.Client))
        self.assertTrue(hasattr(enlace.State,'put_code'))
        self.assertEqual(enlace.PORT,8797)

    def test_ui_module_importable(self):
        from app import App
        self.assertTrue(callable(App._send_link_code))
        self.assertTrue(callable(App.do_device_change))
        self.assertTrue(callable(App.pick_next_email))
        self.assertTrue(callable(App._await_code_result))

    def test_device_change_never_auto(self):
        from app import App
        class Fake:
            pass
        # Llamada de control automát. a este método jamás autoriza cambio por sí misma.
        result=App.do_device_change(Fake(),[],manual=False)
        self.assertIn('Confirma con el titular',result)

if __name__=='__main__':unittest.main(verbosity=2)
