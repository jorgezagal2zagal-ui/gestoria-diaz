"""Sondeo seguro del avance del IMSS. No ejecuta acciones ni escribe códigos."""
import time


def wait_for_screen_change(read_nodes, classify, old_stage, stopped,
                           timeout=7.0, interval=0.15, clock=None, sleep=None):
    """Devuelve (nodos, nueva_etapa) en el primer estado reconocible diferente.

    Ignora pantallas de carga sin accesibilidad ('DESCONOCIDA'). Si no hay
    transición dentro del plazo, devuelve None: la aplicación nunca debe
    repetir a ciegas el toque que acaba de enviar.
    """
    clock = clock or time.monotonic
    sleep = sleep or time.sleep
    end = clock() + timeout
    while not stopped() and clock() < end:
        sleep(min(interval, max(0.0, end - clock())))
        if stopped():
            return None
        nodes = read_nodes()
        name = classify(nodes)
        if name != old_stage and name != 'DESCONOCIDA':
            return nodes, name
    return None
