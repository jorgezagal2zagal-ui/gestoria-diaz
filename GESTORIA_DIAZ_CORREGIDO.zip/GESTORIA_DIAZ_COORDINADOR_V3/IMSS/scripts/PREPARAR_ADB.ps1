param([Parameter(Mandatory=$true)][string]$Destino)
$ErrorActionPreference = 'Stop'
$root = Split-Path (Split-Path $Destino -Parent) -Parent
$known = @(
  (Join-Path $root 'platform-tools\adb.exe'),
  (Join-Path $env:LOCALAPPDATA 'GestoriaDiaz\Android\platform-tools\adb.exe'),
  (Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe'),
  (Join-Path $env:LOCALAPPDATA 'platform-tools\adb.exe'),
  'C:\platform-tools\adb.exe',
  'C:\adb\adb.exe'
)
$found = $null
foreach ($candidate in $known) {
  if (Test-Path -LiteralPath $candidate -PathType Leaf) { $found=$candidate; break }
}
if (-not $found) {
  $cmd = Get-Command adb.exe -ErrorAction SilentlyContinue
  if ($cmd) { $found = $cmd.Source }
}
if ($found) {
  Write-Host "ADB existente: $found"
  # Dejamos su ruta en un archivo de texto, sin duplicar ni alterar la instalacion.
  Set-Content -LiteralPath (Join-Path $root 'RUTA_ADB.txt') -Value $found -Encoding UTF8
  & $found version | Select-Object -First 2
  exit 0
}
Write-Host 'ADB no encontrado. Se intentara descargar desde Google una sola vez.'
Write-Host 'Herramientas oficiales y licencia: https://developer.android.com/tools/releases/platform-tools'
Write-Host 'Continuar implica que aceptas los terminos correspondientes del SDK de Android.'
$archive = Join-Path $env:TEMP 'gestoria_adb_google.zip'
$extract = Join-Path $env:TEMP ('gestoria_adb_' + [guid]::NewGuid().ToString('N'))
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  Invoke-WebRequest 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile $archive -UseBasicParsing -TimeoutSec 90
  if ((Get-Item $archive).Length -lt 100000) { throw 'La descarga esta incompleta.' }
  Expand-Archive -Path $archive -DestinationPath $extract -Force
  $src = Join-Path $extract 'platform-tools'
  if (-not (Test-Path (Join-Path $src 'adb.exe'))) { throw 'No aparece adb.exe en el ZIP oficial.' }
  Copy-Item -LiteralPath $src -Destination (Join-Path $root 'platform-tools') -Recurse -Force
  $exe = Join-Path $root 'platform-tools\adb.exe'
  Set-Content -LiteralPath (Join-Path $root 'RUTA_ADB.txt') -Value $exe -Encoding UTF8
  & $exe version | Select-Object -First 2
  Write-Host 'ADB listo junto al bot.'
  exit 0
} catch {
  Write-Host "No se pudo instalar ADB: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host 'Instalalo desde https://developer.android.com/tools/releases/platform-tools'
  exit 1
} finally {
  Remove-Item $archive -Force -ErrorAction SilentlyContinue
  Remove-Item $extract -Recurse -Force -ErrorAction SilentlyContinue
}
