# -*- coding: utf-8 -*-
"""Enlace LOCAL IMSS <-> Outlook. Solo escucha en 127.0.0.1. Sin nube.

No guarda los códigos ni contraseñas en disco. Clave compartida restringida
al perfil del usuario actual de Windows. Se requiere mismo usuario y equipo.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import json, os, re, secrets, threading, time

EMAIL = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
BASE = Path(os.environ.get('LOCALAPPDATA') or str(Path.home()))/'GestoriaDiaz'/'EnlaceIMSS_Outlook'
KEYFILE = BASE/'clave_local.txt'
HOST, PORT = '127.0.0.1', 8797

def shared_key():
    BASE.mkdir(parents=True, exist_ok=True)
    try:
        with KEYFILE.open('x',encoding='utf-8') as f:
            f.write(secrets.token_urlsafe(48))
        try: os.chmod(KEYFILE,0o600)
        except OSError: pass
    except FileExistsError:
        pass
    value=KEYFILE.read_text(encoding='utf-8').strip()
    if len(value)<40:
        raise RuntimeError('La clave local no es válida. Revísala en la carpeta del usuario.')
    return value

class LinkError(RuntimeError): pass

class State:
    def __init__(self):
        self.lock=threading.RLock(); self.job=None

    def start(self, email, request_id):
        email=email.strip().lower()
        if not EMAIL.fullmatch(email): raise ValueError('Correo inválido')
        if not re.fullmatch('[0-9a-f]{32}',request_id): raise ValueError('Solicitud inválida')
        with self.lock:
            self.job={'email':email,'id':request_id,'started':datetime.now(timezone.utc).isoformat(),
                      'code':None,'status':'ESPERANDO_CODIGO','created':time.monotonic(),
                      'sent_at':0, 'document_ready':False}
            return self.status(request_id)

    def status(self,request_id=None):
        with self.lock:
            j=self.job
            if not j: return {'status':'SIN_SOLICITUD','email':None,'code':None}
            if request_id and request_id!=j['id']: raise ValueError('Solicitud diferente')
            expired = time.monotonic()-j['created']>900
            if expired:
                j['code']=None;j['status']='CADUCADA'
            return {'status':j['status'],'email':j['email'],'request_id':j['id'],
                    'started':j['started'],'code':j['code'],
                    'document_ready':j['document_ready']}

    def put_code(self,request_id,code,email=None):
        code=str(code).strip()
        if not re.fullmatch('[0-9]{6}',code): raise ValueError('Se requieren seis dígitos')
        with self.lock:
            j=self.job
            if not j or j['id']!=request_id: raise ValueError('Solicitud no encontrada')
            if email and j['email']!=email.strip().lower(): raise ValueError('La cuenta no coincide con la solicitud IMSS')
            if time.monotonic()-j['created']>900: raise ValueError('Solicitud caducada; inicia un nuevo trámite')
            if j['status'] not in ('ESPERANDO_CODIGO','CODIGO_DISPONIBLE'):
                raise ValueError('La solicitud ya no espera un código')
            j['code']=code;j['status']='CODIGO_DISPONIBLE';j['sent_at']=time.monotonic()
            return {'ok':True}

    def acknowledge(self,request_id):
        with self.lock:
            j=self.job
            if not j or j['id']!=request_id:raise ValueError('Solicitud distinta')
            if j['status']=='CODIGO_DISPONIBLE':
                j['status']='CODIGO_ENVIADO_AL_CELULAR'
                j['code']=None
            return {'ok':True}

    def imss_done(self,request_id):
        with self.lock:
            j=self.job
            if not j or j['id']!=request_id:raise ValueError('Solicitud distinta')
            j['status']='SOLICITUD_IMSS_ENVIADA';j['code']=None;j['document_ready']=False
            return {'ok':True}

class Server:
    def __init__(self,state:State,port=PORT):
        key=shared_key()
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): return
            def reply(self,status,obj):
                payload=json.dumps(obj,ensure_ascii=False).encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type','application/json; charset=utf-8')
                self.send_header('Cache-Control','no-store')
                self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Content-Length',str(len(payload)))
                self.end_headers();self.wfile.write(payload)
            def authorized(self):
                return secrets.compare_digest(self.headers.get('X-GD-Link-Key',''),key)
            def body(self):
                n=int(self.headers.get('Content-Length','0'))
                if not (1<=n<=2048):raise ValueError('Tamaño inválido')
                x=json.loads(self.rfile.read(n))
                if not isinstance(x,dict):raise ValueError('Formato inválido')
                return x
            def do_GET(self):
                if not self.authorized():return self.reply(401,{'error':'Sin autorización'})
                try:
                    p=urlparse(self.path)
                    if p.path=='/v1/ping':return self.reply(200,{'ok':True,'version':1})
                    if p.path=='/v1/estado':
                        req=parse_qs(p.query).get('id',[None])[0]
                        return self.reply(200,state.status(req))
                    return self.reply(404,{'error':'No existe'})
                except ValueError as e:return self.reply(400,{'error':str(e)})
            def do_POST(self):
                if not self.authorized():return self.reply(401,{'error':'Sin autorización'})
                try:
                    p=self.body()
                    if self.path=='/v1/iniciar':return self.reply(200,state.start(str(p.get('email','')),str(p.get('id',''))))
                    if self.path=='/v1/codigo':return self.reply(200,state.put_code(str(p.get('id','')),str(p.get('code','')),str(p.get('email',''))))
                    if self.path=='/v1/recibido':return self.reply(200,state.acknowledge(str(p.get('id',''))))
                    if self.path=='/v1/imss_enviado':return self.reply(200,state.imss_done(str(p.get('id',''))))
                    return self.reply(404,{'error':'No existe'})
                except (ValueError, json.JSONDecodeError) as e:return self.reply(400,{'error':str(e)[:150]})
                except Exception:return self.reply(500,{'error':'Error local'})
        self.server=ThreadingHTTPServer((HOST,port),Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
    def start(self):self.thread.start()
    def close(self):self.server.shutdown();self.server.server_close()

class Client:
    def __init__(self,port=PORT,timeout=1.4):self.port=port;self.timeout=timeout
    def call(self,endpoint,body=None):
        url=f'http://{HOST}:{self.port}'+endpoint
        data=json.dumps(body).encode('utf-8') if body is not None else None
        req=Request(url,data=data,headers={'X-GD-Link-Key':shared_key(),
                           'Content-Type':'application/json'},method='POST' if data is not None else 'GET')
        try:
            with urlopen(req,timeout=self.timeout) as r: return json.loads(r.read(8192))
        except HTTPError as e:
            try: error=json.loads(e.read(1024)).get('error','HTTP '+str(e.code))
            except Exception: error='HTTP '+str(e.code)
            raise LinkError(error) from e
        except (URLError,TimeoutError,OSError) as e:
            raise LinkError('El bot Outlook no está abierto o el enlace local está ocupado.') from e
    def ping(self):return self.call('/v1/ping')
    def begin(self,email,request_id):return self.call('/v1/iniciar',{'email':email,'id':request_id})
    def status(self,request_id):return self.call('/v1/estado?id='+request_id)
    def ack(self,request_id):return self.call('/v1/recibido',{'id':request_id})
    def done(self,request_id):return self.call('/v1/imss_enviado',{'id':request_id})
