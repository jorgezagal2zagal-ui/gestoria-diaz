"""Gestoria Diaz - prototipo asistido de IMSS Digital, Wi-Fi, sin dependencias pip."""
import base64
import json
import os
from pathlib import Path
import re
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from adb_bridge import Bridge, BridgeError, discover_adb
from flow_speed import wait_for_screen_change
from imss_core import nodes_from_xml, stage, node_match, clickpoint, edits, normal, login_fields, privacy_box, access_button, form_matches, privacy_action, login_button_candidate, device_change_prompt, device_change_accept_button, email_confirmation_required, email_confirmation_button

APPDATA = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'GestoriaDiaz' / 'IMSS_WIFI_UN_CLIC'
CONFIG = APPDATA / 'config.json'
# PIN opcional inyectado localmente; nunca distribuir un valor personal.
# No imprimirlo en bitácoras, excepciones, archivos de configuración ni diagnósticos.
DEVICE_PIN = os.environ.get('GESTORIA_DEVICE_PIN', '')

BLACK = '#111318'; PANEL = '#1b2027'; GOLD='#dfb66a'; WHITE='#e8eaf0'; GRAY='#aab0bc'


def get_config():
    try:
        obj=json.loads(CONFIG.read_text(encoding='utf-8'))
        return obj if isinstance(obj,dict) else {}
    except (ValueError,OSError): return {}


def save_config(obj):
    APPDATA.mkdir(parents=True,exist_ok=True)
    tmp=CONFIG.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(CONFIG)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Gestoría Díaz · IMSS Digital · Wi-Fi · V6 Rápida y Confirmar')
        self.geometry('1130x790');self.minsize(970,690);self.configure(bg=BLACK)
        self.bridge=Bridge(); self.cfg=get_config()
        self.ip=tk.StringVar(value=self.cfg.get('ip',''))
        self.port=tk.StringVar(value=self.cfg.get('port',''))
        self.curp=tk.StringVar(); self.correo=tk.StringVar(); self.code=tk.StringVar()
        self.imei_enabled=tk.BooleanVar(value=False)
        self.status=tk.StringVar(value='ADB listo' if self.bridge.adb else 'ADB no encontrado')
        self._busy=False; self._refresh_busy=False;self._calibrating=False;self._login_busy=False;self._form_points={};self._cal_sequence=[];self._access_sent=False
        self._image=None;self._size=(1,1);self._photo_size=(1,1)
        self._flow_stop=threading.Event(); self._seen={};self._pin_attempted=False;self._privacy_attempted=False;self._change_attempted=False
        self.make_layout()
        self.after(450,self.init_connection)
        self.after(2500,self.preview_tick)

    def make_layout(self):
        style=ttk.Style(self)
        if 'clam' in style.theme_names():style.theme_use('clam')
        style.configure('TEntry',fieldbackground='#f3f3f3',foreground='#151515',padding=6)
        style.configure('TButton',padding=(10,7),font=('Segoe UI',10))
        style.configure('Gold.TButton',background=GOLD,foreground='#111318',font=('Segoe UI',10,'bold'))
        style.map('Gold.TButton',background=[('active','#f1cc89')])
        head=tk.Frame(self,bg=BLACK);head.pack(fill='x',padx=16,pady=(12,8))
        tk.Label(head,text='GESTORÍA DÍAZ',bg=BLACK,fg=GOLD,font=('Segoe UI',21,'bold')).pack(side='left')
        tk.Label(head,text='IMSS DIGITAL · CONEXIÓN WI-FI',bg=BLACK,fg=WHITE,font=('Segoe UI',11)).pack(side='right')
        area=tk.Frame(self,bg=BLACK);area.pack(fill='both',expand=True,padx=16,pady=2)
        left=tk.Frame(area,bg=PANEL,padx=14,pady=10);left.pack(side='left',fill='both',expand=True,padx=(0,10))
        right=tk.Frame(area,bg=PANEL,padx=12,pady=12,width=350);right.pack(side='right',fill='both');right.pack_propagate(False)
        def section(text): tk.Label(left,text=text,bg=PANEL,fg=GOLD,font=('Segoe UI',12,'bold')).pack(anchor='w',pady=(8,4))
        def field(parent,label,var,w=18):
            c=tk.Frame(parent,bg=PANEL);c.pack(side='left',padx=(0,7))
            tk.Label(c,text=label,bg=PANEL,fg=WHITE,font=('Segoe UI',9)).pack(anchor='w')
            e=ttk.Entry(c,textvariable=var,width=w);e.pack(anchor='w');return e
        def bar(*buttons):
            b=tk.Frame(left,bg=PANEL);b.pack(anchor='w',fill='x',pady=5)
            for name,fn,style in buttons:
                ttk.Button(b,text=name,command=fn,style=style).pack(side='left',padx=(0,7),pady=2)
        section('1 · Conexión al celular')
        fr=tk.Frame(left,bg=PANEL);fr.pack(anchor='w',fill='x')
        field(fr,'IP del celular',self.ip,21);field(fr,'Puerto de conexión',self.port,12)
        bar(('CONECTAR WI-FI',self.connect,'Gold.TButton'),('VINCULAR',self.pair,'TButton'),('DETECTAR ADB',self.detect,'TButton'))
        tk.Label(left,text='El puerto de VINCULAR es distinto al puerto de CONECTAR.',bg=PANEL,fg=GRAY,font=('Segoe UI',9)).pack(anchor='w')
        section('2 · Datos de la solicitud')
        fr=tk.Frame(left,bg=PANEL);fr.pack(anchor='w',fill='x')
        field(fr,'CURP (18 caracteres)',self.curp,24);field(fr,'Correo del trámite',self.correo,32)
        tk.Label(left,text='Usa únicamente solicitudes autorizadas por el titular.',bg=PANEL,fg=GRAY,font=('Segoe UI',9)).pack(anchor='w',pady=(4,1))
        bar(('ABRIR IMSS DIGITAL',self.open_imss,'Gold.TButton'),('INICIAR PASOS',self.start_flow,'TButton'),('DETENER',self.stop_flow,'TButton'))
        bar(('LIMPIAR Y RELLENAR CAMPOS',self.refill_login,'Gold.TButton'),('CALIBRAR FORMULARIO',self.calibrate_form,'TButton'))
        bar(('ACEPTAR PRIVACIDAD E INICIAR',self.accept_and_login,'Gold.TButton'),('CALIBRAR PRIVACIDAD',self.calibrate_privacy,'TButton'))
        bar(('CONFIRMAR CAMBIO DE CELULAR',self.accept_device_change,'Gold.TButton'),('CALIBRAR BOTÓN SÍ',self.calibrate_change,'TButton'))
        tk.Label(left,text='Si el IMSS duplica la CURP o el correo, este botón borra primero el texto. Calibra los campos una sola vez si Android no los identifica.',bg=PANEL,fg=GRAY,font=('Segoe UI',9),wraplength=610,justify='left').pack(anchor='w')
        section('3 · Código recibido por correo')
        fr=tk.Frame(left,bg=PANEL);fr.pack(anchor='w',fill='x')
        field(fr,'Código IMSS (6 dígitos)',self.code,23)
        bar(('PONER CÓDIGO',self.send_code,'Gold.TButton'),('MARCAR PRIMERA CASILLA',self.calibrate,'TButton'))
        tk.Label(left,text='Para calibrar: pulsa MARCAR y luego toca la primera casilla en la vista.',bg=PANEL,fg=GRAY,font=('Segoe UI',9),wraplength=510,justify='left').pack(anchor='w')
        bar(('VERIFICAR EN IMSS',self.verify_code,'TButton'),('ACTUALIZAR VISTA',self.refresh,'TButton'))
        section('Registro y diagnóstico')
        self.logbox=tk.Text(left,height=8,bg='#101318',fg='#d7dbe3',insertbackground=GOLD,font=('Consolas',9),wrap='word',relief='flat')
        self.logbox.pack(fill='both',expand=True,pady=(0,6));self.logbox.configure(state='disabled')
        tk.Label(right,text='VISTA DEL CELULAR',bg=PANEL,fg=GOLD,font=('Segoe UI',12,'bold')).pack(anchor='w')
        tk.Label(right,text='Haz clic para tocar; calibra la casilla si es necesario.',bg=PANEL,fg=GRAY,font=('Segoe UI',9),wraplength=320,justify='left').pack(anchor='w',pady=4)
        self.canvas=tk.Canvas(right,width=318,height=660,bg='#090c10',highlightthickness=1,highlightbackground='#534a39')
        self.canvas.pack(fill='both',expand=True,pady=7)
        self.canvas.bind('<Button-1>',self.preview_click)
        foot=tk.Frame(self,bg=BLACK);foot.pack(fill='x',padx=16,pady=8)
        tk.Label(foot,textvariable=self.status,bg=BLACK,fg=GOLD,font=('Segoe UI',10)).pack(side='left')
        ttk.Button(foot,text='VER DISPOSITIVOS',command=self.detect).pack(side='right')
        self.log('Programa iniciado. Las conexiones Wi-Fi guardadas se vuelven a intentar al abrir.')
        self.log('PIN de identidad preconfigurado para este dispositivo (valor oculto).')
        if self.bridge.adb:self.log('ADB detectado: '+self.bridge.adb)
        else:self.log('No hay ADB. Abre el programa mediante ABRIR_BOT.bat para prepararlo.')

    def log(self,s):
        def write():
            self.logbox.configure(state='normal');self.logbox.insert('end',time.strftime('%H:%M:%S')+' · '+s+'\n')
            self.logbox.see('end');self.logbox.configure(state='disabled')
        self.after(0,write)

    def task(self,fn,when_done=None):
        def worker():
            try:
                result=fn()
                if when_done:self.after(0,lambda:when_done(result))
            except Exception as exc:
                message=str(exc)
                self.log('ERROR: '+message)
                self.after(0,lambda:self.status.set('Error: '+message[:85]))
        threading.Thread(target=worker,daemon=True).start()

    def init_connection(self):
        if self.bridge.adb and self.ip.get() and self.port.get():
            self.log('Reintentando conexión Wi-Fi guardada...')
            self.connect()
        elif self.bridge.adb:self.detect()

    def connect(self):
        ip=self.ip.get().strip(); port=self.port.get().strip()
        def work():
            try:
                result=self.bridge.connect(ip,port)
                connected_port=port
            except BridgeError as first_error:
                # Tras un reinicio Android puede cambiar el puerto ADB.
                # Solo reintenta el mismo teléfono (misma IP) y el servicio ADB de conexión.
                candidates=[p for p in self.bridge.mdns_ports(ip) if p != port]
                if not candidates:
                    raise first_error
                last_error=first_error
                for candidate in candidates:
                    try:
                        result=self.bridge.connect(ip,candidate)
                        connected_port=candidate
                        break
                    except BridgeError as exc:
                        last_error=exc
                else:
                    raise last_error
            cfg=get_config();cfg.update(ip=ip,port=connected_port);save_config(cfg)
            self.cfg=cfg
            return result,connected_port
        def done(answer):
            result,connected_port=answer
            self.port.set(connected_port)
            self.status.set('Celular conectado: '+str(self.bridge.serial))
            self.log('Conectado y datos Wi-Fi guardados: '+result)
            self.refresh()
        self.task(work,done)

    def pair(self):
        ip=self.ip.get().strip()
        port=simpledialog.askstring('Vincular por Wi-Fi','PUERTO DE VINCULACIÓN (no el de conexión):',parent=self)
        if not port:return
        code=simpledialog.askstring('Código Android','Código de 6 cifras de Vincular dispositivo:',parent=self)
        if not code:return
        self.task(lambda:self.bridge.pair(ip,port,code),lambda result:self.log('Vinculación: '+result+'. Regresa y escribe el puerto principal para conectar.'))

    def detect(self):
        def done(result):
            devices,raw=result
            if devices:
                self.bridge.serial=devices[0]
                self.status.set('ADB conectado: '+self.bridge.serial)
                self.log('ADB encontró: '+', '.join(devices))
            else:
                self.log('No hay teléfono autorizado. Activa depuración inalámbrica y usa CONECTAR.')
                self.status.set('ADB activo; teléfono aún no conectado')
        self.task(lambda:self.bridge.devices(),done)

    def open_imss(self):
        def done(pkg):
            self.log('Se solicitó abrir IMSS Digital oficial: '+pkg)
            self.status.set('IMSS Digital · '+pkg)
            self.after(300,self.refresh)
        self.task(lambda:self.bridge.launch_imss(),done)

    def refresh(self):
        if self._refresh_busy or not self.bridge.serial:return
        self._refresh_busy=True
        def done(result):
            self._refresh_busy=False
            data,w,h=result
            try:
                original=tk.PhotoImage(data=base64.b64encode(data).decode('ascii'),format='png')
                # Ajusta a la vista usando subsample entero; conserva proporciones.
                factor=max(1,(w+307)//308,(h+615)//616)
                self._image=original.subsample(factor,factor)
                self._size=(w,h);self._photo_size=(self._image.width(),self._image.height())
                self.canvas.delete('all')
                self.canvas.create_image(5,5,image=self._image,anchor='nw',tags=('phone',))
                self.canvas.config(scrollregion=(0,0,self._image.width()+12,self._image.height()+12))
            except tk.TclError as exc:self.log('No se pudo mostrar la captura: '+str(exc))
        def work():return self.bridge.screenshot()
        def worker():
            try:
                res=work();self.after(0,lambda:done(res))
            except Exception as exc:
                msg=str(exc)
                self.after(0,lambda:self.log('Captura: '+msg))
                self.after(0,lambda:setattr(self,'_refresh_busy',False))
        threading.Thread(target=worker,daemon=True).start()

    def preview_tick(self):
        if self.bridge.serial and self.winfo_exists() and not self._calibrating and not self._busy:self.refresh()
        self.after(2300,self.preview_tick)

    def calibrate_privacy(self):
        """Calibración de SOLO los dos controles, sin tocar CURP ni correo."""
        if not self.bridge.serial:
            messagebox.showwarning('Celular','Primero conecta el celular y actualiza la vista.');return
        self._calibrating=True
        old=get_config()
        self._form_points=dict(old.get('form_points') or {}) if old.get('form_serial')==self.bridge.serial else {}
        self._cal_sequence=['privacidad','iniciar']
        self.status.set('CALIBRAR 1/2: marca la fila HE LEÍDO Y ACEPTO en la VISTA')
        self.log('Calibración: señala primero la casilla de privacidad y luego INICIAR SESIÓN, sin tocar el teléfono.')

    def calibrate_change(self):
        """El usuario señala una sola vez dónde está SÍ en el diálogo real."""
        if not self.bridge.serial:
            messagebox.showwarning('Celular','Primero conecta el celular.');return
        self._calibrating=True
        self._cal_sequence=['cambio_si']
        self.status.set('CALIBRAR: haz clic en SÍ, QUIERO HACER EL CAMBIO, en la vista')
        self.log('Calibrando solo el botón SÍ del aviso específico de cambio de celular.')

    def _change_calibration(self):
        cfg=get_config()
        if cfg.get('change_serial')!=self.bridge.serial:
            return None
        pt=cfg.get('change_yes_point')
        if not isinstance(pt,list) or len(pt)!=2 or not all(isinstance(v,(int,float)) and 0<=v<=1 for v in pt):
            return None
        _,w,h=self.bridge.screenshot()
        if cfg.get('change_size') != [w,h]:return None
        return (round(pt[0]*w),round(pt[1]*h))

    def do_device_change(self, nodes, manual=False):
        """Una sola pulsación por aviso para no confirmar a ciegas otro diálogo."""
        state=stage(nodes)
        if state != 'CAMBIO_DISPOSITIVO':
            if manual and state=='DESCONOCIDA':
                # UIAutomator puede devolver vacío en algunos diálogos. En este caso
                # solo se permite el botón manual, tras confirmar la pantalla visible.
                pass
            else:
                raise BridgeError('No se detectó el aviso específico de cambio de celular del IMSS.')
        if self._change_attempted:
            return 'Ya se intentó confirmar el cambio una vez. Comprueba la pantalla antes de repetir.'
        btn=device_change_accept_button(nodes)
        if btn:
            point=clickpoint(btn)
        elif manual:
            point=self._change_calibration()
            if not point:
                return 'No detecté el botón SÍ. Pulsa CALIBRAR BOTÓN SÍ y márcalo en la vista, o tócalo en el celular.'
        else:
            return ('IMSS solicita cambio de celular, pero Android no mostró el botón SÍ en accesibilidad. '
                    'Usa CALIBRAR BOTÓN SÍ y luego CONFIRMAR CAMBIO DE CELULAR.')
        self._change_attempted=True
        self.bridge.tap(*point)
        self.log('Se tocó SÍ, QUIERO HACER EL CAMBIO (una sola vez).')
        return 'Se tocó SÍ, QUIERO HACER EL CAMBIO. Comprobando avance de IMSS.'

    def accept_device_change(self):
        if self._busy or self._login_busy:
            self.log('Hay un trámite en curso; espera a que termine.');return
        if not messagebox.askyesno('Cambiar celular vinculado',
                'Este botón selecciona SÍ, QUIERO HACER EL CAMBIO y puede desvincular '
                'el dispositivo anterior.\n\nÚsalo solo cuando veas el aviso de IMSS '
                'y el titular haya autorizado el cambio. ¿Confirmas?',parent=self):
            return
        self._change_attempted=False
        def work():
            nodes=nodes_from_xml(self.bridge.dump())
            status=stage(nodes)
            if status=='DESCONOCIDA':
                if not self._change_calibration():
                    return ('Android no mostró el aviso en accesibilidad. '
                            'Pulsa CALIBRAR BOTÓN SÍ sobre el aviso visible y vuelve a confirmar.')
            elif status!='CAMBIO_DISPOSITIVO':
                return 'No aparece el aviso de cambio de celular; no se tocó nada.'
            result=self.do_device_change(nodes,manual=True)
            time.sleep(.65)
            check=stage(nodes_from_xml(self.bridge.dump()))
            return result + (' Aviso aún visible: revisa antes de reintentar.' if check=='CAMBIO_DISPOSITIVO' else ' IMSS avanzó o está cargando.')
        def done(result):
            self.log(result);self.status.set(result[:90]);self.refresh()
        self.task(work,done)

    def accept_and_login(self):
        """Completa únicamente privacidad e inicio, sin volver a pegar CURP/correo."""
        curp=self.curp.get().strip().upper();email=self.correo.get().strip().lower()
        if not re.fullmatch(r'[A-Z0-9]{18}',curp) or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email):
            messagebox.showerror('Datos','Coloca una CURP y correo válidos en el panel.');return
        if self._busy or self._login_busy:
            self.log('Espera a que termine la acción anterior.');return
        self._login_busy=True
        def work():
            try:return self.accept_privacy_and_submit(curp,email)
            finally:self._login_busy=False
        def done(answer):
            self.status.set(answer[:95]);self.log(answer);self.refresh()
        self.task(work,done)

    def _form_calibration(self):
        cfg=get_config()
        if cfg.get('form_serial')!=self.bridge.serial:return None,None,None
        points=cfg.get('form_points') or {}
        if not points:return None,None,None
        _,w,h=self.bridge.screenshot()
        if cfg.get('form_size')!=[w,h]:return None,None,None
        return points,w,h

    def accept_privacy_and_submit(self,curp,email):
        """Un intento de consentimiento por pantalla; evita alternar checkboxes."""
        nodes=nodes_from_xml(self.bridge.dump())
        if stage(nodes)!='ACCESO':
            raise BridgeError('No está abierto el formulario de inicio de IMSS Digital.')
        if form_matches(nodes,curp,email) is not True:
            return 'No se confirmó CURP/correo; usa LIMPIAR Y RELLENAR y revisa antes de iniciar.'
        pts,w,h=self._form_calibration()
        loc=privacy_action(nodes, (w,h) if w else None)
        if loc:
            x,y,checked,verifiable,source=loc
            if not checked and not self._privacy_attempted:
                self._privacy_attempted=True
                self.bridge.tap(x,y)
                self.log('Se pulsó la casilla de aceptación del Aviso de Privacidad.')
                time.sleep(.18)
        elif pts and all(k in pts for k in ('privacidad','iniciar')) and not self._privacy_attempted:
            self._privacy_attempted=True
            self.bridge.tap(round(pts['privacidad'][0]*w),round(pts['privacidad'][1]*h))
            self.log('Se pulsó la casilla calibrada de privacidad.')
            time.sleep(.18)
        elif not self._privacy_attempted:
            return 'No se localizó la casilla. Pulsa CALIBRAR PRIVACIDAD (dos clics en la vista).'

        after=nodes_from_xml(self.bridge.dump())
        state=stage(after)
        if state!='ACCESO':
            return 'La pantalla cambió después de privacidad; revisa IMSS y continúa.'
        candidate=privacy_action(after, (w,h) if w else None)
        if candidate and candidate[3] and not candidate[2]:
            return 'La casilla sigue sin marcarse. No se pulsó Iniciar sesión.'
        if not candidate and not self._privacy_attempted:
            return 'No se confirmó la aceptación. Revisa la vista.'
        btn=access_button(after) or login_button_candidate(after)
        if btn:
            self.bridge.tap(*clickpoint(btn))
            self.log('Se pulsó Iniciar sesión tras la aceptación.')
            return 'Privacidad aceptada; se pulsó Iniciar sesión.'
        if pts and 'iniciar' in pts:
            self.bridge.tap(round(pts['iniciar'][0]*w),round(pts['iniciar'][1]*h))
            return 'Privacidad aceptada; se tocó el botón Iniciar sesión calibrado.'
        return 'Casilla pulsada, pero no se identificó Iniciar sesión. CALIBRAR PRIVACIDAD.'

    def calibrate_form(self):
        if not self.bridge.serial:
            messagebox.showwarning('Celular','Primero conecta tu celular y actualiza la vista.');return
        self._calibrating=True
        self._form_points={}
        self._cal_sequence=['curp','correo','privacidad','iniciar']
        self.status.set('CALIBRAR 1/4: toca el campo CURP en la VISTA de la derecha')
        self.log('Calibración: selecciona CURP, correo, casilla de aceptación y botón Iniciar sesión EN LA VISTA. No se tocará el teléfono todavía.')

    def refill_login(self):
        curp=self.curp.get().strip().upper(); email=self.correo.get().strip().lower()
        if not re.fullmatch(r'[A-Z0-9]{18}',curp) or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email):
            messagebox.showerror('Datos','Coloca una CURP de 18 caracteres y un correo válido.');return
        if self._busy or self._login_busy:
            self.log('Espera a que termine la acción anterior.');return
        self._login_busy=True;self._privacy_attempted=False
        def work():
            try:return self.fill_login(curp,email,submit=False,manual=True)
            finally:self._login_busy=False
        def done(r):
            self.status.set('Relleno: '+r[:90]);self.log(r);self.refresh()
        self.task(work,done)

    def fill_login(self,curp,email,submit=False,manual=False):
        nodes=nodes_from_xml(self.bridge.dump());state=stage(nodes)
        cfg=get_config();points=cfg.get('form_points') if cfg.get('form_serial')==self.bridge.serial else None
        if points:
            _,w,h=self.bridge.screenshot()
            if cfg.get('form_size')!=[w,h]:points=None
        if state!='ACCESO' and not (manual and state=='DESCONOCIDA' and points):
            raise BridgeError('Abre INICIA SESIÓN de IMSS Digital antes de rellenar. Pantalla: '+state)
        fields=login_fields(nodes)
        if fields:
            places=[clickpoint(n) for n in fields];old=[len(n['text']) for n in fields]
        elif points and all(k in points for k in ('curp','correo')):
            places=[(int(points[k][0]*w),int(points[k][1]*h)) for k in ('curp','correo')]
            old=[None,None]
        else:
            return 'Android no identificó los campos. Usa CALIBRAR FORMULARIO y señala las cuatro posiciones.'
        if form_matches(nodes,curp,email) is not True:
            for i, (pos, value) in enumerate(zip(places,[curp,email])):
                self.bridge.tap(*pos);time.sleep(.12)
                self.bridge.replace_focused_text(value,old[i]);time.sleep(.14)
                if i==1:self.bridge.key(4) # Oculta teclado después del correo
        time.sleep(.18)
        newer=nodes_from_xml(self.bridge.dump())
        match=form_matches(newer,curp,email)
        if match is False:
            # Algunos WebViews no admiten Ctrl+A. Una única corrección de respaldo.
            for i,(pos,value) in enumerate(zip(places,[curp,email])):
                self.bridge.tap(*pos)
                self.bridge.replace_focused_text(value,100,force_backspace=True)
                if i==1:self.bridge.key(4)
            time.sleep(.22)
            newer=nodes_from_xml(self.bridge.dump());match=form_matches(newer,curp,email)
        if match is False:
            raise BridgeError('Los campos siguen distintos; no se pulsó Iniciar sesión. Revisa el formulario.')
        if match is None:
            return ('CURP y correo enviados después de borrar. Android no expone su contenido, '
                    'así que revisa en el celular y pulsa Iniciar sesión manualmente.')
        return 'Campos confirmados, sin duplicados. Listos para aceptar privacidad e iniciar.'

    def calibrate(self):
        self._cal_sequence=[]
        self._calibrating=True
        self.status.set('Toca la primera casilla del código IMSS en la VISTA DEL CELULAR')
        self.log('Calibración: haz clic en la primera casilla en la imagen de la derecha.')

    def preview_click(self,event):
        x=event.x-5;y=event.y-5
        imw,imh=self._photo_size
        if x<0 or y<0 or x>=imw or y>=imh:
            self.log('Clic fuera de la imagen.');return
        w,h=self._size
        px=int(w*x/imw);py=int(h*y/imh)
        if self._calibrating and self._cal_sequence:
            target=self._cal_sequence.pop(0)
            if target=='cambio_si':
                cfg=get_config();cfg.update(change_yes_point=[round(px/w,6),round(py/h,6)],
                                            change_serial=self.bridge.serial,change_size=[w,h])
                save_config(cfg);self.cfg=cfg;self._calibrating=False
                self.status.set('Posición SÍ guardada para este celular')
                self.log('Botón SÍ calibrado. Si IMSS muestra el aviso, pulsa CONFIRMAR CAMBIO DE CELULAR.')
                return
            self._form_points[target]=[round(px/w,6),round(py/h,6)]
            if self._cal_sequence:
                names={'correo':'campo CORREO','privacidad':'casilla HE LEÍDO Y ACEPTO','iniciar':'botón INICIAR SESIÓN'}
                self.status.set('CALIBRAR: toca '+names[self._cal_sequence[0]]+' en la vista')
            else:
                conf=get_config();conf.update(form_points=self._form_points,
                    form_serial=self.bridge.serial,form_size=[w,h])
                save_config(conf);self.cfg=conf;self._calibrating=False
                self.status.set('Calibración guardada. Puedes pulsar ACEPTAR PRIVACIDAD E INICIAR')
                self.log('Calibración guardada para el mismo dispositivo. No se guardaron CURP ni correo.')
            return # Solo calibración, NO tocamos el celular
        if self._calibrating:
            conf=get_config();conf['otp_first']=[round(px/w,6),round(py/h,6)]
            save_config(conf);self.cfg=conf;self._calibrating=False
            self.status.set('Primera casilla guardada para este celular')
            self.log('Primera casilla calibrada (posición proporcional guardada).')
        self.task(lambda:self.bridge.tap(px,py))

    def send_code(self):
        code=self.code.get().strip()
        if not (len(code)==6 and code.isascii() and code.isdecimal()):
            messagebox.showerror('Código','Introduzca exactamente seis números.');return
        conf=get_config()
        first=conf.get('otp_first')
        def work():
            xml=self.bridge.dump();nodes=nodes_from_xml(xml)
            if stage(nodes) not in ('CODIGO','DESCONOCIDA'):
                raise BridgeError('IMSS no está en la pantalla del código.')
            if first:
                _,w,h=self.bridge.screenshot()
                self.bridge.tap(int(first[0]*w),int(first[1]*h))
            else:
                inps=edits(nodes)
                if inps:self.bridge.tap(*clickpoint(inps[0]))
                else:raise BridgeError('Primero pulsa MARCAR PRIMERA CASILLA y tócala una vez en la vista.')
            time.sleep(0.24)
            self.bridge.digits(code)
            return 'Se enviaron seis pulsaciones numéricas al campo IMSS.'
        def done(result):
            self.log(result+' Comprueba las seis casillas antes de Verificar.')
            self.status.set('Código enviado; pendiente de comprobación en IMSS')
            self.refresh()
        self.task(work,done)

    def verify_code(self):
        def work():
            nodes=nodes_from_xml(self.bridge.dump())
            n=node_match(nodes,['verificar','validar codigo'])
            if not n:raise BridgeError('No se identificó el botón Verificar. Puedes pulsarlo en la vista del celular.')
            self.bridge.tap(*clickpoint(n));return 'Se pulsó Verificar en IMSS.'
        self.task(work,lambda result:self.log(result))

    def stop_flow(self):
        self._flow_stop.set();self.status.set('Asistente detenido');self.log('El proceso se detuvo sin cerrar IMSS.')

    def start_flow(self):
        curp=self.curp.get().strip().upper();email=self.correo.get().strip()
        if not re.fullmatch(r'[A-Z0-9]{18}',curp) or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email):
            messagebox.showerror('Datos','Ingresa una CURP de 18 caracteres y un correo válido.');return
        if self._busy or self._login_busy:
            self.log('Hay una acción en curso; espera a que termine.');return
        self._flow_stop.clear();self._seen={};self._busy=True;self._access_sent=False;self._pin_attempted=False;self._privacy_attempted=False;self._change_attempted=False
        self.log('Modo rápido: avanza cuando cambia la pantalla, sin repetir toques. Las verificaciones siguen siendo obligatorias.')
        self.task(lambda:self.flow(curp,email),lambda result:self.log(result))

    def _await_stage_change(self, origin):
        """Espera el cambio de pantalla con sondeo corto; NO repite el toque.

        Las capturas ADB se serializan en Bridge, nunca se pulsan botones
        mientras se está esperando a que Android procese la acción anterior.
        """
        return wait_for_screen_change(
            lambda: nodes_from_xml(self.bridge.dump()), stage,
            origin, self._flow_stop.is_set,
            timeout=7.0, interval=0.15)

    def flow(self,curp,email):
        try:
            previous=None
            pending=None
            for _ in range(75):
                if self._flow_stop.is_set():return 'Asistente detenido.'
                if pending is not None:
                    nodes,state=pending
                    pending=None
                else:
                    nodes=nodes_from_xml(self.bridge.dump());state=stage(nodes)
                if state!=previous:
                    if previous=='IDENTIDAD' and state!='IDENTIDAD':self._pin_attempted=False
                    self.log('Pantalla detectada: '+state);previous=state
                    self._seen[state]=0
                self._seen[state]=self._seen.get(state,0)+1
                if state=='IDENTIDAD':
                    if self._pin_attempted:
                        return 'Android sigue solicitando identidad. Comprueba la pantalla; no se reintentó el PIN.'
                    if not DEVICE_PIN:
                        return 'Confirma tu identidad manualmente en el HONOR y pulsa REANUDAR.'
                    self._pin_attempted=True
                    # Únicamente si Android expone explícitamente la ventana de identidad.
                    self.log('Pantalla de identidad confirmada: enviando PIN preconfigurado (sin mostrarlo).')
                    self.bridge.enter_device_pin(DEVICE_PIN)
                    time.sleep(1.0)
                    if stage(nodes_from_xml(self.bridge.dump()))=='IDENTIDAD':
                        return 'El PIN fue enviado, pero Android sigue pidiendo identidad; introdúcelo manualmente.'
                    continue
                if state=='CODIGO':
                    self.log('Código solicitado: escríbelo en el panel y pulsa PONER CÓDIGO.');return 'Esperando código IMSS.'
                if state=='CORREO_REPORTE':
                    return 'Solicitud enviada; el PDF llegará al correo del trámite. No se descarga desde este panel.'
                if state=='DESCONOCIDA':
                    if self._seen[state]>=5:
                        return 'Pantalla no reconocida. Usa la vista para avanzar y vuelve a INICIAR PASOS.'
                    time.sleep(0.2);continue
                if self._seen[state]>=4:
                    return 'Se detuvo para no pulsar repetidamente sobre '+state+'.'
                if state=='ACCESO':
                    if self._access_sent:
                        if self._seen[state]>=3:
                            return 'El formulario sigue abierto. Revisa los campos; no se volvieron a escribir los datos.'
                    else:
                        result=self.fill_login(curp,email,submit=False)
                        self.log(result)
                        if 'confirmados' not in result.lower() and 'campos confirmados' not in result.lower():
                            return result
                        result=self.accept_privacy_and_submit(curp,email)
                        self.log(result);self._access_sent=True
                        if 'se pulsó iniciar sesión' not in result.lower():
                            return result
                elif state=='CORREO_CONFIRMADO':
                    btn=node_match(nodes,['aceptar','entendido'])
                    if btn:self.bridge.tap(*clickpoint(btn))
                    else:return 'Correo confirmado; pulsa Aceptar en el teléfono.'
                elif state=='CAMBIO_DISPOSITIVO':
                    if self._change_attempted:
                        return 'Se intentó SÍ una vez, pero el aviso sigue visible. Verifica en el celular, sin repetir automáticamente.'
                    result=self.do_device_change(nodes)
                    self.log(result)
                    if not self._change_attempted:
                        return result
                elif state=='MENU_IMSS':
                    btn=node_match(nodes,['constancia de semanas cotizadas','semanas cotizadas'])
                    if btn:self.bridge.tap(*clickpoint(btn))
                    else:return 'Selecciona Constancia de semanas cotizadas en el teléfono.'
                elif state in ('SEMANA_INTRO','CONFIRMAR_SEMANAS'):
                    btn=node_match(nodes,['continuar','aceptar'])
                    if btn:self.bridge.tap(*clickpoint(btn))
                    else:return 'Pulsa Continuar en el teléfono y vuelve a iniciar.'
                elif state=='AVISO_CORREO':
                    # IMSS exige confirmar el correo. Solo pulsar el botón
                    # «Confirmar» si el mensaje específico está visible.
                    btn=email_confirmation_button(nodes)
                    if btn:
                        self.bridge.tap(*clickpoint(btn))
                        self.log('Se pulsó Confirmar en el aviso de correo IMSS una sola vez.')
                    else:
                        return ('IMSS pide confirmar el correo, pero no se identificó con seguridad '
                                'el botón Confirmar. Tócalo en el celular y luego pulsa INICIAR PASOS.')
                else:
                    return 'Pantalla reconocida '+state+'; continuar en el celular.'
                # No esperar 800 ms fijos ni pulsar la misma opción otra vez.
                # Leer la pantalla nueva tan pronto como Android la muestre.
                pending=App._await_stage_change(self,state)
                if pending is None:
                    if self._flow_stop.is_set():return 'Asistente detenido.'
                    return ('IMSS sigue en '+state+' o todavía está cargando. '
                            'No repetí el toque para evitar duplicaciones; revisa la vista y pulsa INICIAR PASOS cuando avance.')
            return 'Número máximo de pantallas alcanzado; revisa el trámite.' 
        finally:
            self._busy=False


if __name__=='__main__':
    App().mainloop()
