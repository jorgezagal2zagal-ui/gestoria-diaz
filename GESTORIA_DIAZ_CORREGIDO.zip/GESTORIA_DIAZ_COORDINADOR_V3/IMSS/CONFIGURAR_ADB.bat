@echo off
setlocal
cd /d "%~dp0"
if exist "%LOCALAPPDATA%\GestoriaDiaz\Android\platform-tools\adb.exe" (
 echo ADB ya esta instalado en tu PC.
 "%LOCALAPPDATA%\GestoriaDiaz\Android\platform-tools\adb.exe" version
 pause
 exit /b 0
)
where adb >nul 2>nul
if not errorlevel 1 (
 echo ADB encontrado en el sistema.
 adb version
 pause
 exit /b 0
)
echo No se encontro ADB en las rutas conocidas.
echo Descargalo desde https://developer.android.com/tools/releases/platform-tools
pause
