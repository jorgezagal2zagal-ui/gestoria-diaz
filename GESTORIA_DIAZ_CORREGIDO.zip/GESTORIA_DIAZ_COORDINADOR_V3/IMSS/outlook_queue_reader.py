# -*- coding: utf-8 -*-
"""Consulta SOLO LECTURA de las direcciones seleccionadas en Outlook V12.

El programa de Outlook es el único que marca cuentas como USADO; IMSS no
lee contraseñas ni escribe en SQLite. El correo tiene que seguir seleccionado
(NUEVO + seleccionado=1) para que Outlook lo inicie a petición de IMSS.
"""
from __future__ import annotations
import os
import re
import sqlite3
from pathlib import Path
from urllib.parse import quote

EMAIL_RE = re.compile(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')


def outlook_database(base=None):
    root = Path(base) if base is not None else Path(os.environ.get('LOCALAPPDATA') or str(Path.home()))
    return root / 'GestoriaDiaz' / 'OutlookV1' / 'cola_simple.sqlite3'


def next_new_selected(base=None):
    """Devuelve (email_o_None, cantidad_nuevas_seleccionadas).

    No crea la base de datos si no está; exige explícitamente NUEVO y seleccionado.
    """
    path = outlook_database(base)
    if not path.is_file():
        return None, 0
    uri = 'file:' + quote(path.resolve().as_posix(), safe='/:') + '?mode=ro'
    db = sqlite3.connect(uri, uri=True, timeout=1.5)
    try:
        db.execute('PRAGMA query_only = ON')
        try:
            count = db.execute('''SELECT COUNT(*) FROM correo
              WHERE estado='NUEVO' AND seleccionado=1''').fetchone()[0]
            row = db.execute('''SELECT email FROM correo
              WHERE estado='NUEVO' AND seleccionado=1 ORDER BY n LIMIT 1''').fetchone()
        except sqlite3.OperationalError as exc:
            raise RuntimeError('Abre Outlook V12 primero para actualizar su lista de cuentas') from exc
        if row and EMAIL_RE.fullmatch(str(row[0])):
            return str(row[0]).lower(), int(count)
        return None, 0
    finally:
        db.close()
