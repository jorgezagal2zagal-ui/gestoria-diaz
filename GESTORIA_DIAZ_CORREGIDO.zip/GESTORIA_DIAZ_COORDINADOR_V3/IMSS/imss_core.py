"""Detección de pantallas IMSS basada en textos de accesibilidad, sin OCR."""
import re
import unicodedata
import xml.etree.ElementTree as ET


def normal(text):
    return ''.join(ch for ch in unicodedata.normalize('NFKD', str(text or '').lower()) if not unicodedata.combining(ch))


def nodes_from_xml(xml):
    if not xml or '<hierarchy' not in xml:
        return []
    xml = xml[xml.find('<hierarchy'):]
    end = xml.find('</hierarchy>')
    if end >= 0: xml = xml[:end + len('</hierarchy>')]
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return []
    result = []
    for el in root.iter('node'):
        attrs = dict(el.attrib)
        b = re.search(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]', attrs.get('bounds', ''))
        bounds = tuple(map(int, b.groups())) if b else None
        result.append({'text': attrs.get('text', ''), 'desc': attrs.get('content-desc', ''),
                       'rid': attrs.get('resource-id', ''), 'class': attrs.get('class', ''),
                       'clickable': attrs.get('clickable', '') == 'true',
                       'checked': attrs.get('checked', '') == 'true',
                       'enabled': attrs.get('enabled', '') != 'false', 'bounds': bounds})
    return result


def words(nodes):
    return normal(' '.join(n['text'] + ' ' + n['desc'] for n in nodes))


def stage(nodes):
    t = words(nodes)
    if 'validacion de identidad' in t or 'confirma tu identidad' in t:
        return 'IDENTIDAD'
    # Los diálogos de éxito se superponen al formulario del código; prioridad máxima.
    if 'el correo ha sido confirmado' in t:
        return 'CORREO_CONFIRMADO'
    # Dialogo de cambio de equipo: puede superponerse al login y otros textos.
    if device_change_prompt(nodes):
        return 'CAMBIO_DISPOSITIVO'
    if email_confirmation_required(nodes):
        return 'AVISO_CORREO'
    if 'ingresa tu codigo de validacion' in t or 'escribe el codigo de validacion' in t:
        return 'CODIGO'
    if 'para poder acceder' in t and 'correo' in t:
        return 'AVISO_CORREO'
    if 'consulta tu constancia de semanas cotizadas' in t or 'tu reporte sera enviado' in t:
        return 'CONFIRMAR_SEMANAS'
    if 'documento informativo' in t and 'semanas cotizadas' in t:
        return 'SEMANA_INTRO'
    if ('constancia de semanas cotizadas' in t and 'vigencia de derechos' in t) or ('reporte personalizado de cotizacion' in t and 'constancia' in t):
        return 'MENU_IMSS'
    if ('inicia sesion' in t or 'iniciar sesion' in t) and ('correo electronico' in t or 'curp' in t):
        return 'ACCESO'
    if 'solicitud de constancia de semanas' in t or 'historia laboral' in t:
        return 'CORREO_REPORTE'
    return 'DESCONOCIDA'



def email_confirmation_required(nodes):
    """Detecta el mensaje concreto del IMSS que exige confirmar correo.

    No confundir con el diálogo de éxito: «El correo ha sido confirmado».
    """
    t=' '.join(words(nodes).split())
    return (('para poder acceder' in t or 'para acceder' in t) and
            'correo' in t and ('haber confirmado' in t or 'confirmar tu correo' in t or
                                 'confirmar el correo' in t or 'correo confirmado' in t) and
            'el correo ha sido confirmado' not in t)


def email_confirmation_button(nodes):
    """Únicamente «Confirmar» en el aviso específico: sin botones genéricos Sí."""
    if not email_confirmation_required(nodes):
        return None
    matches=[]
    for n in nodes:
        if not n.get('bounds') or not n.get('enabled'):continue
        label=normal((n.get('text','')+' '+n.get('desc','')).strip()).strip()
        if label not in ('confirmar', 'confirmar correo', 'confirmar mi correo'):
            continue
        rank=(5 if n.get('clickable') else 0)+(3 if 'Button' in n.get('class','') else 0)
        matches.append((rank,n))
    return max(matches,key=lambda pair:pair[0])[1] if matches else None


def device_change_prompt(nodes):
    """Solo el aviso concreto de IMSS que cambia el celular ligado a una CURP.

    No interpretar una pantalla genérica con la palabra 'cambio' como permiso.
    """
    t = words(nodes)
    has_question = ('curp' in t and 'vinculad' in t and 'dispositivo' in t)
    asks_link = ('deseas vincularla' in t or 'quiero hacer el cambio' in t)
    return bool(has_question and asks_link)


def device_change_accept_button(nodes):
    """Botón SÍ del diálogo confirmado. Nunca usa el genérico 'sí'."""
    if not device_change_prompt(nodes):
        return None
    hits = []
    for n in nodes:
        if not n.get('bounds') or not n.get('enabled'):
            continue
        label = normal(n.get('text','') + ' ' + n.get('desc','')).strip()
        if 'quiero hacer el cambio' not in label:
            continue
        # No elegir el mensaje completo de la alerta por coincidencia parcial.
        if 'esta curp' in label or 'deseas vincularla' in label:
            continue
        rank = (8 if n.get('clickable') else 0) + (4 if 'Button' in n.get('class','') else 0)
        rank -= len(label) / 100
        hits.append((rank,n))
    return max(hits,key=lambda item:item[0])[1] if hits else None


def node_match(nodes, phrases, classes=(), prefer_clickable=True):
    """Encuentra controles por texto o descripción; no usa posiciones adivinadas."""
    phrases = [normal(p) for p in phrases]
    hits = []
    for n in nodes:
        hay = normal(' '.join((n['text'], n['desc'], n['rid'])))
        if n['enabled'] and n['bounds'] and any(p in hay for p in phrases):
            rank = 0
            if classes and any(c in n['class'] for c in classes): rank += 5
            if n['clickable'] and prefer_clickable: rank += 2
            if n['text']: rank += 1
            hits.append((rank,n))
    return max(hits,key=lambda x:x[0])[1] if hits else None


def clickpoint(node):
    x1,y1,x2,y2 = node['bounds']
    return ((x1+x2)//2, (y1+y2)//2)


def edits(nodes):
    return [n for n in nodes if 'EditText' in n['class'] and n['bounds'] and n['enabled']]


def code_digits(s):
    s = str(s).strip()
    if len(s)!=6 or not s.isdecimal() or not s.isascii():
        raise ValueError('El código debe tener exactamente seis números.')
    return s


def otp_key_positions(w,h):
    """Layout observado en el video del usuario (Gboard numérico, pantalla 1116x2480).
    Solo se debe usar si el teclado está ABIERTO y se confirmó el mismo layout.
    """
    rows = ['123','456','789',',0.']
    xs = [0.13, 0.375, 0.625]
    ys = [0.789, 0.85, 0.906, 0.965]
    return {digit:(int(w*xs[i]),int(h*ys[j])) for j,row in enumerate(rows) for i,digit in enumerate(row) if digit.isdigit()}


def login_fields(nodes):
    fields = edits(nodes)
    if len(fields)<2:return None
    def desc(n):return normal(' '.join((n['text'],n['desc'],n['rid'])))
    curp=[n for n in fields if 'curp' in desc(n)]
    email=[n for n in fields if 'correo' in desc(n) or 'email' in desc(n) or 'e-mail' in desc(n)]
    if curp and email and curp[0] is not email[0]:return curp[0],email[0]
    fields=sorted(fields,key=lambda n:n['bounds'][1]);return fields[0],fields[1]


def privacy_box(nodes):
    # La cadena "aviso de privacidad" también está en un hipervínculo.
    valid=[n for n in nodes if n['bounds'] and n['enabled'] and
           'checkbox' in normal(n['class'])]
    if valid:return valid[0]
    return next((n for n in nodes if n['bounds'] and n['enabled'] and n['clickable']
                 and 'he leido y acepto' in normal(n['text']+' '+n['desc'])),None)


def access_button(nodes):
    valid=[n for n in nodes if n['bounds'] and n['enabled'] and n['clickable']
           and 'iniciar sesion' in normal(n['text']+' '+n['desc'])]
    return sorted(valid,key=lambda n:n['bounds'][1])[-1] if valid else None



def privacy_label(nodes):
    """La fila del consentimiento, NUNCA el hipervínculo al aviso."""
    valid=[]
    for n in nodes:
        text=normal(n.get('text','')+' '+n.get('desc',''))
        if n.get('bounds') and n.get('enabled') and 'he leido y acepto' in text:
            valid.append(n)
    return min(valid,key=lambda n:n['bounds'][1]) if valid else None


def privacy_action(nodes, screen_size=None):
    """Devuelve (x,y,checked,verificable,origen) o None.

    Busca un checkbox auténtico asociado a la etiqueta; si no existe, usa
    el área de la fila y no el enlace 'Consulta aquí nuestro Aviso'.
    """
    label=privacy_label(nodes)
    checks=[n for n in nodes if n.get('bounds') and n.get('enabled') and
            ('checkbox' in normal(n.get('class','')) or 'check_box' in normal(n.get('rid','')))]
    if label:
        lx1,ly1,lx2,ly2=label['bounds']
        mid=(ly1+ly2)//2
        checks.sort(key=lambda n:abs((n['bounds'][1]+n['bounds'][3])//2-mid))
        if checks and abs((checks[0]['bounds'][1]+checks[0]['bounds'][3])//2-mid)<max(65, (ly2-ly1)*2):
            n=checks[0]
            return (*clickpoint(n),n['checked'],True,'checkbox')
        # Si el texto es un área que responde al toque, usar su borde izquierdo.
        # Android puede exponer la fila como TextView sin click.
        if label['clickable']:
            x=lx1+max(4,min(16,(lx2-lx1)//5))
        else:
            width=(screen_size[0] if screen_size else max(400,lx2))
            x=max(6,lx1-min(40,int(width*0.04)))
        return (x,mid,False,False,'fila de consentimiento')
    # Sin etiqueta, no arriesgamos tocar un switch de mantener sesión.
    return None


def login_button_candidate(nodes):
    """Botón accesible aunque el WebView no marque clickable=true."""
    found=[]
    for n in nodes:
        label=normal(n.get('text','')+' '+n.get('desc',''))
        if (n.get('bounds') and n.get('enabled') and
                ('iniciar sesion' in label or 'inicia sesion' in label)):
            rank=int(bool(n.get('clickable')))*6+int('Button' in n.get('class',''))*3
            if 'iniciar sesion' in label:rank+=2
            found.append((rank, n['bounds'][1],n))
    good=[r for r in found if r[0]>=3]
    if not good:return None
    return max(good,key=lambda v:(v[0],v[1]))[2]


def form_matches(nodes, curp, email):
    fields=login_fields(nodes)
    if not fields:return None
    return (fields[0]['text'].strip().upper()==curp and
            fields[1]['text'].strip().lower()==email.lower())
