"""Puente Windows/ADB. No requiere paquetes pip adicionales."""
from pathlib import Path
import os, re, subprocess, shutil, struct, threading, time

BASE = Path(__file__).resolve().parent
COMMON = [
    BASE / 'platform-tools' / 'adb.exe',
    Path(os.environ.get('LOCALAPPDATA', str(BASE))) / 'GestoriaDiaz' / 'Android' / 'platform-tools' / 'adb.exe',
    Path(os.environ.get('LOCALAPPDATA', str(BASE))) / 'Android' / 'Sdk' / 'platform-tools' / 'adb.exe',
    Path('C:/platform-tools/adb.exe'), Path('C:/adb/adb.exe'),
]


def discover_adb():
    p = BASE / 'RUTA_ADB.txt'
    if p.exists():
        try:
            candidate = Path(p.read_text(encoding='utf-8-sig').strip().strip('"'))
            if candidate.is_file():
                return str(candidate)
        except (OSError, UnicodeError):
            pass
    for candidate in COMMON:
        if candidate.is_file():
            return str(candidate)
    return shutil.which('adb.exe') or shutil.which('adb')


class BridgeError(RuntimeError):
    pass


class Bridge:
    def __init__(self, adb=None):
        self.adb = adb or discover_adb()
        self.serial = None
        self._command_lock = threading.RLock()

    def call(self, *args, timeout=18, binary=False, device=False):
        """Serializa los comandos ADB y reintenta solo lecturas seguras si cae el transporte.

        Nunca repite taps, textos o códigos: duplicarlos puede alterar un trámite.
        """
        if not self.adb:
            raise BridgeError('ADB no disponible. Ejecuta ABRIR_BOT.bat o instala ADB.')
        argv = [self.adb]
        if device and self.serial:
            argv += ['-s', self.serial]
        argv += list(map(str, args))
        safe_read = bool(args) and (args[0] in ('version','devices','mdns','exec-out') or
                     (args[0]=='shell' and len(args)>1 and args[1] in ('pm','uiautomator','dumpsys','wm')))
        with self._command_lock:
            cp = self._run_command(argv, timeout)
            # Error transitorio del ADB Wi-Fi observado en el video del usuario.
            first_err = (cp.stderr + cp.stdout).decode('utf-8','replace').lower()
            if cp.returncode != 0 and safe_read and device and self.serial and any(
                phrase in first_err for phrase in ('protocol fault','device offline','device not found',
                'connection reset','closed','cannot connect')):
                # Sin reiniciar el servidor ADB ni afectar otras conexiones de Windows.
                try:
                    self._run_command([self.adb,'connect',self.serial],timeout=12)
                    time.sleep(0.35)
                    cp = self._run_command(argv, timeout)
                except BridgeError:
                    pass
            if cp.returncode != 0:
                err = cp.stderr.decode('utf-8','replace').strip() or cp.stdout.decode('utf-8','replace').strip()
                if 'protocol fault' in err.lower():
                    raise BridgeError('ADB perdió la comunicación Wi-Fi. Pulsa CONECTAR WI-FI y luego ACTUALIZAR VISTA. Detalle: '+err[:160])
                raise BridgeError(err[:450] or 'ADB devolvió un error')
            if binary:
                return cp.stdout
            return cp.stdout.decode('utf-8','replace').strip()

    def _run_command(self, argv, timeout):
        try:
            return subprocess.run(argv, capture_output=True, timeout=timeout, stdin=subprocess.DEVNULL,
                                  creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except subprocess.TimeoutExpired as exc:
            raise BridgeError('ADB tardó demasiado. Comprueba la depuración Wi-Fi.') from exc
        except OSError as exc:
            raise BridgeError('No se pudo ejecutar ADB: '+str(exc)) from exc

    def version(self):
        return self.call('version',timeout=8)

    def devices(self):
        raw = self.call('devices','-l',timeout=10)
        devices=[]
        for line in raw.splitlines()[1:]:
            spl=line.split()
            if len(spl)>1 and spl[1]=='device':
                devices.append(spl[0])
        return devices,raw

    def mdns_ports(self, ip):
        """Busca puertos de CONEXIÓN anunciados por Android, nunca los de vinculación."""
        try:
            out=self.call('mdns','services',timeout=12)
        except BridgeError:
            return []
        ports=[]
        for line in out.splitlines():
            if '_adb-tls-connect._tcp' not in line.lower():
                continue
            for found_ip,found_port in re.findall(r'(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})',line):
                if found_ip==ip and found_port not in ports:
                    ports.append(found_port)
        return ports

    def connect(self, ip, port):
        ip=ip.strip()
        if not re.fullmatch(r'(?:\d{1,3}\.){3}\d{1,3}',ip) or any(int(o)>255 for o in ip.split('.')):
            raise BridgeError('IP inválida. Ejemplo: 192.168.1.8')
        port=str(port).strip()
        if not port.isdecimal() or not 1<=int(port)<=65535:
            raise BridgeError('Puerto inválido. Utiliza el de Dirección IP y puerto, no el de vinculación.')
        endpoint=f'{ip}:{port}'
        answer=self.call('connect',endpoint,timeout=20)
        if 'connected' not in answer.lower() and 'already connected' not in answer.lower():
            raise BridgeError('ADB no confirmó la conexión: '+answer)
        # ADB puede tardar unos instantes en pasar de offline a device.
        for attempt in range(4):
            devices,_ = self.devices()
            if endpoint in devices:
                break
            time.sleep(0.4)
        else:
            raise BridgeError('El teléfono todavía no figura como autorizado. Revisa la depuración inalámbrica de Android.')
        self.serial=endpoint
        return answer

    def use_device(self, serial):
        devices,_=self.devices()
        if serial not in devices:
            raise BridgeError('Dispositivo no está conectado/autorizado.')
        self.serial=serial
        return serial

    def pair(self, ip,port, code):
        if not str(port).isdigit() or not 1<=int(port)<=65535:
            raise BridgeError('Puerto de vinculación inválido.')
        if not (len(str(code).strip())==6 and str(code).strip().isdigit()):
            raise BridgeError('El código de vinculación de Android debe tener seis dígitos.')
        return self.call('pair',f'{ip.strip()}:{port}',str(code).strip(),timeout=28)

    def screenshot(self):
        data=self.call('exec-out','screencap','-p',timeout=17,binary=True,device=True)
        if not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise BridgeError('Android no devolvió una captura PNG.')
        w,h=struct.unpack('>II',data[16:24]);return data,w,h

    def tap(self,x,y):
        return self.call('shell','input','tap',int(x),int(y),timeout=10,device=True)

    def type_text(self,s):
        if not s or not re.fullmatch(r'[a-zA-Z0-9@._+-]+',s):
            raise BridgeError('Texto inválido para entrada ADB; revisa el correo/CURP.')
        return self.call('shell','input','text',s,timeout=12,device=True)

    def key(self,n):
        return self.call('shell','input','keyevent',str(n),timeout=10,device=True)

    def replace_focused_text(self, value, prior_length=None, force_backspace=False):
        """Replace existing input, never append another CURP or email."""
        if not value or not re.fullmatch(r'[a-zA-Z0-9@._+-]+', value):
            raise BridgeError('Texto no válido para el teclado Android.')
        if not force_backspace:
            try:
                out=self.call('shell','input','keycombination','113','29',timeout=9,device=True)
                if any(term in out.lower() for term in ('usage:', 'unknown', 'error:')):
                    raise BridgeError('Combinación no disponible')
                self.key(67)
            except BridgeError:
                force_backspace=True
        if force_backspace:
            # Cursor al final + borrados; un único comando ADB evita demoras Wi-Fi.
            n=max(40,min(110,(int(prior_length) if prior_length else 90)+8))
            self.call('shell','input','keyevent','123',*(['67']*n),timeout=32,device=True)
        self.type_text(value)
        return True

    def enter_device_pin(self, pin):
        """Único intento por pantalla confirmada; evita registrar el valor."""
        if not (len(pin)==4 and pin.isascii() and pin.isdecimal()):
            raise BridgeError('La configuración local del PIN no es válida.')
        # Android KEYCODE_0=7 .. KEYCODE_9=16; KEYCODE_ENTER=66.
        codes=[str(7+int(d)) for d in pin]+['66']
        return self.call('shell','input','keyevent',*codes,timeout=16,device=True)

    def digits(self,code):
        code=str(code).strip()
        if not (len(code)==6 and code.isascii() and code.isdecimal()):
            raise BridgeError('El código IMSS debe tener exactamente seis dígitos.')
        # KEYCODE_0=7, KEYCODE_1=8, ..., KEYCODE_9=16.
        # Son pulsaciones de Android sobre el campo actual, no un teclado artificial.
        for d in code:
            self.key(7+int(d))
        return True

    def dump(self):
        # En algunos teléfonos uiautomator falla al estar abierto un teclado protegido.
        # Nunca permite ignorar validaciones de identidad.
        try:
            out=self.call('shell','uiautomator','dump','/dev/tty',timeout=14,device=True)
            if '<hierarchy' in out:
                return out[out.find('<hierarchy'):]
        except BridgeError:
            pass
        try:
            self.call('shell','uiautomator','dump','/sdcard/window.xml',timeout=14,device=True)
            out=self.call('exec-out','cat','/sdcard/window.xml',timeout=12,device=True)
            if '<hierarchy' in out:
                return out[out.find('<hierarchy'):]
        except BridgeError:
            pass
        return ''

    def launch_imss(self):
        """Abre SOLO el paquete oficial; 'imss' en otros paquetes puede significar IMS de Android."""
        pkg='st.android.imsspublico'
        path=self.call('shell','pm','path',pkg,timeout=13,device=True)
        if 'package:' not in path:
            raise BridgeError('No encontré la aplicación oficial IMSS Digital ('+pkg+'). Instálala desde Google Play.')
        result=self.call('shell','monkey','-p',pkg,'-c','android.intent.category.LAUNCHER','1',timeout=16,device=True)
        if 'No activities found' in result or 'monkey aborted' in result.lower():
            raise BridgeError('IMSS Digital está instalado, pero Android no permitió abrirlo. Ábrelo manualmente una vez.')
        return pkg
