# -*- coding: utf-8 -*-
"""Gestoría Díaz / IMSS: interfaz simple sobre el flujo V6 validado localmente.
Enlace local opcional con Outlook. Sin contraseñas de correo ni webhooks externos.
"""
from __future__ import annotations
import re, secrets, threading, tkinter as tk
from tkinter import ttk, messagebox
from imss_v6_base import App as BaseApp, BLACK, PANEL, GOLD, WHITE, GRAY, get_config
from imss_core import nodes_from_xml, stage, edits, clickpoint, node_match
from adb_bridge import BridgeError
from enlace import Client, LinkError
from outlook_queue_reader import next_new_selected

class App(BaseApp):
    def __init__(self):
        self.link=Client(timeout=0.9)
        self.link_id=None
        self.link_registered=False
        self.code_automatic_attempt=False
        self.link_running=False
        self._last_link_info=''
        self._auto_email_enabled=True
        self._otp_verify_in_progress=False
        super().__init__()
        self.title('GESTORÍA DÍAZ · IMSS Digital · Panel sencillo + Outlook')
        self.geometry('1100x740')
        self.after(1300,self.link_tick)

    def make_layout(self):
        style=ttk.Style(self)
        if 'clam' in style.theme_names(): style.theme_use('clam')
        style.configure('TEntry',fieldbackground='#FAFAFA',foreground='#111111',padding=5)
        style.configure('TButton',font=('Segoe UI',10),padding=(11,7))
        style.configure('Gold.TButton',background=GOLD,foreground=BLACK,
                        font=('Segoe UI',10,'bold'),padding=(12,9))
        style.map('Gold.TButton',background=[('active','#efd196')])
        header=tk.Frame(self,bg=BLACK);header.pack(fill='x',padx=18,pady=(12,8))
        tk.Label(header,text='GESTORÍA DÍAZ',bg=BLACK,fg=GOLD,font=('Segoe UI',22,'bold')).pack(side='left')
        tk.Label(header,text='SEMANAS COTIZADAS · IMSS',bg=BLACK,fg=WHITE,font=('Segoe UI',11)).pack(side='right')
        body=tk.Frame(self,bg=BLACK);body.pack(fill='both',expand=True,padx=16,pady=5)
        leftwrap=tk.Frame(body,bg=PANEL)
        leftwrap.pack(side='left',fill='both',expand=True,padx=(0,12))
        leftcanvas=tk.Canvas(leftwrap,bg=PANEL,highlightthickness=0,bd=0)
        leftscroll=ttk.Scrollbar(leftwrap,orient='vertical',command=leftcanvas.yview)
        leftcanvas.configure(yscrollcommand=leftscroll.set)
        leftscroll.pack(side='right',fill='y')
        leftcanvas.pack(side='left',fill='both',expand=True)
        left=tk.Frame(leftcanvas,bg=PANEL,padx=14,pady=13)
        leftwindow=leftcanvas.create_window((0,0),window=left,anchor='nw')
        left.bind('<Configure>',lambda event:leftcanvas.configure(scrollregion=leftcanvas.bbox('all')))
        leftcanvas.bind('<Configure>',lambda event:leftcanvas.itemconfigure(leftwindow,width=event.width))
        def on_wheel(event):
            leftcanvas.yview_scroll(int(-event.delta/120), 'units')
        def wheel_bind(_): self.bind_all('<MouseWheel>',on_wheel)
        def wheel_unbind(_): self.unbind_all('<MouseWheel>')
        leftwrap.bind('<Enter>',wheel_bind)
        leftwrap.bind('<Leave>',wheel_unbind)
        right=tk.Frame(body,bg=PANEL,padx=11,pady=12,width=330);right.pack(side='right',fill='both');right.pack_propagate(False)
        def sect(text):tk.Label(left,text=text,bg=PANEL,fg=GOLD,font=('Segoe UI',11,'bold')).pack(anchor='w',pady=(6,4))
        def entbox(parent,label,var,width):
            c=tk.Frame(parent,bg=PANEL);c.pack(side='left',padx=(0,8),fill='x',expand=True)
            tk.Label(c,text=label,bg=PANEL,fg=GRAY,font=('Segoe UI',9)).pack(anchor='w')
            e=ttk.Entry(c,textvariable=var,width=width);e.pack(fill='x');return e
        def toolbar(parent,buttons):
            f=tk.Frame(parent,bg=PANEL);f.pack(anchor='w',fill='x',pady=(5,4))
            for name,fn,accent in buttons:
                ttk.Button(f,text=name,command=fn,style='Gold.TButton' if accent else 'TButton').pack(side='left',padx=(0,6))
        sect('1 · CONECTAR EL CELULAR')
        row=tk.Frame(left,bg=PANEL);row.pack(fill='x')
        entbox(row,'IP del HONOR',self.ip,19);entbox(row,'Puerto Wi-Fi',self.port,11)
        toolbar(left,[('CONECTAR',self.connect,True),('DETECTAR',self.detect,False),('VINCULAR',self.pair,False)])
        sect('2 · DATOS DEL TRÁMITE')
        self.auto_email_var=tk.BooleanVar(master=self,value=True)
        tk.Checkbutton(left,text='Tomar el siguiente correo NUEVO seleccionado en Outlook V12',
             variable=self.auto_email_var,bg=PANEL,fg=WHITE,activebackground=PANEL,
             activeforeground=WHITE,selectcolor='#273544',font=('Segoe UI',9)).pack(anchor='w',pady=(1,3))
        self.queue_status=tk.StringVar(master=self,value='Correos Outlook: sin consultar')
        tk.Label(left,textvariable=self.queue_status,bg=PANEL,fg='#97d2bd',
                 font=('Segoe UI',9),anchor='w').pack(fill='x')
        toolbar(left,[('SIGUIENTE CORREO NUEVO',self.pick_next_email,False),
                      ('CONSULTAR LISTA OUTLOOK',self.refresh_queue_info,False)])
        row=tk.Frame(left,bg=PANEL);row.pack(fill='x')
        entbox(row,'CURP',self.curp,19);entbox(row,'Correo de verificación',self.correo,28)
        toolbar(left,[('ABRIR IMSS',self.open_imss,False),('INICIAR TRÁMITE',self.start_flow,True),('REANUDAR',self.resume_flow,False),('DETENER',self.stop_flow,False)])
        sect('3 · CÓDIGO DE VERIFICACIÓN')
        row=tk.Frame(left,bg=PANEL);row.pack(fill='x')
        entbox(row,'Código IMSS (6 dígitos; manual o desde Outlook)',self.code,20)
        toolbar(left,[('ENVIAR CÓDIGO',self.send_code,True),('VERIFICAR',self.verify_code,False)])
        self.auto_verify_var=tk.BooleanVar(master=self,value=True)
        tk.Checkbutton(left,text='Al recibir código de Outlook: verificar y continuar automáticamente si el botón es visible',
                       variable=self.auto_verify_var,bg=PANEL,fg=WHITE,activebackground=PANEL,
                       activeforeground=WHITE,selectcolor='#273544',font=('Segoe UI',9),
                       wraplength=620,justify='left').pack(anchor='w',pady=(0,4))
        self.link_status=tk.StringVar(value='Outlook: comprobando conexión local…')
        tk.Label(left,textvariable=self.link_status,bg=PANEL,fg='#97d2bd',font=('Segoe UI',9),
                 wraplength=635,justify='left').pack(anchor='w',pady=(4,7))
        toolbar(left,[('VINCULAR BOT OUTLOOK',self.register_with_outlook,False),
                      ('ACTUALIZAR VISTA',self.refresh,False)])
        self.advanced=tk.Frame(left,bg=PANEL)
        self.adv_visible=False
        tk.Button(left,text='▸ Herramientas / calibración',bg=PANEL,fg=GRAY,relief='flat',
                  font=('Segoe UI',9),anchor='w',command=self.toggle_advanced).pack(anchor='w',pady=(4,1))
        toolbar(self.advanced,[('CORREGIR CURP/CORREO',self.refill_login,False),
                               ('ACEPTAR PRIVACIDAD',self.accept_and_login,False)])
        toolbar(self.advanced,[('CALIBRAR FORMULARIO',self.calibrate_form,False),
                               ('CALIBRAR PRIVACIDAD',self.calibrate_privacy,False)])
        toolbar(self.advanced,[('SÍ CAMBIAR DISPOSITIVO',self.accept_device_change,False),
                               ('CALIBRAR SÍ',self.calibrate_change,False),
                               ('MARCAR PRIMERA CASILLA',self.calibrate,False)])
        tk.Label(left,text='ESTADO / DIAGNÓSTICO',bg=PANEL,fg=GOLD,font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(5,4))
        self.logbox=tk.Text(left,height=7,bg='#0F141B',fg='#DFE2E7',insertbackground=GOLD,
                            font=('Consolas',9),wrap='word',relief='flat')
        self.logbox.pack(fill='both',expand=True);self.logbox.configure(state='disabled')
        tk.Label(right,text='PANTALLA DEL CELULAR',bg=PANEL,fg=GOLD,font=('Segoe UI',11,'bold')).pack(anchor='w')
        tk.Label(right,text='Puedes tocar la imagen para controlar tu HONOR.',bg=PANEL,fg=GRAY,
                 font=('Segoe UI',9),wraplength=300).pack(anchor='w',pady=3)
        self.canvas=tk.Canvas(right,width=318,height=610,bg='#070A0D',highlightthickness=1,highlightbackground='#615438')
        self.canvas.pack(fill='both',expand=True,pady=5)
        self.canvas.bind('<Button-1>',self.preview_click)
        footer=tk.Frame(self,bg=BLACK);footer.pack(fill='x',padx=16,pady=(0,7))
        tk.Label(footer,textvariable=self.status,bg=BLACK,fg=GOLD,font=('Segoe UI',10)).pack(side='left')
        if self.bridge.adb:self.log('ADB encontrado. Bot IMSS listo para conectar.')
        else:self.log('ADB no está disponible. Abre ABRIR_BOT.bat para prepararlo.')
        self.log('Tu PIN anterior permanece configurado en esta copia PERSONAL. No compartas el ZIP.')
        self.after(950,self.refresh_queue_info)

    def toggle_advanced(self):
        self.adv_visible=not self.adv_visible
        if self.adv_visible:self.advanced.pack(fill='x',before=self.logbox)
        else:self.advanced.pack_forget()

    def refresh_queue_info(self):
        try:
            email, count=next_new_selected()
            self.queue_status.set(f'Outlook V12: {count} cuenta(s) NUEVAS seleccionadas' if email
                                  else 'Outlook V12: sin cuentas NUEVAS seleccionadas')
        except Exception as ex:
            self.queue_status.set('Outlook V12: lista no disponible ('+str(ex)[:65]+')')

    def pick_next_email(self):
        try:
            email, count=next_new_selected()
        except Exception as ex:
            messagebox.showwarning('Outlook V12','No pude consultar la lista: '+str(ex)[:170]);return
        if not email:
            messagebox.showinfo('Outlook V12','Abre Outlook V12, importa el TXT y pulsa SELECCIONAR TODOS en su lista de cuentas NUEVAS.');return
        self.correo.set(email)
        self.queue_status.set(f'{count} cuentas NUEVAS seleccionadas · siguiente: {email}')
        self.log('Correo NUEVO seleccionado del listado Outlook V12. El estado no se modificó.')

    def _resolve_email_for_new_request(self):
        if not self.auto_email_var.get():
            return self.correo.get().strip().lower()
        try:
            email,count=next_new_selected()
        except Exception as ex:
            raise ValueError('No se pudo consultar la lista de Outlook V12: '+str(ex)[:125]) from ex
        if not email:
            raise ValueError('Outlook V12 no tiene correos NUEVOS seleccionados. Selecciónalos allí o desactiva la opción automática.')
        self.correo.set(email)
        self.queue_status.set(f'{count} NUEVOS seleccionados · correo asignado: {email}')
        return email

    def do_device_change(self,nodes,manual=False):
        # Nunca desvincular el equipo anterior de un titular sin confirmar en persona.
        if not manual:
            return ('IMSS pide vincular esta CURP al HONOR, lo que puede desvincular el '
                    'dispositivo anterior. Confirma con el titular y usa la opción '
                    'SÍ CAMBIAR DISPOSITIVO de Herramientas.')
        return super().do_device_change(nodes,manual=True)

    def register_with_outlook(self):
        email=self.correo.get().strip().lower()
        if not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email):
            messagebox.showerror('Correo','Escribe primero el correo del trámite.');return
        if self.link_registered and self.link_id:
            self.link_status.set('Outlook ya enlazado para esta solicitud.');return
        self.link_id=secrets.token_hex(16)
        self._link_register_async(email,self.link_id)

    def _link_register_async(self,email,req_id):
        def work():
            try:
                self.link.begin(email,req_id)
                self.after(0,lambda:self._link_registration_result(True,''))
            except Exception as ex:
                msg=str(ex)[:150]
                self.after(0,lambda:self._link_registration_result(False,msg))
        threading.Thread(target=work,daemon=True).start()

    def _link_registration_result(self,success,message):
        self.link_registered=success
        if success:
            self.link_status.set('Outlook conectado: esperando el código del mismo correo.')
            self.log('Solicitud conectada con Outlook por 127.0.0.1. No se compartió la CURP.')
        else:
            self.link_status.set('Outlook no está abierto; puedes escribir el código aquí. '+message)

    def start_flow(self):
        if self._busy or self._login_busy:
            self.log('Espera a que finalice el paso actual antes de iniciar otro trámite.');return
        curp=self.curp.get().strip().upper()
        if not re.fullmatch(r'[A-Z0-9]{18}',curp):
            messagebox.showerror('Datos','Escribe una CURP válida de 18 caracteres.');return
        try: email=self._resolve_email_for_new_request()
        except ValueError as ex:
            messagebox.showwarning('Outlook V12',str(ex));return
        if not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email):
            messagebox.showerror('Datos','Escribe un correo válido.');return
        # Se inicia una nueva solicitud por cada trámite. No reutilizar códigos antiguos.
        self.link_registered=False;self.code_automatic_attempt=False;self.link_id=secrets.token_hex(16)
        self._link_register_async(email,self.link_id)
        super().start_flow()

    def resume_flow(self):
        """Continúa desde la pantalla actual, sin reiniciar el enlace a Outlook."""
        if self._busy or self._login_busy:
            self.log('Espera a que termine la acción actual.');return
        curp=self.curp.get().strip().upper();email=self.correo.get().strip()
        if not re.fullmatch(r'[A-Z0-9]{18}',curp) or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',email):
            messagebox.showerror('Datos','CURP o correo inválidos.');return
        self._flow_stop.clear();self._seen={};self._busy=True
        self.log('Reanudando desde la pantalla actual, sin reenviar el correo ni el código.')
        self.task(lambda:self.flow(curp,email),lambda answer:self.log(answer))

    def flow(self,curp,email):
        result=super().flow(curp,email)
        if self.link_id and result and 'Solicitud enviada;' in result:
            try:self.link.done(self.link_id)
            except LinkError:pass
        return result

    def link_tick(self):
        # El sondeo es un canal local; no bloquea ni repite órdenes ADB.
        try:
            if self.link_id and self.link_registered and not self.link_running:
                self.link_running=True
                req_id=self.link_id
                threading.Thread(target=self._check_link,args=(req_id,),daemon=True).start()
        finally:
            self.after(2400,self.link_tick)

    def _check_link(self,req_id):
        try:
            data=self.link.status(req_id)
            self.after(0,lambda:self._received_status(req_id,data))
        except Exception:
            pass
        finally:self.after(0,lambda:setattr(self,'link_running',False))

    def _received_status(self,req_id,data):
        if req_id!=self.link_id:return
        state=data.get('status','')
        if state=='CADUCADA':
            self.link_status.set('La solicitud de Outlook caducó. Reinicia el trámite para un código nuevo.')
            return
        if state=='CODIGO_DISPONIBLE' and data.get('code') and not self.code_automatic_attempt:
            code=str(data['code'])
            if not re.fullmatch('[0-9]{6}',code):return
            self.code.set(code)
            self.code_automatic_attempt=True
            self.link_status.set('Código recibido de Outlook. Intentando introducirlo en IMSS…')
            self._send_link_code(req_id,code)
        elif state=='SOLICITUD_IMSS_ENVIADA':
            self.link_status.set('IMSS solicitó las semanas. Revisa en Outlook el PDF de Historia Laboral.')

    def _send_link_code(self,req_id,code):
        """Transfiere el código por ADB una sola vez, sin duplicar toques.

        Si todavía no se ve el formulario OTP, mantiene pendiente el código
        hasta que aparezca; un fallo a mitad de escritura exige revisión manual.
        """
        auto_verify=bool(self.auto_verify_var.get())
        def work():
            nodes=nodes_from_xml(self.bridge.dump())
            if stage(nodes)!='CODIGO':
                return 'ESPERAR',False
            cfg=get_config();first=cfg.get('otp_first')
            if first:
                _,w,h=self.bridge.screenshot()
                self.bridge.tap(int(first[0]*w),int(first[1]*h))
            else:
                ins=edits(nodes)
                if not ins:raise BridgeError('Calibra la primera casilla en Herramientas (una sola vez).')
                self.bridge.tap(*clickpoint(ins[0]))
            import time
            time.sleep(.25)
            self.bridge.digits(code)
            clicked=False
            if auto_verify:
                time.sleep(.55)
                fresh=nodes_from_xml(self.bridge.dump())
                if stage(fresh)=='CODIGO':
                    btn=node_match(fresh,['verificar','validar codigo'])
                    if btn:
                        self.bridge.tap(*clickpoint(btn))
                        clicked=True
            return 'ESCRITO',clicked
        def done(result):
            status,clicked=result
            if status=='ESPERAR':
                self.code_automatic_attempt=False
                self.link_status.set('Código recibido. Esperando que IMSS muestre las seis casillas…')
                return
            try:self.link.ack(req_id)
            except LinkError:pass
            self.code.set('')
            if clicked:
                self.link_status.set('Código introducido; se pulsó Verificar una vez. Esperando respuesta…')
                self.log('Código introducido en IMSS y botón Verificar pulsado una sola vez.')
                threading.Thread(target=self._await_code_result,args=(req_id,),daemon=True).start()
            else:
                self.link_status.set('Código enviado al HONOR. Revisa las casillas y pulsa VERIFICAR si IMSS no avanzó.')
            self.refresh()
        def task():
            try:r=work();self.after(0,lambda:done(r))
            except Exception as e:
                text=str(e)[:180]
                self.after(0,lambda:self._code_error(text))
        threading.Thread(target=task,daemon=True).start()

    def _await_code_result(self,req_id):
        import time
        # No volver a pulsar Verificar. Solo mirar si la aplicación avanzó.
        for _ in range(12):
            if self._flow_stop.is_set() or req_id!=self.link_id:return
            time.sleep(1.1)
            try:next_stage=stage(nodes_from_xml(self.bridge.dump()))
            except Exception:continue
            if next_stage in ('CODIGO','DESCONOCIDA'):continue
            self.after(0,lambda stage_name=next_stage:self._continue_after_code(req_id,stage_name))
            return
        self.after(0,lambda:self.link_status.set('IMSS no confirmó el avance; revisa el HONOR y pulsa REANUDAR si corresponde.'))

    def _continue_after_code(self,req_id,stage_name):
        if self.link_id!=req_id or self._busy:return
        self.link_status.set('IMSS avanzó a '+stage_name+'. Continuando desde esta pantalla…')
        self.resume_flow()

    def _code_error(self,msg):
        # Evitar un segundo envío automático si una pulsación pudo haberse aplicado.
        self.code_automatic_attempt=True
        self.link_status.set('No se completó automáticamente. Revisa las casillas. '+msg)
        self.log('Revisa las casillas: no se repetirán automáticamente las pulsaciones del código.')

if __name__=='__main__':App().mainloop()
