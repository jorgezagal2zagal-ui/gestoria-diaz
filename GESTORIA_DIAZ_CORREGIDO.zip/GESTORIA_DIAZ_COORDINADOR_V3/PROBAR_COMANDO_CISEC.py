# -*- coding: utf-8 -*-
"""Prueba LOCAL del comando. No conecta con grupos ni chats externos."""
import re, sys, os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'OUTLOOK'))
from credenciales import WindowsDPAPI
from cola_privada import Requests

def parse_command(text):
    m=re.fullmatch(r'\s*/CISEC\s+([A-Z0-9]{18})\s*',text.strip().upper())
    if not m:raise ValueError('Formato: /CISEC CURP (18 caracteres).')
    return m.group(1)

def main():
    if os.name!='nt':raise SystemExit('Requiere Windows y el mismo usuario del coordinador.')
    db=Requests(WindowsDPAPI())
    print('PRUEBA LOCAL /CISEC. Esto NO escucha Telegram, WhatsApp ni Discord.')
    print('Escribe /CISEC seguido de CURP autorizada; salir para cerrar.')
    while True:
        try:line=input('> ').strip()
        except (EOFError,KeyboardInterrupt):break
        if line.lower() in ('salir','exit'):break
        try:
            curp=parse_command(line)
            rid=db.enqueue(curp)
            print('Recibido. Folio:',rid[:8],'- agregado a la cola del coordinador.')
        except Exception as exc:print(str(exc))
if __name__=='__main__':main()
