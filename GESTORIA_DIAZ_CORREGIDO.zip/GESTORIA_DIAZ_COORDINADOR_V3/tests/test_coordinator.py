import sys, tempfile, unittest, threading, os
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
_runtime=tempfile.TemporaryDirectory()
os.environ['LOCALAPPDATA']=_runtime.name
from COORDINADOR import Coordinator
from cola_privada import Requests
from queue_store import QueueStore

class Protector:
    def protect(self,s):return s.encode()
    def unprotect(self,s):return s.decode()

class Regression(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.jobs=Requests(Protector(),Path(self.tmp.name)/'jobs.db')
        self.accounts=QueueStore(Path(self.tmp.name)/'accounts.db')
        self.accounts.add(['one@example.com','two@example.com']);self.accounts.select_all()
        self.fake=SimpleNamespace(jobs=self.jobs,accounts=self.accounts,
            vault=SimpleNamespace(has_password=lambda _:True),note=Mock())
    def enqueue(self):return self.jobs.enqueue('AAAA000101HDFBBB01')
    def test_attention_and_error_keep_email_reserved(self):
        for status in ('REQUIERE_ATENCION','ERROR'):
            with self.subTest(status=status):
                old=self.enqueue();self.jobs.set(old,status,email='one@example.com')
                new=self.enqueue();Coordinator.reserve_pending_emails(self.fake)
                self.assertEqual(self.jobs.get(new)['email'],'two@example.com')
                self.jobs.set(new,'CANCELADA');self.jobs.set(old,'CANCELADA')
    def test_excluded_first_job_does_not_starve_next(self):
        first=self.enqueue()
        for email in ('one@example.com','two@example.com'):self.jobs.skip_email(first,email)
        second=self.enqueue();Coordinator.reserve_pending_emails(self.fake)
        self.assertIsNone(self.jobs.get(first)['email'])
        self.assertEqual(self.jobs.get(second)['email'],'one@example.com')
    def test_mail_change_retains_folio_and_curp_across_restart(self):
        jid=self.enqueue();before=self.jobs.get(jid)
        self.jobs.set(jid,'REQUIERE_ATENCION',email='one@example.com')
        self.jobs.skip_email(jid,'one@example.com')
        self.jobs.set(jid,'PENDIENTE',email='two@example.com')
        reopened=Requests(Protector(),self.jobs.path)
        self.assertEqual(reopened.get(jid)['curp'],before['curp'])
        self.assertEqual(reopened.get(jid)['id'],jid)
        self.assertIn('one@example.com',reopened.skipped_emails(jid))
    def test_crash_recovery_does_not_replay_imss(self):
        jid=self.enqueue();self.jobs.set(jid,'ESPERANDO_CODIGO',email='one@example.com')
        self.jobs.recover();self.jobs.recover()
        self.assertEqual(self.jobs.get(jid)['status'],'REQUIERE_ATENCION')
        self.assertEqual(self.jobs.oldest_pending(),(None,None))
    @patch('COORDINADOR.record')
    def test_pulse_exception_preserves_job_and_reschedules(self,record):
        jid=self.enqueue()
        f=SimpleNamespace(messages=__import__('queue').Queue(),logbox=Mock(),
            active_id=jid,jobs=self.jobs,_flow_stop=threading.Event(),note=Mock(),after=Mock(),_pulse=Mock())
        f.messages.put(('log','synthetic log'))
        f.logbox.configure.side_effect=RuntimeError('failure')
        f._pulse_once=lambda:Coordinator._pulse_once(f)
        Coordinator._pulse(f)
        self.assertTrue(f._flow_stop.is_set())
        self.assertEqual(self.jobs.get(jid)['status'],'REQUIERE_ATENCION')
        f.after.assert_called_once_with(1100,f._pulse)
        record.assert_called_once()
    def test_pulse_success_reschedules_once(self):
        f=SimpleNamespace(_pulse_once=Mock(),after=Mock(),_pulse=Mock())
        Coordinator._pulse(f);f.after.assert_called_once_with(1100,f._pulse)
    def test_device_change_requires_explicit_consent(self):
        f=SimpleNamespace(active_id='test',device_change_processing=False,_busy=False,_login_busy=False,note=Mock(),bridge=Mock())
        with patch('COORDINADOR.messagebox.askyesno',return_value=False):
            Coordinator.confirm_change(f)
        f.bridge.dump.assert_not_called()


class BrowserLifecycle(unittest.TestCase):
    def test_context_failure_keeps_original_diagnostic_and_closes_browser(self):
        import navegador, json
        events=[]
        browser=Mock();browser.new_context.side_effect=RuntimeError('SECRET_NOT_FOR_LOGS')
        manager=Mock();manager.__enter__=Mock(return_value=Mock());manager.__exit__=Mock(return_value=False)
        with tempfile.TemporaryDirectory() as d, \
             patch('playwright.sync_api.sync_playwright',return_value=manager), \
             patch('navegador.launch_private_browser',return_value=browser), \
             patch('pathlib.Path.home',return_value=Path(d)):
            engine=navegador.BrowserLogin(events.append);engine.running=True
            engine._worker('synthetic@example.com','SYNTHETIC_PASSWORD')
            data=(Path(d)/'GestoriaDiaz_Outlook_error.txt').read_text()
            self.assertNotIn('UnboundLocalError',data)
            self.assertEqual(json.loads(data)['type'],'RuntimeError')
            self.assertNotIn('SECRET_NOT_FOR_LOGS',data)
            self.assertNotIn('synthetic@example.com',data)
            self.assertNotIn('SYNTHETIC_PASSWORD',data)
        self.assertFalse(engine.running);browser.close.assert_called_once()

class Privacy(unittest.TestCase):
    def test_diagnostics_do_not_include_exception_values(self):
        import diagnostico, json, logging
        with tempfile.TemporaryDirectory() as d, patch.dict(os.environ,{'LOCALAPPDATA':d}):
            logger=logging.getLogger('gestoria.diagnostics')
            for handler in logger.handlers[:]:handler.close();logger.removeHandler(handler)
            try:raise ValueError('PRIVATE_CUSTOMER_DATA')
            except ValueError as exc:diagnostico.record('test_failure',exc)
            data=next(Path(d).rglob('events.jsonl')).read_text()
            self.assertNotIn('PRIVATE_CUSTOMER_DATA',data)
            self.assertEqual(json.loads(data)['type'],'ValueError')
            for handler in logger.handlers[:]:handler.close();logger.removeHandler(handler)

class Dispatch(unittest.TestCase):
    def make_ready(self):
        jid='synthetic-folio'
        jobs=Mock();jobs.oldest_pending.return_value=(jid,'SYNTHETIC_CURP')
        jobs.get.return_value={'email':'synthetic@example.com'}
        f=SimpleNamespace(active_id=None,_busy=False,_login_busy=False,
            reserve_pending_emails=Mock(),jobs=jobs,local_server=Mock(),
            bridge=SimpleNamespace(serial='fake-device'),
            mail_browser=SimpleNamespace(rate_limited=False,running=False,sender='sender@example.com',start=Mock()),
            cooldown=SimpleNamespace(remaining=lambda:0),vault=SimpleNamespace(password=lambda _:'fake'),
            _update_device_banner=Mock(),correo=Mock(),curp=Mock(),notice=Mock(),note=Mock(),accounts=Mock())
        return f
    @patch('COORDINADOR.threading.Thread')
    def test_ready_phone_dispatches_without_manual_button(self,thread):
        f=self.make_ready();Coordinator.start_next(f)
        self.assertEqual(f.active_id,'synthetic-folio')
        f.mail_browser.start.assert_called_once_with('synthetic@example.com','fake')
        f.jobs.set.assert_called_once_with('synthetic-folio','ACTIVA',email='synthetic@example.com')
        thread.return_value.start.assert_called_once()
    def test_busy_phone_does_not_start_second_request(self):
        f=self.make_ready();f._busy=True;Coordinator.start_next(f)
        f.mail_browser.start.assert_not_called()
    def test_microsoft_rate_limit_prevents_dispatch(self):
        f=self.make_ready();f.mail_browser.rate_limited=True;Coordinator.start_next(f)
        f.mail_browser.start.assert_not_called()

if __name__=='__main__':unittest.main(verbosity=2)
