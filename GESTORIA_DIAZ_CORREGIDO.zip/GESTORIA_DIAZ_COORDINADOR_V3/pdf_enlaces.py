# -*- coding: utf-8 -*-
"""Lectura conservadora de enlaces IMSS. Nunca abre dominios arbitrarios.

El remitente y la fecha del correo deben ser verificables. Descarga solo PDF
real desde imss.gob.mx, limita tamaño y no publica resultados al cliente.
"""
from __future__ import annotations
import hashlib, re, secrets
from html.parser import HTMLParser
from urllib.parse import parse_qs
from pathlib import Path
from urllib.parse import urlparse, urljoin

MAX_SIZE=15*1024*1024
WORDS=re.compile(r'(?:IMSS|historia\s+laboral|semanas\s+cotizadas|reporte\s+de\s+semanas)',re.I)


def official_imss(url: str) -> bool:
    try:
        p=urlparse(url.strip())
        host=(p.hostname or '').lower().rstrip('.')
        return (p.scheme=='https' and p.username is None and p.password is None
                and (p.port is None or p.port==443)
                and (host=='imss.gob.mx' or host.endswith('.imss.gob.mx')))
    except (ValueError,AttributeError):
        return False


def is_pdf(data: bytes) -> bool:
    return isinstance(data,bytes) and 100 <= len(data) <= MAX_SIZE and data[:1024].lstrip().startswith(b'%PDF-') and b'%%EOF' in data[-2048:]


def unwrap_official_link(url: str) -> str | None:
    """Acepta enlaces directos IMSS o Safe Links de Microsoft que los envuelven.

    Jamás se navega por el dominio Safe Links: únicamente se extrae el destino
    codificado y se valida como una URL oficial del IMSS.
    """
    if official_imss(url):return url
    try:
        parsed=urlparse(url)
        host=(parsed.hostname or '').lower()
        if parsed.scheme!='https' or (host!='safelinks.protection.outlook.com' and
             not host.endswith('.safelinks.protection.outlook.com')):
            return None
        target=parse_qs(parsed.query).get('url',[''])[0]
        return target if official_imss(target) else None
    except (ValueError,AttributeError):return None


def find_official_link(page, sender, started, seen_ids):
    """Se ejecuta en el hilo Playwright de Outlook, sobre su bandeja abierta.

    Ante remitente o fecha no verificables no continúa. Solo mensajes recibidos
    después de la solicitud IMSS y con remitente exacto.
    """
    import navegador
    if not navegador.is_outlook_mail_url(page.url) or not sender or not navegador.iso_dt(started):return None
    rows=[]
    # No utilizar visible_inbox_rows de códigos: no detecta "Historia Laboral".
    for selector in ('[role="option"]','[data-convid]','[data-item-id]','[role="row"]'):
        try:
            items=page.locator(selector)
            for n in range(min(items.count(),80)):
                item=items.nth(n)
                if item.is_visible():
                    summary=(item.inner_text(timeout=800) or '')[:650]
                    if WORDS.search(summary):rows.append((item,summary))
            if rows:break
        except Exception:continue
    for row,summary in rows:
        try:
            identifier=row.get_attribute('data-item-id') or row.get_attribute('data-convid') or summary[:180]
            if identifier in seen_ids:continue
            row.click(timeout=4000);page.wait_for_timeout(400)
            if not navegador._visible_sender_in_message(page,sender):continue
            received=navegador._received_timestamp(page)
            a=navegador.iso_dt(received)
            b=navegador.iso_dt(started)
            if not a or a < b - navegador.timedelta(minutes=1):continue
            candidate=[]
            for pane in navegador._read_panes(page):
                try:
                    links=pane.locator('a[href]')
                    for k in range(min(links.count(),65)):
                        el=links.nth(k)
                        if not el.is_visible():continue
                        href=el.get_attribute('href') or ''
                        allowed=unwrap_official_link(href)
                        if allowed:candidate.append(allowed)
                except Exception:continue
            seen_ids.add(identifier)
            candidate=list(dict.fromkeys(candidate))
            # No adivinar entre varios enlaces oficiales.
            if len(candidate)==1:return candidate[0]
        except Exception:continue
    return None


class _DocLinks(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag not in ('iframe','embed','object','a'):return
        attrs=dict(attrs)
        url=attrs.get('src') or attrs.get('data') or attrs.get('href') or ''
        if url:self.links.append((tag,url))


def fetch_pdf(context, url: str) -> bytes:
    """Obtiene PDF desde enlace oficial, opcionalmente desde visor HTML simple.

    Rechaza redirecciones a sitios ajenos, PDF falsos o HTML con enlaces ambiguos.
    No ejecuta JavaScript de la página del IMSS dentro del descargador.
    """
    if not official_imss(url):raise ValueError('Solo se admiten enlaces HTTPS oficiales de IMSS.')
    current=url
    for depth in range(3):
        response=context.request.get(current,timeout=30000,max_redirects=0)
        for _ in range(5):
            if 300 <= response.status < 400:
                redirect=response.headers.get('location') or ''
                dest=urljoin(response.url,redirect)
                if not official_imss(dest):raise PermissionError('Redirección fuera de IMSS bloqueada.')
                response=context.request.get(dest,timeout=30000,max_redirects=0)
            else:break
        if not official_imss(response.url):raise PermissionError('URL final no oficial.')
        if not response.ok:raise RuntimeError('IMSS respondió HTTP '+str(response.status))
        size=response.headers.get('content-length','')
        if size.isdigit() and int(size)>MAX_SIZE:raise ValueError('Documento demasiado grande.')
        data=response.body()
        if is_pdf(data):return data
        if depth>=2 or len(data)>2_000_000 or not data.lstrip()[:200].lower().startswith((b'<!doctype html',b'<html')):
            break
        html=data.decode('utf-8','replace')
        parser=_DocLinks();parser.feed(html)
        links=[]
        for tag,href in parser.links:
            target=urljoin(response.url,href)
            if official_imss(target) and (tag in ('embed','object','iframe') or '.pdf' in urlparse(target).path.lower()):
                links.append(target)
        links=list(dict.fromkeys(links))
        if len(links)!=1:break
        current=links[0]
    raise ValueError('El enlace abrió un visor o página, no un PDF directo. Se requiere revisar ese caso.')

def save_pdf(data:bytes, output_dir:Path, request_id:str):
    if not is_pdf(data):raise ValueError('No es un PDF válido.')
    if not re.fullmatch(r'[0-9a-f]{32}',request_id):raise ValueError('Identificador inválido.')
    output_dir.mkdir(mode=0o700,parents=True,exist_ok=True)
    path=output_dir/(request_id+'_'+secrets.token_hex(5)+'.pdf')
    with path.open('xb') as f:f.write(data)
    try:path.chmod(0o600)
    except OSError:pass
    return str(path), hashlib.sha256(data).hexdigest()
