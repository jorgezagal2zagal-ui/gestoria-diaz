@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
 py -3 -m pip install -r requirements.txt
 if errorlevel 1 goto error
 py -3 -m playwright install chromium
 if errorlevel 1 goto error
) else (
 python -m pip install -r requirements.txt
 if errorlevel 1 goto error
 python -m playwright install chromium
 if errorlevel 1 goto error
)
echo.
echo Navegador de Outlook preparado.
pause
exit /b 0
:error
echo Error al instalar dependencias. Revisa Internet y Python.
pause
exit /b 1
