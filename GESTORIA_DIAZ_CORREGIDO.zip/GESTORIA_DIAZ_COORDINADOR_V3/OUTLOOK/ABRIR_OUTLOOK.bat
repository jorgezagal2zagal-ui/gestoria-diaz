@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title Gestoria Diaz - Outlook Incognito
where py >nul 2>nul
if not errorlevel 1 (
 py -3 -c "import playwright" >nul 2>nul
 if errorlevel 1 call "%~dp0INSTALAR.bat"
 py -3 "%~dp0app.py"
) else (
 python -c "import playwright" >nul 2>nul
 if errorlevel 1 call "%~dp0INSTALAR.bat"
 python "%~dp0app.py"
)
if errorlevel 1 (
 echo La aplicacion no pudo iniciar. Revisa Python 3 y ejecuta INSTALAR.bat.
 pause
)
