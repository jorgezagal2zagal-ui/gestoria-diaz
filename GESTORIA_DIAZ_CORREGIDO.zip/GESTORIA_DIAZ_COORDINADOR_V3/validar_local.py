"""Run deterministic local checks with isolated synthetic data, no remote accounts."""
import os, subprocess, sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
commands=[(root,['-m','unittest','discover','-s','tests','-v']),
          (root/'IMSS',['PROBAR_IMSS_V8.py'])]
commands += [(root/'OUTLOOK',[name]) for name in
             ('PROBAR_V8.py','PROBAR_V9.py','PROBAR_V10.py','PROBAR_V11.py','PROBAR_V12.py','PROBAR_ENLACE.py')]
with tempfile.TemporaryDirectory() as d:
    environ=dict(os.environ,LOCALAPPDATA=d)
    for cwd,args in commands:
        result=subprocess.run([sys.executable,*args],cwd=cwd,env=environ)
        if result.returncode:sys.exit(result.returncode)
print('All local checks passed. Windows/HONOR/Microsoft integration is NOT validated.')
