@echo off
cd /d "%~dp0"
py -3 PROBAR_COMANDO_CISEC.py
pause
