"""Solo verifica que el puente localhost conteste. No inicia un trámite."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'IMSS'))
from enlace import Client
if __name__=='__main__':
 try:print('Enlace Outlook↔IMSS:',Client().ping())
 except Exception as exc:print('Todavía no responde:',str(exc))
