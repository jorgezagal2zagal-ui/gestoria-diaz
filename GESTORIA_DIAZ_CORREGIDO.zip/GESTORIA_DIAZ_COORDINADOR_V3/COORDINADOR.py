# -*- coding: utf-8 -*-
"""Gestoría Díaz: tercer bot supervisor, SIN modificar los motores originales.

Inicia los motores como módulos. Outlook abre su sesión privada y pasa el código
mediante State/Server en 127.0.0.1:8797; IMSS ejecuta el flujo original en HONOR.
No envía PDFs a terceros. Entrega pendiente de validación y portal autenticado.
"""
from __future__ import annotations
import os, queue, re, sys, threading, time
from diagnostico import record
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'IMSS'))
sys.path.append(str(ROOT/'OUTLOOK'))
from app import App as OriginalIMSSApp
from imss_core import nodes_from_xml, stage
from enlace import State, Server
from navegador import BrowserLogin
from queue_store import QueueStore
from credenciales import Vault, WindowsDPAPI, decode_file
from cooldown import Cooldown
from cola_privada import Requests
from pdf_enlaces import find_official_link, fetch_pdf, save_pdf

BG='#0E1218'; PANEL='#1B2530'; GOLD='#E7B75F'; WHITE='#EDF1F5'; MUTED='#AAB5C3'
BASE=Path(os.environ.get('LOCALAPPDATA') or str(Path.home()))/'GestoriaDiaz'/'CoordinadorV1'
BASE.mkdir(parents=True,exist_ok=True)

class OutlookConEnlaces(BrowserLogin):
    def __init__(self, callback, request_supplier, deliver_code, on_pdf):
        super().__init__(callback, request_supplier, deliver_code)
        self.on_pdf=on_pdf
        self.pdf_sender=''
        self.link_seen=set()
        self.last_pdf_check=0
    def start(self,email,password):
        self.link_seen=set();self.last_pdf_check=0
        return super().start(email,password)
    def _check_inbox(self,page,email):
        # Código: motor Outlook V13 original, sin cambios.
        super()._check_inbox(page,email)
        try:
            state=self.request_supplier() or {}
            if state.get('status')!='SOLICITUD_IMSS_ENVIADA':return
            if (state.get('email') or '').casefold()!=email.casefold():return
            now=time.monotonic()
            if now-self.last_pdf_check<12:return
            self.last_pdf_check=now
            sender=self.pdf_sender or self.sender
            if not sender:
                self._emit('Configura una vez el REMITENTE EXACTO del enlace IMSS para localizar el PDF.')
                return
            link=find_official_link(page,sender,state.get('started'),self.link_seen)
            if not link:return
            self._emit('Enlace oficial de IMSS encontrado. Comprobando que descargue un PDF verdadero…')
            try:
                pdf=fetch_pdf(page.context,link)
                self.on_pdf(state['request_id'],email,pdf)
            except Exception as exc:
                self._emit('Enlace encontrado, pero la descarga necesita revisión: '+str(exc)[:155])
                self.on_pdf(state['request_id'],email,None,error=str(exc))
        except Exception as exc:
            self._emit('Revisión de enlace pendiente: '+type(exc).__name__)

class Coordinator(OriginalIMSSApp):
    def __init__(self):
        self.messages=queue.Queue()
        self.accounts=QueueStore()
        self.vault=Vault()
        # Si no había cuentas seleccionadas, no exigir el botón «Seleccionar todas».
        if self.accounts.counts()['seleccionados']==0 and self.accounts.counts()['nuevos']:
            self.accounts.select_all()
        self.jobs=Requests(WindowsDPAPI())
        self.jobs.recover()
        self.mail_state=State()
        self.local_server=None
        self.active_id=None
        self.active_email=None
        self.last_start=0.0
        self.cooldown=Cooldown(seconds=60)
        self.last_browser_running=False
        self.sender_code=''
        self.sender_pdf=''
        self._last_external_status=''
        self.device_change_pending=False
        self.device_change_processing=False
        self.change_email_processing=False
        self.mail_login_issue=False
        self.mail_browser=OutlookConEnlaces(self._browser_event,self.mail_state.status,
                                             self._deliver_code,self._downloaded)
        super().__init__()
        self.title('Gestoría Díaz · Tercer bot coordinador · Versión de prueba')
        self.geometry('980x770');self.minsize(800,650)
        try:
            self.local_server=Server(self.mail_state);self.local_server.start()
            self.note('Comunicación local Outlook↔IMSS disponible, puerto 8797.')
        except Exception as exc:
            self.note('ERROR DE ENLACE: cierra cualquier Outlook V13 que esté abierto. '+str(exc)[:100])
        self._load_senders()
        self._update_device_banner()
        self.reserve_pending_emails()
        self._update_txt_status()
        self.protocol('WM_DELETE_WINDOW',self.close_all)
        self.after(800,self._pulse)

    def make_layout(self):
        # Todos los nombres necesarios para el motor IMSS original están presentes.
        self.auto_email_var=tk.BooleanVar(master=self,value=False)
        self.auto_verify_var=tk.BooleanVar(master=self,value=True)
        self.queue_status=tk.StringVar(master=self,value='')
        self.link_status=tk.StringVar(master=self,value='Enlace Outlook: iniciando…')
        self.adv_visible=False
        self.configure(bg=BG)
        top=tk.Frame(self,bg=BG);top.pack(fill='x',padx=22,pady=(18,8))
        tk.Label(top,text='GESTORÍA DÍAZ',fg=GOLD,bg=BG,font=('Segoe UI',24,'bold')).pack(anchor='w')
        tk.Label(top,text='TERCER BOT · OUTLOOK V13 + IMSS V8 · DOS MOTORES ORIGINALES',fg=MUTED,bg=BG,
                 font=('Segoe UI',9,'bold')).pack(anchor='w',pady=(0,5))
        self.notice=tk.StringVar(master=self,value='Listo para recibir solicitudes autorizadas.')
        tk.Label(top,textvariable=self.notice,fg=WHITE,bg=BG,font=('Segoe UI',11),wraplength=900,justify='left').pack(anchor='w',pady=(6,2))
        actions=tk.Frame(self,bg=PANEL,padx=20,pady=18);actions.pack(fill='x',padx=20,pady=9)
        self._title(actions,'1  CONECTAR HONOR')
        cr=tk.Frame(actions,bg=PANEL);cr.pack(fill='x',pady=(5,13))
        tk.Label(cr,text='IP',bg=PANEL,fg=MUTED).pack(side='left')
        ttk.Entry(cr,textvariable=self.ip,width=20).pack(side='left',padx=(8,18))
        tk.Label(cr,text='Puerto',bg=PANEL,fg=MUTED).pack(side='left')
        ttk.Entry(cr,textvariable=self.port,width=10).pack(side='left',padx=(8,14))
        self.btn(cr,'CONECTAR HONOR',self.connect,True).pack(side='left',padx=(0,7))
        self.btn(cr,'DETECTAR',self.detect).pack(side='left')
        # Único paso inicial de correos: importar TXT una vez.
        ir=tk.Frame(actions,bg=PANEL);ir.pack(fill='x',pady=(0,10))
        self.btn(ir,'IMPORTAR TXT DE CORREOS',self.import_accounts,True).pack(side='left',padx=(0,12))
        self.txt_status=tk.StringVar(master=self,value='Sin cuentas importadas')
        tk.Label(ir,textvariable=self.txt_status,bg=PANEL,fg=MUTED,
                 font=('Segoe UI',9),anchor='w',wraplength=570,justify='left').pack(side='left',fill='x',expand=True)
        self._title(actions,'2  SOLICITAR SEMANAS COTIZADAS')
        sr=tk.Frame(actions,bg=PANEL);sr.pack(fill='x',pady=8)
        tk.Label(sr,text='CURP',bg=PANEL,fg=MUTED).pack(side='left')
        ttk.Entry(sr,textvariable=self.curp,width=26).pack(side='left',padx=(9,15),ipady=6)
        self.btn(sr,'INICIAR TRÁMITE',self.enqueue_and_start,True).pack(side='left',padx=(0,8))
        self.btn(sr,'DETENER',self.abort).pack(side='left')
        self.counter=tk.StringVar(master=self,value='Cola: 0 pendientes')
        tk.Label(actions,textvariable=self.counter,bg=PANEL,fg=GOLD,font=('Segoe UI',10,'bold')).pack(anchor='w',pady=(7,0))
        tk.Label(actions,text='Un HONOR procesa una solicitud a la vez. Las demás esperan en cola.',bg=PANEL,
                 fg=MUTED,font=('Segoe UI',9)).pack(anchor='w')
        center=tk.Frame(self,bg=BG);center.pack(fill='both',expand=True,padx=20,pady=6)
        left=tk.Frame(center,bg=PANEL,padx=14,pady=12);left.pack(side='left',fill='both',expand=True,padx=(0,10))
        right=tk.Frame(center,bg=PANEL,padx=12,pady=12,width=282);right.pack(side='right',fill='both');right.pack_propagate(False)
        self._title(left,'SOLICITUDES Y DIAGNÓSTICO')
        self.table=ttk.Treeview(left,columns=('cuenta','estado'),show='headings',height=6)
        self.table.heading('cuenta',text='Correo');self.table.heading('estado',text='Estado')
        self.table.column('cuenta',width=190);self.table.column('estado',width=175)
        self.table.pack(fill='x',pady=(8,7))
        self.logbox=tk.Text(left,height=10,wrap='word',bg='#0A1017',fg=WHITE,
                            insertbackground=GOLD,font=('Consolas',9),relief='flat')
        self.logbox.pack(fill='both',expand=True,pady=5);self.logbox.configure(state='disabled')
        footer=tk.Frame(left,bg=PANEL);footer.pack(fill='x',pady=4)
        self.btn(footer,'OPCIONES AVANZADAS',self.toggle_advanced).pack(side='left',padx=(0,6))
        self.btn(footer,'CAMBIAR SOLO CORREO',self.change_only_email).pack(side='left',padx=(0,6))
        self.btn(footer,'REANUDAR IMSS',self.resume_flow).pack(side='left',padx=(0,6))
        self.btn(footer,'ACTUALIZAR',self.refresh).pack(side='left')
        self.advanced=tk.Frame(left,bg=PANEL,pady=9)
        row=tk.Frame(self.advanced,bg=PANEL);row.pack(fill='x')
        tk.Label(row,text='Remitente exacto CÓDIGO:',bg=PANEL,fg=MUTED).pack(side='left')
        self.s_code=tk.StringVar(master=self)
        ttk.Entry(row,textvariable=self.s_code,width=32).pack(side='left',padx=8)
        row=tk.Frame(self.advanced,bg=PANEL);row.pack(fill='x',pady=(7,0))
        tk.Label(row,text='Remitente exacto ENLACE:',bg=PANEL,fg=MUTED).pack(side='left')
        self.s_pdf=tk.StringVar(master=self)
        ttk.Entry(row,textvariable=self.s_pdf,width=32).pack(side='left',padx=8)
        ar=tk.Frame(self.advanced,bg=PANEL);ar.pack(fill='x',pady=8)
        self.btn(ar,'GUARDAR REMITENTES',self.save_senders).pack(side='left',padx=3)
        # Importar TXT ahora es visible en el panel principal.
        self.btn(ar,'SELECCIONAR TODAS',self.select_accounts).pack(side='left',padx=3)
        ar2=tk.Frame(self.advanced,bg=PANEL);ar2.pack(fill='x')
        self.btn(ar2,'AUTORIZAR CAMBIO DISPOSITIVO',self.confirm_change).pack(side='left',padx=3)
        self.btn(ar2,'CALIBRAR SÍ',self.calibrate_change).pack(side='left',padx=3)
        self.btn(ar2,'CALIBRAR CÓDIGO',self.calibrate).pack(side='left',padx=3)
        self.change_button=self.btn(left,'AUTORIZAR CAMBIO DE CELULAR (CURP ACTUAL)',self.confirm_change,True)
        # Aparece solo si IMSS ha detectado el aviso concreto para esta solicitud.
        self._title(right,'VISTA DEL HONOR')
        self.canvas=tk.Canvas(right,width=255,height=520,bg='#080D13',highlightthickness=1,
                              highlightbackground='#5B4D31')
        self.canvas.pack(fill='both',expand=True,pady=8)
        self.canvas.bind('<Button-1>',self.preview_click)
        tk.Label(right,textvariable=self.link_status,bg=PANEL,fg=MUTED,wraplength=240,justify='left').pack(anchor='w')
        tk.Label(self,textvariable=self.status,bg=BG,fg=GOLD).pack(anchor='w',padx=20,pady=(0,7))
        self.after(500,self.refresh_queue_info)

    def btn(self,parent,label,fn,gold=False):
        return tk.Button(parent,text=label,command=fn,bg=GOLD if gold else '#33414F',
                         fg=BG if gold else WHITE,activebackground='#F4CE84',
                         relief='flat',bd=0,font=('Segoe UI',9,'bold'),padx=13,pady=8)
    def _title(self,parent,text):
        tk.Label(parent,text=text,fg=GOLD,bg=parent.cget('bg'),
                 font=('Segoe UI',11,'bold')).pack(anchor='w')
    def toggle_advanced(self):
        self.adv_visible=not self.adv_visible
        if self.adv_visible:self.advanced.pack(fill='x',pady=7)
        else:self.advanced.pack_forget()
    def note(self,msg):
        self.messages.put(('log',str(msg)))
    def _browser_event(self,msg):
        if 'error de outlook' in msg.casefold():record('outlook_engine_error')
        if msg=='Navegador cerrado.':record('outlook_closed')
        self.note('OUTLOOK: '+msg)
        low=msg.casefold()
        # Señales de diagnóstico, no pruebas de contraseña incorrecta. Nunca
        # rotar cuentas por un desafío MFA ni por un error 429 de Microsoft.
        if ('error de outlook' in low or 'no se pudo completar la contraseña' in low):
            self.messages.put(('mail_issue',None))

    def _load_senders(self):
        import json
        saved={}
        try:saved=json.loads((BASE/'config.json').read_text('utf-8'))
        except (ValueError,OSError):pass
        # Migración solo de remitente público; no lee contraseñas en texto.
        if not saved.get('code'):
            try:
                from core import data_dir
                cfg=json.loads((data_dir()/'panel_simple.json').read_text('utf-8'))
                saved['code']=cfg.get('sender','')
            except Exception:pass
        self.s_code.set(saved.get('code',''))
        self.s_pdf.set(saved.get('pdf',''))
        self.save_senders(quiet=True)
    def save_senders(self,quiet=False):
        import json
        a=self.s_code.get().strip().lower();b=self.s_pdf.get().strip().lower()
        if (a and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',a)) or (b and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',b)):
            if not quiet:messagebox.showwarning('Remitente','Escribe el correo completo del remitente.')
            return
        self.mail_browser.set_sender(a)
        self.mail_browser.pdf_sender=b
        (BASE/'config.json').write_text(json.dumps({'code':a,'pdf':b},ensure_ascii=False),encoding='utf-8')
        if not quiet:self.note('Remitentes autorizados guardados. No se guardaron contraseñas.')
    def import_accounts(self):
        file=filedialog.askopenfilename(parent=self,title='Importar cuentas Outlook TXT',
                 filetypes=[('Archivo TXT','*.txt'),('Todos los archivos','*.*')])
        if not file:return
        try:
            pairs=[(str(address).strip().lower(),password) for address,password in decode_file(file) if password]
            if not pairs:raise ValueError('No encontré cuentas con contraseña. Usa: correo@hotmail.com | CONTRA: tu_clave')
            self.vault.save(pairs)
            self.accounts.add([address for address,_ in pairs])
            self.accounts.select_all()
            self.note(f'TXT importado: {len(pairs)} cuenta(s). Contraseñas guardadas mediante Windows DPAPI.')
            self.reserve_pending_emails()
            self._update_txt_status()
            self.start_next()  # comienza ya si HONOR está libre y conectado
        except Exception as exc:messagebox.showerror('Importar TXT',str(exc)[:220],parent=self)

    def _update_txt_status(self):
        counts=self.accounts.counts()
        self.txt_status.set(f"{counts['nuevos']} Nuevo · {counts['usados']} Usado · "
                            f"{counts['seleccionados']} seleccionados automáticamente")

    def select_accounts(self):
        self.accounts.select_all()
        self._update_txt_status()
        self.reserve_pending_emails()
        self.note('Todas las cuentas seleccionadas. No cambian a Usado hasta iniciar el acceso.')
        self.start_next()

    def reserve_pending_emails(self):
        """Asigna cuenta sin consumirla, incluso si HONOR aún está desconectado.

        Reservas existentes se mantienen para impedir cruzar cuentas entre CURP.
        No hace falta seleccionar manualmente el correo, ni reimportarlo por solicitud.
        """
        rows=self.jobs.list()
        reserved={item['email'].lower() for item in rows
                  if item['email'] and item['status'] in ('PENDIENTE','ACTIVA','ESPERANDO_CODIGO','ESPERANDO_PDF','REQUIERE_ATENCION','ERROR')}
        candidates=[entry['email'] for entry in self.accounts.entries()
                    if entry['estado']=='NUEVO' and entry['seleccionado']]
        for job in rows:
            if job['status']!='PENDIENTE' or job['email']:continue
            exclusions=self.jobs.skipped_emails(job['id'])
            chosen=next((email for email in candidates
                         if email not in reserved and email not in exclusions and self.vault.has_password(email)),None)
            if chosen is None:continue
            self.jobs.set(job['id'],'PENDIENTE',email=chosen)
            reserved.add(chosen)
            self.note('Correo asignado a solicitud '+job['id'][:8]+': '+chosen)
        return reserved
    def _resolve_email_for_new_request(self):
        # El tercer bot elige una sola vez ANTES de iniciar Outlook;
        # no se cambia la cuenta cuando pasa a USADO.
        if not self.active_email:raise ValueError('No hay cuenta asignada a esta solicitud.')
        self.correo.set(self.active_email)
        return self.active_email
    def enqueue_and_start(self):
        raw=self.curp.get().strip()
        if raw:
            try:
                jid=self.jobs.enqueue(raw)
            except Exception as exc:messagebox.showerror('CURP',str(exc));return
            self.curp.set('')
            self.note('Solicitud recibida: folio '+jid[:8]+'. Asignando correo automáticamente…')
            self.reserve_pending_emails()
        self.start_next()
    def start_next(self):
        if self.active_id or self._busy or self._login_busy:return
        self.reserve_pending_emails()
        jid,curp=self.jobs.oldest_pending()
        if not jid:
            self.notice.set('Sin solicitudes. La siguiente CURP se iniciará de inmediato.');return
        job=self.jobs.get(jid)
        email=(job or {}).get('email')
        if not email:
            self.notice.set('Falta un correo Nuevo con contraseña. Pulsa IMPORTAR TXT DE CORREOS.');return
        # En vez de dejar la fila eternamente PENDIENTE, exponer la causa exacta.
        if not self.local_server:
            self.notice.set('PENDIENTE: el enlace local 8797 está ocupado. Cierra la otra ventana Outlook.');return
        if not self.bridge.serial:
            self.notice.set('PENDIENTE: correo '+email+' reservado; conecta el HONOR para iniciar.');return
        if self.mail_browser.rate_limited:
            self.notice.set('DETENIDO: Microsoft limitó accesos (429). No se intentará otro inicio.');return
        if self.mail_browser.running:
            self.notice.set('PENDIENTE: termina primero la sesión de Outlook activa.');return
        if self.cooldown.remaining():
            self.notice.set('Siguiente solicitud: '+email+' · espera de seguridad: '+str(self.cooldown.remaining())+' s')
            return
        try:passwd=self.vault.password(email)
        except Exception as exc:
            self.notice.set('No se pudo abrir la contraseña cifrada de Windows: '+str(exc)[:90]);return
        if not passwd:
            self.notice.set('No hay contraseña para '+email+'. Reimporta el TXT con claves.');return
        # La falta de remitente NO impide iniciar. Afectará solo lectura automática
        # de códigos hasta confirmar el remitente real; no se envían OTP inciertos.
        self.active_id=jid;self.active_email=email
        self.device_change_pending=False;self.mail_login_issue=False
        self._update_device_banner()
        self.correo.set(email);self.curp.set(curp)
        self.jobs.set(jid,'ACTIVA',email=email)
        self.notice.set('Trabajando con '+email+' · Folio '+jid[:8])
        self.note('Iniciando ahora: correo '+email+' y el mismo correo en IMSS.')
        if not self.mail_browser.sender:
            self.note('AVISO: la sesión y el trámite iniciarán; para enviar códigos automáticamente falta validar una vez el remitente real de IMSS.')
        try:
            self.mail_browser.start(email,passwd)
            self.accounts.mark_started(email)
            self.last_browser_running=True
        except Exception as exc:
            self.jobs.set(jid,'REQUIERE_ATENCION',error='Error al iniciar Outlook: '+type(exc).__name__)
            record('outlook_start_failed',exc)
            self.active_id=None;self.active_email=None
            self.notice.set('No se pudo iniciar Outlook. Revisa el diagnóstico.')
            self.note('Error: '+str(exc)[:160]);return
        # Ejecutar ABRIR IMSS antes de INICIAR PASOS, sin tocar el motor.
        def launch():
            try:
                pkg=self.bridge.launch_imss()
                self.messages.put(('opened',(jid,pkg)))
            except Exception as exc:self.messages.put(('error',(jid,'No se abrió IMSS: '+str(exc)[:160])))
        threading.Thread(target=launch,daemon=True).start()
    def _on_opened(self,jid,pkg):
        if self.active_id!=jid:return
        self.note('IMSS Digital abierto: '+str(pkg)+'. Iniciando pasos originales.')
        self.jobs.set(jid,'ESPERANDO_CODIGO')
        self.start_flow()
    def _deliver_code(self,request_id,code,email):
        # V13 validó remitente, fecha e identidad de la cuenta; nunca persiste OTP.
        self.mail_state.put_code(request_id,code,email=email)
        self.note('Código verificado recibido desde Outlook; enviado al motor IMSS.')
    def _downloaded(self,request_id,email,pdf,error=None):
        # Callback corre en hilo del navegador. Nunca actualiza Tk directamente.
        self.messages.put(('pdf',(request_id,email,pdf,error)))
    def _on_pdf(self,req_id,email,pdf,error):
        if req_id!=self.link_id or email!=self.active_email or not self.active_id:return
        if error:
            self.jobs.set(self.active_id,'REQUIERE_ATENCION',error='Enlace oficial: '+error[:180])
            self.notice.set('El correo trae enlace, pero no entregó PDF directamente; revisar visor IMSS.')
            self.note('Descarga pendiente: '+error[:165]);return
        try:
            path,digest=save_pdf(pdf,BASE/'PDF_PARA_REVISAR',self.active_id)
            self.jobs.set(self.active_id,'PDF_REVISAR',pdf_path=path,digest=digest)
            self.note('PDF recibido y validado como archivo, pendiente confirmar identidad del titular: '+Path(path).name)
            self.notice.set('PDF descargado. Pendiente revisión de CURP y entrega segura.')
            self._finish_session()
        except Exception as exc:self.note('Error al guardar PDF: '+str(exc)[:150])
    def _finish_session(self):
        self.mail_browser.stop()
        self.cooldown.begin()
        self.last_browser_running=True
        self.active_id=None;self.active_email=None
        self.device_change_pending=False;self._update_device_banner()
        self.link_id=None;self.link_registered=False
        self.curp.set('');self.correo.set('')
    def _update_device_banner(self):
        if not hasattr(self,'change_button'):return
        if self.device_change_pending and self.active_id:
            self.change_button.pack(fill='x',pady=(8,4))
        else:
            self.change_button.pack_forget()

    def do_device_change(self,nodes,manual=False):
        # Solo añadimos la notificación al coordinador; el motor original de
        # IMSS no cambia. No ejecutar cambio sin consentimiento.
        if not manual and stage(nodes)=='CAMBIO_DISPOSITIVO':
            self.messages.put(('device_prompt',self.active_id))
        return super().do_device_change(nodes,manual=manual)

    def confirm_change(self):
        """Autorizar el aviso exacto IMSS con una sola pulsación.

        No cambia la vinculación sin consentimiento del titular. Si ADB no
        expone el texto del diálogo, nunca pulsar coordenadas a ciegas.
        """
        if not self.active_id:
            return messagebox.showinfo('Cambio de celular','No hay trámite activo.',parent=self)
        if self.device_change_processing or self._busy or self._login_busy:
            self.notice.set('Espera a que IMSS termine de leer la pantalla antes de autorizar.');return
        jid=self.active_id
        if not messagebox.askyesno('Autorizar cambio de dispositivo',
            '¿Confirmas que el titular de ESTA solicitud autorizó vincular su CURP al HONOR?\n\n'
            'Esto podría desvincular su dispositivo anterior.\n'
            'Solo se pulsará «SÍ, QUIERO HACER EL CAMBIO» una vez, si se detecta el aviso exacto.',parent=self):
            self.note('Cambio de dispositivo NO autorizado. IMSS permanece en espera.')
            return
        self.device_change_processing=True
        self.notice.set('Confirmando el aviso específico de vinculación en el HONOR…')
        def worker():
            try:
                nodes=nodes_from_xml(self.bridge.dump())
                if stage(nodes)!='CAMBIO_DISPOSITIVO':
                    result=('NO_TOCO', 'El aviso exacto ya no está visible para ADB. '
                            'Revisa la pantalla; si lo ves, toca SÍ manualmente en el HONOR.')
                else:
                    # Una autorización permite un solo toque. Nunca volver a
                    # intentar automáticamente mientras persista el mismo aviso.
                    self._change_attempted=False
                    text=super(Coordinator,self).do_device_change(nodes,manual=True)
                    if self._change_attempted:
                        time.sleep(.9)
                        new_stage=stage(nodes_from_xml(self.bridge.dump()))
                        if new_stage not in ('CAMBIO_DISPOSITIVO','DESCONOCIDA'):
                            result=('AVANZO',text+' IMSS avanzó a '+new_stage+'.')
                        else:
                            result=('REVISAR',text+' IMSS no confirmó el avance. '
                                    'No volveré a pulsar sin revisión.')
                    else:
                        result=('NO_TOCO',text)
                self.messages.put(('device_done',(jid,*result)))
            except Exception as exc:
                self.messages.put(('device_done',(jid,'ERROR','No se tocó el botón: '+str(exc)[:175])))
        threading.Thread(target=worker,daemon=True).start()

    def _device_result(self,jid,kind,detail):
        self.device_change_processing=False
        self.note('Cambio de dispositivo: '+detail)
        if jid!=self.active_id:return
        if kind=='AVANZO':
            self.device_change_pending=False
            self._update_device_banner()
            self.notice.set('Vinculación autorizada y confirmada. Reanudando trámite actual…')
            self.after(500,lambda:self.resume_flow() if self.active_id==jid and not self._busy and not self._login_busy else None)
        else:
            self.device_change_pending=True
            self._update_device_banner()
            self.notice.set(detail[:200])

    def _selected_job_for_mail_change(self):
        if self.active_id:return self.active_id
        selection=self.table.selection()
        if selection:return selection[0]
        jid,_=self.jobs.oldest_pending()
        return jid

    def change_only_email(self):
        """Mismo folio y misma CURP; libera únicamente la reserva del correo.

        Si hay IMSS en curso, hay que comprobar que aún está en ACCESO. Un
        código ya solicitado no debe asignarse a otra cuenta a mitad del flujo.
        """
        if self.change_email_processing or self.device_change_processing:return
        jid=self._selected_job_for_mail_change()
        if not jid:
            return messagebox.showinfo('Cambiar correo','No hay solicitud pendiente o activa.',parent=self)
        job=self.jobs.get(jid)
        if not job or job['status'] not in ('PENDIENTE','ACTIVA','ESPERANDO_CODIGO','REQUIERE_ATENCION'):
            return messagebox.showwarning('Cambiar correo','Esta solicitud ya avanzó; no cambies el correo después de solicitar el código o el PDF.',parent=self)
        old_email=job.get('email') or ''
        if not old_email:
            self.reserve_pending_emails();self.start_next();return
        # Primeras consultas: no alterar un trámite IMSS que ya pidió un código.
        needs_stage_check=(jid==self.active_id or job['status']=='REQUIERE_ATENCION')
        if needs_stage_check:
            if self._busy or self._login_busy:
                self.notice.set('Espera a que IMSS termine el paso actual antes de cambiar el correo.')
                return
            self.change_email_processing=True
            self.notice.set('Comprobando que IMSS todavía permite sustituir el correo…')
            def check():
                try:
                    current=stage(nodes_from_xml(self.bridge.dump()))
                    self.messages.put(('email_stage',(jid,old_email,current)))
                except Exception as exc:
                    self.messages.put(('email_stage',(jid,old_email,'ERROR: '+str(exc)[:130])))
            threading.Thread(target=check,daemon=True).start()
            return
        self._apply_email_change(jid,old_email)

    def _email_stage_result(self,jid,old_email,current):
        self.change_email_processing=False
        job=self.jobs.get(jid)
        if jid!=self.active_id and (not job or job['status']!='REQUIERE_ATENCION'):return
        if current!='ACCESO':
            self.notice.set('No cambié nada: IMSS está en '+current+'. Regresa al formulario de acceso y revisa el trámite.')
            self.note('Cambio de correo no permitido durante etapa '+current+'.')
            return
        self._apply_email_change(jid,old_email)

    def _apply_email_change(self,jid,old_email):
        job=self.jobs.get(jid)
        if not job or job.get('email')!=old_email:return
        # Reservas y exclusiones se mantienen aunque se cierre el programa.
        other_reserved={item['email'].lower() for item in self.jobs.list()
                        if item['id']!=jid and item['email'] and item['status'] in
                        ('PENDIENTE','ACTIVA','ESPERANDO_CODIGO','ESPERANDO_PDF','REQUIERE_ATENCION','ERROR')}
        blocked=self.jobs.skipped_emails(jid)|other_reserved|{old_email.lower()}
        next_email=next((x['email'] for x in self.accounts.entries()
                    if x['estado']=='NUEVO' and x['seleccionado']
                    and x['email'] not in blocked and self.vault.has_password(x['email'])),None)
        if not next_email:
            self.notice.set('No hay otro correo NUEVO disponible. Importa más cuentas TXT; se conserva la CURP y el correo anterior.')
            return
        if not messagebox.askyesno('Cambiar solo correo',
            'Se conservarán el folio y la CURP.\n\nCorreo anterior: '+old_email+
            '\nSiguiente: '+next_email+'\n\n¿Confirmas el cambio?',parent=self):return
        self.jobs.skip_email(jid,old_email)
        self.jobs.set(jid,'PENDIENTE',email=next_email,error='')
        if jid==self.active_id:
            self._flow_stop.set()  # Ningún paso ADB adicional de la petición anterior.
            self.mail_browser.stop()
            self.cooldown.begin()
            self.active_id=None;self.active_email=None
            self.link_registered=False;self.link_id=None
            self._change_attempted=False;self.device_change_pending=False
            self._update_device_banner()
            self.mail_login_issue=False
        self.notice.set('Se conservó la misma CURP. Correo nuevo: '+next_email+'. Esperando cierre de sesión anterior y pausa de seguridad.')
        self.note('Mismo folio '+jid[:8]+': se cambió solo '+old_email+' → '+next_email)
        self._update_txt_status()
        # El pulso normal reinicia únicamente cuando el navegador privado cerró.

    def abort(self):
        self.stop_flow()
        if self.active_id:
            self.jobs.set(self.active_id,'REQUIERE_ATENCION',error='Detenido por el operador. Verificar antes de reintentar.')
            self._finish_session()
        self.notice.set('Detenido. Revisa el HONOR antes de otra solicitud.')
    def _pulse(self):
        # Tk does not reschedule a callback that raised. Always keep the queue alive.
        try:
            self._pulse_once()
        except Exception as exc:
            record('coordinator_pulse_failed',exc)
            if self.active_id:
                self._flow_stop.set()
                try:
                    self.jobs.set(self.active_id,'REQUIERE_ATENCION',
                                  error='Error del coordinador; revisar antes de continuar')
                except Exception as storage_error:
                    record('queue_write_failed',storage_error)
            self.note('Error del coordinador: '+type(exc).__name__+'. Se conserva el trámite para revisión.')
        finally:
            self.after(1100,self._pulse)

    def _pulse_once(self):
        try:
            while True:
                kind,payload=self.messages.get_nowait()
                if kind=='log':
                    self.logbox.configure(state='normal')
                    self.logbox.insert('end',time.strftime('%H:%M:%S')+' '+payload+'\n')
                    self.logbox.see('end');self.logbox.configure(state='disabled')
                elif kind=='opened':self._on_opened(*payload)
                elif kind=='error':
                    jid,msg=payload;self.note('ERROR: '+msg)
                    if jid==self.active_id:
                        self.jobs.set(jid,'ERROR',error=msg);self._finish_session()
                elif kind=='pdf':self._on_pdf(*payload)
                elif kind=='phone_stage':
                    request_id,phone_state=payload
                    if request_id==self.active_id and phone_state=='CAMBIO_DISPOSITIVO':
                        self.device_change_pending=True
                        self._update_device_banner()
                        self.notice.set('IMSS está esperando autorización para cambiar de dispositivo. Usa el botón amarillo; el correo y la CURP siguen reservados.')
                elif kind=='device_prompt' and payload==self.active_id:
                    self.device_change_pending=True
                    self._update_device_banner()
                    self.notice.set('IMSS pide vincular la CURP al HONOR. Solicita autorización del titular y usa AUTORIZAR CAMBIO DE CELULAR.')
                    self.note('AVISO: cambio de dispositivo pendiente de autorización para el folio '+payload[:8])
                elif kind=='device_done':self._device_result(*payload)
                elif kind=='email_stage':self._email_stage_result(*payload)
                elif kind=='mail_issue' and self.active_id:
                    self.mail_login_issue=True
                    self.notice.set('Outlook reportó un fallo. Revisa la cuenta. Si sigue en ACCESO IMSS, pulsa CAMBIAR SOLO CORREO. No se cambia ante 429/MFA.')

        except queue.Empty:pass
        if self.last_browser_running and not self.mail_browser.running:
            self.last_browser_running=False
            if self.active_id:
                self.note('Outlook se cerró antes de completar el trámite. Mantengo folio, CURP y correo para evitar mezclas.')
                self.jobs.set(self.active_id,'REQUIERE_ATENCION',error='Outlook se cerró: revisar etapa IMSS y sesión')
                self.notice.set('Outlook cerrado. Conservé la solicitud activa. Si IMSS pide CAMBIAR DISPOSITIVO puedes autorizarlo aquí; si aún está en ACCESO, CAMBIAR SOLO CORREO.')
                # No liberar esta CURP ni arrancar otra; primero resolver la
                # ventana IMSS que puede seguir abierta en el teléfono.
                current_id=self.active_id
                def detect_after_close():
                    try:
                        state=stage(nodes_from_xml(self.bridge.dump()))
                        self.messages.put(('phone_stage',(current_id,state)))
                    except Exception:pass
                threading.Thread(target=detect_after_close,daemon=True).start()
            self.cooldown.begin()
        try:
            state=self.mail_state.status()
            ext=state.get('status')
            if ext!=self._last_external_status and self.active_id:
                self._last_external_status=ext
                if ext=='SOLICITUD_IMSS_ENVIADA':
                    self.jobs.set(self.active_id,'ESPERANDO_PDF')
                    self.note('IMSS confirmó solicitud. Outlook ahora buscará el enlace de Historia Laboral.')
                elif ext=='CADUCADA':
                    self.jobs.set(self.active_id,'REQUIERE_ATENCION',error='Código caducado; no se reintenta automáticamente')
                    self.note('Código caducado. Revisa el HONOR antes de continuar.')
        except Exception:pass
        rows=self.jobs.list()
        selected_jobs=set(self.table.selection())
        for i in self.table.get_children():self.table.delete(i)
        for item in rows[-15:]:
            self.table.insert('', 'end',iid=item['id'],values=(item.get('email') or 'Sin asignar',item['status']))
        if selected_jobs:self.table.selection_set([jid for jid in selected_jobs if self.table.exists(jid)])
        pending=sum(j['status']=='PENDIENTE' for j in rows)
        self.counter.set(f'Cola: {pending} pendiente(s) · {len(rows)} en historial · Outlook: '+
                         ('activo' if self.mail_browser.running else 'cerrado'))
        if not self.active_id and pending and not self.mail_browser.running and not self.mail_browser.rate_limited:
            self.start_next()
        self._update_txt_status()
    def close_all(self):
        self._flow_stop.set();self.mail_browser.stop()
        try:
            if self.local_server:self.local_server.close()
        except Exception:pass
        self.destroy()

if __name__=='__main__':
    if os.name!='nt':raise SystemExit('Este panel requiere Windows para proteger los datos con DPAPI y controlar HONOR por ADB.')
    Coordinator().mainloop()
