@echo off
setlocal
cd /d "%~dp0"
py -3 -m pip install playwright msal requests pillow
py -3 -m playwright install chromium
pause
