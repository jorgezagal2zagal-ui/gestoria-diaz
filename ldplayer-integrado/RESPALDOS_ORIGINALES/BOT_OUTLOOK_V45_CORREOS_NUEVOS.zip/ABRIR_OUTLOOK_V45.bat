@echo off
cd /d "%~dp0"
py -3 "%~dp0GESTORIA_DIAZ_OUTLOOK_V45.pyw"
if errorlevel 1 pause
