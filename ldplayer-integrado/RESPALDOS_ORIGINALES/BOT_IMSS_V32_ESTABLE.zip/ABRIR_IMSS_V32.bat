@echo off
cd /d "%~dp0"
pyw -3 "%~dp0GESTORIA_DIAZ_IMSS_V32_SIN_CAMBIOS.pyw"
