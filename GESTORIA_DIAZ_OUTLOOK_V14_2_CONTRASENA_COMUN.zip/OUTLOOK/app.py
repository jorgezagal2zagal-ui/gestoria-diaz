# -*- coding: utf-8 -*-
"""Gestoría Díaz - Outlook Incógnito: panel reducido y enlace IMSS local.

- Inicio en Microsoft mediante Chromium temporal (sin cookies persistentes).
- Lectura automática OPCIONAL mediante OAuth delegado de Microsoft Graph.
- Envío manual de código al bot IMSS como respaldo.
- No omite MFA ni CAPTCHA de Microsoft.
"""
from __future__ import annotations
import json, re, threading, time, tkinter as tk
import queue as ui_queue
from diagnostico import record
from pathlib import Path
from tkinter import messagebox,ttk,scrolledtext,filedialog
from core import EMAIL_RE, data_dir
from credenciales import Vault, decode_file
from navegador import BrowserLogin
from mail_service import MailService
from enlace import State,Server
from queue_store import QueueStore
from cooldown import Cooldown
BG='#101419';BOX='#1B232C';GOLD='#E8BB62';WHITE='#F0F1F4';GRAY='#ACB6C1';GREEN='#93E4C1'
SETTINGS=data_dir()/'panel_simple.json'

def get_settings():
    try:
        value=json.loads(SETTINGS.read_text(encoding='utf-8'))
        return value if isinstance(value,dict) else {}
    except (ValueError,OSError):return {}

def save_settings(info):
    SETTINGS.parent.mkdir(parents=True,exist_ok=True)
    temp=SETTINGS.with_suffix('.tmp')
    temp.write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
    temp.replace(SETTINGS)

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('GESTORÍA DÍAZ · Outlook V14.2 independiente · Enlace IMSS')
        self._closed=False
        self._ui_events=ui_queue.Queue()
        self._auto_queue_enabled=threading.Event()
        self.geometry('920x800');self.minsize(810,650);self.configure(bg=BG)
        cfg=get_settings()
        self.email=tk.StringVar(value=cfg.get('email',''))
        self.password=tk.StringVar()
        self.save_pw=tk.BooleanVar(value=False)
        self.common_password_status=tk.StringVar(value='Contraseña común: sin configurar.')
        self.sender=tk.StringVar(value=cfg.get('sender',''))
        self.client_id=tk.StringVar(value=cfg.get('client_id',''))
        self.last_auto_check=0.0
        self.code=tk.StringVar()
        self.link_status=tk.StringVar(value='Iniciando enlace con IMSS…')
        self.browser_status=tk.StringVar(value='Outlook aún no se ha abierto.')
        self.info=tk.StringVar(value='Las contraseñas se utilizan solo en el inicio de sesión oficial de Microsoft.')
        self.browser_events=[]
        self.queue = QueueStore()
        self.cooldown = Cooldown(seconds=60)
        self.cooldown_label=tk.StringVar(value='ENFRIAMIENTO · Listo para iniciar')
        self.accounts_label=tk.StringVar(value='Cuentas importadas: 0')
        self.auto_queue=tk.BooleanVar(value=bool(cfg.get('auto_queue',False)))
        if self.auto_queue.get():self._auto_queue_enabled.set()
        self._auto_started_request=None
        self._last_auto_status=None
        self.active_email=None
        self.active_email_label=tk.StringVar(value="Ninguna cuenta en uso")
        self._previous_browser_running=False
        self.state=State();self.server=None
        self.browser=BrowserLogin(self._receive_browser_event,
                                  request_supplier=self.state.status,
                                  deliver_code=self._deliver_browser_code)
        self.browser.set_sender(self.sender.get())
        self.vault=None;self.service=None;self.auto_busy=False
        try:
            self.server=Server(self.state,resolver=self._reserve_email,available=self._reservation_available,can_begin=self._can_begin);self.server.start()
            self.link_status.set('Enlace activo en esta computadora (127.0.0.1:8797)')
        except Exception as e:
            self.link_status.set('No se pudo activar el enlace. Cierra otras versiones de Outlook. '+str(e)[:65])
        self._build()
        self._update_common_password_status()
        self.after(1000,self.tick)
        self.protocol('WM_DELETE_WINDOW',self.close)

    def report_callback_exception(self,error_type,error,trace):
        record('outlook_callback_failed',error.with_traceback(trace))
        try:self.info.set('Error de interfaz; revisa el diagnóstico técnico antes de repetir la operación.')
        except Exception:pass

    def post_ui(self,callback):
        if not self._closed:self._ui_events.put(callback)

    def _can_begin(self,email):
        return (not self.browser.rate_limited and
                ((self.browser.running and self.active_email==email.strip().lower()) or
                 (not self.browser.running and not self.cooldown.remaining())))

    def _reservation_available(self):
        return (self._auto_queue_enabled.is_set() and not self.browser.running
                and not self.browser.rate_limited and not self.cooldown.remaining())

    def _reserve_email(self):
        # HTTP worker: use storage only, never Tk variables.
        vault=Vault()
        return next((item['email'] for item in self.queue.entries()
                     if item['estado']=='NUEVO' and item['seleccionado']
                     and vault.has_password(item['email'])),None)

    def _receive_browser_event(self, message):
        # La contraseña nunca se guarda ni se imprime en el diagnóstico.
        try:self.post_ui(lambda m=message:self._show_browser_event(m))
        except Exception:pass

    def _show_browser_event(self, message):
        self.browser_status.set(message)
        self.browser_events.append(message)
        self.browser_events=self.browser_events[-50:]

    def show_diagnostics(self):
        win=tk.Toplevel(self)
        win.title('Diagnóstico · Inicio de Outlook')
        win.geometry('740x400')
        win.configure(bg=BG)
        tk.Label(win,text='PASOS DEL NAVEGADOR (sin contraseñas ni códigos)',
                 bg=BG,fg=GOLD,font=('Segoe UI',11,'bold')).pack(anchor='w',padx=12,pady=(12,4))
        box=scrolledtext.ScrolledText(win,wrap='word',height=16,
                     bg=BOX,fg=WHITE,insertbackground=WHITE,font=('Consolas',10))
        box.pack(fill='both',expand=True,padx=12,pady=8)
        box.insert('1.0','\n'.join(self.browser_events) or 'Todavía no hay eventos del navegador.')
        box.configure(state='disabled')

    def _vault(self):
        if self.vault is None:self.vault=Vault()
        return self.vault

    def _update_common_password_status(self):
        try:
            enabled=self._vault().has_common_password()
            text=('Contraseña común guardada: se usará en todos los correos.' if enabled
                  else 'Contraseña común: sin configurar.')
        except Exception:
            text='No se pudo comprobar la contraseña común guardada.'
        self.common_password_status.set(text)

    def save_password_for_all(self):
        password=self.password.get()
        if not password:
            messagebox.showerror('Contraseña común','Escribe arriba la contraseña que usarán todos los correos.')
            return
        try:
            self._vault().set_common_password(password)
        except Exception as exc:
            messagebox.showerror('Contraseña común','No se pudo guardar la contraseña cifrada ('+type(exc).__name__+').')
            return
        self.password.set('')
        self.save_pw.set(False)
        self._update_common_password_status()
        self.info.set('Contraseña común guardada para todos los correos actuales y futuros. Se conserva al cerrar el programa.')

    def forget_common_password(self):
        try:
            self._vault().clear_common_password()
        except Exception as exc:
            messagebox.showerror('Contraseña común','No se pudo quitar la contraseña común ('+type(exc).__name__+').')
            return
        self.password.set('')
        self._update_common_password_status()
        self.info.set('Contraseña común eliminada. Se usarán las claves individuales que ya estuvieran guardadas.')

    def _mail(self):
        if self.service is None:
            cid=self.client_id.get().strip()
            if not re.fullmatch(r'[0-9a-fA-F-]{36}',cid):
                raise RuntimeError('Para leer correo automáticamente necesitas un ID de aplicación Microsoft autorizado. El inicio en incógnito funciona sin ese ID.')
            self.service=MailService(client_id=cid)
        return self.service

    def label(self,parent,text,color=GRAY,size=10,bold=False):
        return tk.Label(parent,text=text,bg=parent.cget('bg'),fg=color,
                 font=('Segoe UI',size,'bold' if bold else 'normal'),anchor='w',justify='left')

    def button(self,parent,text,fn,accent=False):
        return tk.Button(parent,text=text,command=fn,bg=GOLD if accent else '#343E49',
              fg=BG if accent else WHITE,activebackground='#EED18C',relief='flat',bd=0,
              padx=14,pady=10,font=('Segoe UI',10,'bold'))

    def _build(self):
        head=tk.Frame(self,bg=BG,padx=16,pady=15);head.pack(fill='x')
        self.label(head,'GESTORÍA DÍAZ · OUTLOOK',GOLD,20,True).pack(anchor='w')
        self.label(head,'Sesión incógnita · Separado del bot IMSS · Conexión privada local',GRAY,10).pack(anchor='w')
        tk.Label(head,textvariable=self.cooldown_label,bg=BG,fg=GOLD,font=('Segoe UI',12,'bold'),anchor='w').pack(anchor='w',pady=(6,0))
        current_row=tk.Frame(head,bg=BG);current_row.pack(fill='x',pady=(8,1))
        self.label(current_row,'CORREO EN USO: ',GOLD,11,True).pack(side='left')
        tk.Label(current_row,textvariable=self.active_email_label,bg=BG,fg=WHITE,
                 font=('Segoe UI',12,'bold'),anchor='w').pack(side='left',padx=(2,12))
        self.button(current_row,'COPIAR CORREO',self.copy_current_email).pack(side='left')
        # Área desplazable: funciona también en pantallas pequeñas de Windows.
        area=tk.Frame(self,bg=BG);area.pack(fill='both',expand=True,padx=16,pady=(0,8))
        canvas=tk.Canvas(area,highlightthickness=0,bg=BOX)
        sb=ttk.Scrollbar(area,orient='vertical',command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side='right',fill='y');canvas.pack(side='left',fill='both',expand=True)
        main=tk.Frame(canvas,bg=BOX,padx=17,pady=13)
        content_id=canvas.create_window((0,0),window=main,anchor='nw')
        main.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(content_id,width=e.width))
        def wheel(e):
            canvas.yview_scroll(-int(e.delta/120) if e.delta else 0,'units')
        canvas.bind('<Enter>',lambda e:canvas.bind_all('<MouseWheel>',wheel))
        canvas.bind('<Leave>',lambda e:canvas.unbind_all('<MouseWheel>'))

        self.label(main,'1 · INICIAR SESIÓN EN OUTLOOK',GOLD,11,True).pack(anchor='w',pady=(0,8))
        row=tk.Frame(main,bg=BOX);row.pack(fill='x')
        c=tk.Frame(row,bg=BOX);c.pack(side='left',fill='x',expand=True,padx=(0,10))
        self.label(c,'Correo electrónico').pack(anchor='w')
        ttk.Entry(c,textvariable=self.email).pack(fill='x',ipady=5)
        c=tk.Frame(row,bg=BOX);c.pack(side='left',fill='x',expand=True)
        self.label(c,'Contraseña (no se comparte con IMSS)').pack(anchor='w')
        ttk.Entry(c,textvariable=self.password,show='●').pack(fill='x',ipady=5)
        tk.Checkbutton(main,text='Guardar contraseña individual (si no hay contraseña común)',
            variable=self.save_pw,bg=BOX,fg=GRAY,activebackground=BOX,activeforeground=WHITE,
            selectcolor='#273544').pack(anchor='w',pady=6)
        common_bar=tk.Frame(main,bg=BOX);common_bar.pack(anchor='w',pady=(0,4))
        self.button(common_bar,'GUARDAR PARA TODOS',self.save_password_for_all).pack(side='left',padx=(0,9))
        self.button(common_bar,'OLVIDAR COMÚN',self.forget_common_password).pack(side='left')
        tk.Label(main,textvariable=self.common_password_status,bg=BOX,fg=GRAY,
                 font=('Segoe UI',9),anchor='w').pack(fill='x',pady=(0,4))
        bar=tk.Frame(main,bg=BOX);bar.pack(anchor='w',pady=(2,8))
        self.button(bar,'ABRIR OUTLOOK EN INCÓGNITO',self.open_incognito,True).pack(side='left',padx=(0,9))
        self.button(bar,'REINTENTAR CORREO',self.browser.retry_email).pack(side='left',padx=(0,9))
        self.button(bar,'CERRAR PRIVADO',self.close_private).pack(side='left')
        self.button(bar,'VER DIAGNÓSTICO',self.show_diagnostics).pack(side='left',padx=(9,0))
        self.button(main,'REABRIR LOGIN MICROSOFT (INCÓGNITO)',self.browser.reopen_form).pack(anchor='w',pady=(0,7))
        self.button(main,'ABRIR BANDEJA OUTLOOK (DESPUÉS DE INICIAR SESIÓN)',self.browser.open_mail).pack(anchor='w',pady=(0,7))
        self.label(main,'Si Microsoft pide verificación de identidad, complétala en su sitio.',GRAY,9).pack(anchor='w')
        self.label(main,'Remitente EXACTO del correo de validación IMSS (para búsqueda automática)',GRAY,9).pack(anchor='w',pady=(8,0))
        ttk.Entry(main,textvariable=self.sender).pack(fill='x',ipady=4)
        self.label(main,'Por seguridad, sin remitente y fecha verificables podrás enviar el código manualmente.',GRAY,9).pack(anchor='w',pady=(3,0))
        self.label(main,'CUENTAS TXT · CAMBIO CONTROLADO',GOLD,11,True).pack(anchor='w',pady=(10,4))
        controls=tk.Frame(main,bg=BOX);controls.pack(fill='x',pady=(0,3))
        self.button(controls,'IMPORTAR TXT',self.import_txt).pack(side='left',padx=(0,8))
        self.button(controls,'VER / ELEGIR CUENTA',self.manage_accounts).pack(side='left',padx=(0,8))
        self.button(controls,'SIGUIENTE NUEVA',self.next_account).pack(side='left')
        tk.Label(main,textvariable=self.accounts_label,bg=BOX,fg=GRAY,font=('Segoe UI',9),anchor='w').pack(fill='x')
        self.label(main,'Estado de cada correo: NUEVO (sin intento) o USADO (se inició un acceso).',GRAY,9).pack(anchor='w')
        tk.Checkbutton(main,text='Usar automáticamente la cuenta SELECCIONADA que solicite IMSS',
            variable=self.auto_queue,bg=BOX,fg=WHITE,activebackground=BOX,activeforeground=WHITE,
            selectcolor='#273544',command=self.save_auto_queue).pack(anchor='w',pady=(4,0))
        self.label(main,'Solo una cuenta a la vez, pausa de 60 s y detención ante Microsoft 429.',GRAY,9).pack(anchor='w')
        self.label(main,'2 · ENLACE CON EL BOT IMSS',GOLD,11,True).pack(anchor='w',pady=(10,6))
        self.label(main,'El bot IMSS envía la solicitud aquí cuando ambos programas están abiertos.',GRAY,9).pack(anchor='w')
        self.label(main,'',GREEN,10).pack_forget()
        self.label(main,'Estado:').pack(anchor='w',pady=(4,0))
        tk.Label(main,textvariable=self.link_status,bg=BOX,fg=GREEN,font=('Segoe UI',10),
                 wraplength=700,justify='left',anchor='w').pack(fill='x',pady=3)
        row=tk.Frame(main,bg=BOX);row.pack(fill='x',pady=(4,6))
        tk.Label(row,text='Código IMSS',bg=BOX,fg=GRAY,font=('Segoe UI',10)).pack(side='left',padx=(0,9))
        ttk.Entry(row,textvariable=self.code,width=13).pack(side='left',ipady=4,padx=(0,10))
        self.button(row,'ENVIAR CÓDIGO AL IMSS',self.send_manual_code,True).pack(side='left')
        self.more=tk.Frame(main,bg=BOX)
        self.more_visible=False
        tk.Button(main,text='▸ Configurar lectura automática (opcional)',bg=BOX,fg=GOLD,
                  relief='flat',bd=0,font=('Segoe UI',10),anchor='w',
                  command=self.toggle_advanced).pack(anchor='w',pady=(9,4))
        row=tk.Frame(self.more,bg=BOX);row.pack(fill='x')
        c=tk.Frame(row,bg=BOX);c.pack(side='left',fill='x',expand=True,padx=(0,8))
        self.button(row,'AUTORIZAR LECTURA',self.authorize_microsoft).pack(side='left',pady=(16,0))
        row_app=tk.Frame(self.more,bg=BOX);row_app.pack(fill='x',pady=(3,0))
        self.label(row_app,'ID de aplicación Microsoft (lectura automática)',GRAY,9).pack(side='left')
        ttk.Entry(row_app,textvariable=self.client_id,width=39).pack(side='left',padx=(8,0))
        self.label(self.more,'La lectura automática requiere Mail.Read de Microsoft y remitente exacto.\n'
                   'Abrir Outlook en incógnito no concede ese permiso.',GRAY,9).pack(anchor='w',pady=(4,0))
        self.status_label=self.label(main,'Estado del navegador:',GRAY,9)
        self.status_label.pack(anchor='w',pady=(10,0))
        tk.Label(main,textvariable=self.browser_status,bg=BOX,fg=WHITE,font=('Segoe UI',9),
                 wraplength=700,justify='left',anchor='w').pack(fill='x')
        tk.Label(self,textvariable=self.info,bg=BG,fg=GOLD,font=('Segoe UI',9),
                 wraplength=735,justify='left').pack(anchor='w',padx=18,pady=(0,9))

    def toggle_advanced(self):
        self.more_visible=not self.more_visible
        if self.more_visible:self.more.pack(fill='x',before=self.status_label)
        else:self.more.pack_forget()

    def copy_current_email(self):
        email=(self.active_email if self.browser.running else None) or self.email.get().strip().lower()
        if not email or not EMAIL_RE.fullmatch(email):
            self.info.set('No hay correo válido para copiar.');return
        try:
            self.clipboard_clear();self.clipboard_append(email);self.update_idletasks()
            self.info.set('Correo copiado al portapapeles: '+email)
        except Exception as exc:
            self.info.set('No se pudo copiar el correo ('+type(exc).__name__+').')

    def close_private(self):
        """Cierra una sesión privada y exige 60 s antes de otra cuenta."""
        if self.browser.running:
            self.cooldown.begin()
            self.info.set('Cerrando incógnito. La siguiente cuenta estará disponible tras el enfriamiento.')
        self.browser.stop()

    def _guard_new_login(self):
        if self.browser.rate_limited:
            messagebox.showwarning('Microsoft 429',
                'Microsoft aplicó Too Many Requests. Se pausaron TODAS las cuentas. No se intentará otra hasta que Microsoft retire el límite. Cierra este bot.')
            return False
        if self.browser.running:
            self.info.set('Primero cierra la sesión privada anterior.');return False
        left=self.cooldown.remaining()
        if left:
            self.info.set(f'Enfriamiento activo. Espera {left} segundos antes de iniciar otra cuenta.')
            return False
        return True

    def import_txt(self):
        filename=filedialog.askopenfilename(title='Selecciona TXT con correos y contraseñas',
                                              filetypes=[('Archivos de texto','*.txt'),('Todos','*.*')])
        if not filename:return
        try:
            accounts=decode_file(filename)
            if not accounts:raise ValueError('No encontré direcciones válidas. Usa correo | CONTRA: contraseña')
            with_password=sum(1 for _e,pw in accounts if pw)
            if not messagebox.askyesno('Importar cuentas',
                f'Se encontraron {len(accounts)} correos y {with_password} contraseñas.\n'
                'Las contraseñas se cifrarán con Windows DPAPI.\n'
                'El TXT ORIGINAL seguirá sin cifrar hasta que lo borres tú. ¿Importar?'):
                return
            self._vault().save(accounts)
            added=self.queue.add([e for e,_ in accounts])
            self._update_counts()
            self.info.set(f'TXT importado: {len(accounts)} correos ({added} nuevos). Las claves están cifradas para este usuario de Windows.')
            self.manage_accounts()
        except Exception as ex:
            messagebox.showerror('Importación TXT',str(ex)[:220])

    def _update_counts(self):
        try:
            c=self.queue.counts()
            self.accounts_label.set(f'Cuentas: {c["total"]} · Nuevo: {c["nuevos"]} · Usado: {c["usados"]} · Seleccionados: {c["seleccionados"]}')
        except Exception:self.accounts_label.set('No se pudo leer la lista de cuentas.')

    def _choose_account(self,email):
        if self.browser.running:
            messagebox.showinfo('Sesión activa','Cierra la ventana privada antes de seleccionar otra cuenta.')
            return
        if not self.queue.activate(email):
            messagebox.showwarning('Cuenta','La cuenta no está disponible.');return
        self.email.set(email)
        self.password.set('')
        self.info.set('Seleccionada '+email+'. Todavía figura como NUEVO hasta iniciar el acceso.')
        self._update_counts()

    def next_account(self):
        if self.browser.running:
            messagebox.showinfo('Sesión activa','Cierra primero la ventana privada.');return
        if self.browser.rate_limited:
            messagebox.showwarning('Microsoft 429','Acceso en pausa por límite de Microsoft. No cambiaré de cuenta.');return
        address=self.queue.choose(exclude=self.email.get().strip().lower()) or self.queue.choose()
        if not address:
            self.info.set('No hay cuentas NUEVAS seleccionadas. Marca cuentas desde VER / ELEGIR CUENTA.');return
        self._choose_account(address)

    def manage_accounts(self):
        win=tk.Toplevel(self);win.title('Cuentas Outlook · Nuevo / Usado')
        win.geometry('760x570');win.configure(bg=BG)
        style=ttk.Style(win)
        style.configure('GD.Treeview',background=BOX,foreground=WHITE,fieldbackground=BOX,rowheight=26)
        style.map('GD.Treeview',background=[('selected','#705C34')],foreground=[('selected',WHITE)])
        self.label(win,'LISTADO DE CUENTAS',GOLD,13,True).pack(anchor='w',padx=15,pady=(15,6))
        self.label(win,'NUEVO = aún no se inició un acceso con este bot. USADO = ya se intentó acceder.',GRAY,9).pack(anchor='w',padx=15)
        self.label(win,'Selecciona varias filas con Ctrl o Mayús, o pulsa SELECCIONAR TODOS.',GRAY,9).pack(anchor='w',padx=15,pady=(0,6))
        outer=tk.Frame(win,bg=BG);outer.pack(fill='both',expand=True,padx=15,pady=8)
        sc=tk.Scrollbar(outer);sc.pack(side='right',fill='y')
        tree=ttk.Treeview(outer,columns=('correo','estado','sel'),show='headings',selectmode='extended',yscrollcommand=sc.set,style='GD.Treeview')
        tree.heading('correo',text='CORREO');tree.heading('estado',text='ESTADO');tree.heading('sel',text='EN LISTA')
        tree.column('correo',width=415,anchor='w');tree.column('estado',width=105,anchor='center');tree.column('sel',width=105,anchor='center')
        tree.pack(side='left',fill='both',expand=True);sc.configure(command=tree.yview)
        entries=self.queue.entries()
        for n,row in enumerate(entries):
            tree.insert('', 'end', iid=str(n),values=(row['email'],row['estado'],'Sí' if row['seleccionado'] else 'No'))
        # El resaltado inicial reproduce las cuentas previamente seleccionadas.
        already=[str(n) for n,row in enumerate(entries) if row['seleccionado']]
        if already:tree.selection_set(already)
        def refresh():
            for n,row in enumerate(self.queue.entries()):
                tree.item(str(n),values=(row['email'],row['estado'],'Sí' if row['seleccionado'] else 'No'))
            self._update_counts()
        def apply():
            picked=[entries[int(i)]['email'] for i in tree.selection()]
            self.queue.set_selected(picked);refresh()
            self.info.set(f'Se seleccionaron {len(picked)} cuentas. Solo NUEVO se procesa automáticamente.')
        def all_accounts():
            tree.selection_set(tree.get_children());self.queue.select_all();refresh()
        def none():
            tree.selection_remove(tree.selection());self.queue.deselect_all();refresh()
        def choose_one():
            selected=tree.selection()
            if not selected:
                messagebox.showinfo('Seleccionar cuenta','Selecciona una fila.');return
            self._choose_account(entries[int(selected[0])]['email'])
            refresh()
        bar=tk.Frame(win,bg=BG);bar.pack(fill='x',padx=15,pady=(5,12))
        self.button(bar,'SELECCIONAR TODOS',all_accounts,True).pack(side='left',padx=(0,6))
        self.button(bar,'QUITAR TODOS',none).pack(side='left',padx=(0,6))
        self.button(bar,'GUARDAR SELECCIÓN',apply).pack(side='left',padx=(0,6))
        self.button(bar,'ELEGIR UNA',choose_one).pack(side='left')
        self.label(win,'Importar o seleccionar no marca un correo como USADO. Los estados se conservan al cerrar.',GRAY,9).pack(anchor='w',padx=15,pady=(0,10))

    def save_auto_queue(self):
        if self.auto_queue.get():self._auto_queue_enabled.set()
        else:self._auto_queue_enabled.clear()
        settings=get_settings()
        settings['auto_queue']=bool(self.auto_queue.get())
        save_settings(settings)
        self.info.set('Entrada automática por solicitud IMSS '+('activada.' if self.auto_queue.get() else 'desactivada.'))

    def _maybe_start_request_account(self, state):
        """Un único inicio por solicitud y cuenta, solo tras la pausa y con autorización."""
        if not self.auto_queue.get() or state.get('status')!='ESPERANDO_CODIGO':return
        req_id=state.get('request_id')
        email=str(state.get('email') or '').strip().lower()
        if not req_id or not EMAIL_RE.fullmatch(email):return
        if req_id==self._auto_started_request:return
        if self.browser.running or self.browser.rate_limited or self.cooldown.remaining():return
        if not self.queue.is_selected_new(email):return
        try: pw=self._vault().password(email)
        except Exception as exc:
            self.info.set('Cuenta seleccionada sin contraseña accesible: '+email)
            return
        if not pw:return
        self.email.set(email);self.password.set('')
        if self._start_browser(email,pw):self._auto_started_request=req_id

    def _start_browser(self,email,pw):
        if not self._guard_new_login():return False
        self.browser_events=[]
        self.browser_status.set('Abriendo Microsoft en incógnito…')
        self.browser.set_sender(self.sender.get())
        try:self.browser.start(email,pw)
        except Exception as exc:
            self.info.set('No se pudo abrir Outlook: '+str(exc)[:100]);return False
        # USADO significa que la cuenta ya se entregó al bot para iniciar acceso.
        self.queue.mark_started(email)
        self.active_email=email
        self.active_email_label.set(email)
        self._previous_browser_running=True
        self.password.set('')
        self._update_counts()
        self.info.set('Inicio solicitado para '+email+'. Ahora aparece como USADO.')
        return True

    def open_incognito(self):
        email=self.email.get().strip().lower()
        if not EMAIL_RE.fullmatch(email):messagebox.showerror('Correo','Escribe un correo válido.');return
        pw=self.password.get()
        try:
            vault=self._vault()
            common_enabled=vault.has_common_password()
            if common_enabled or not pw:
                pw=vault.password(email) or ''
        except Exception as exc:
            messagebox.showerror('Contraseña','No se pudo leer la contraseña cifrada ('+type(exc).__name__+').')
            return
        if not pw:
            messagebox.showerror('Contraseña','Escribe la contraseña o guarda una antes.');return
        if not self._guard_new_login():return
        if self.save_pw.get() and not common_enabled:
            try:self._vault().save([(email,pw)])
            except Exception as e:messagebox.showerror('Guardado',str(e)[:160]);return
        save_settings({'email':email,'sender':self.sender.get().strip().lower(),'client_id':self.client_id.get().strip(),'auto_queue':bool(self.auto_queue.get())})
        self._start_browser(email,pw)

    def _deliver_browser_code(self, request_id, code, email):
        # Callback del hilo Playwright: no tocar Tk aquí.
        self.state.put_code(request_id,code,email=email)
        self.post_ui(lambda:self.info.set('Código verificado del correo reciente y enviado a IMSS por el enlace local.'))

    def send_manual_code(self):
        code=self.code.get().strip()
        if not re.fullmatch('[0-9]{6}',code):
            messagebox.showerror('Código','Introduce seis dígitos.');return
        data=self.state.status()
        if data['status'] not in ('ESPERANDO_CODIGO','CODIGO_DISPONIBLE'):
            messagebox.showerror('IMSS','No hay una solicitud IMSS pendiente. Inicia el trámite en el otro programa.');return
        actual=self.email.get().strip().lower()
        try:self.state.put_code(data['request_id'],code,email=actual)
        except Exception as e:messagebox.showerror('No se envió',str(e));return
        self.code.set('')
        self.info.set('Código enviado a IMSS por el enlace local. No se guardó en disco.')

    def authorize_microsoft(self):
        email=self.email.get().strip().lower()
        if not EMAIL_RE.fullmatch(email):messagebox.showerror('Correo','Introduce un correo válido.');return
        sender=self.sender.get().strip().lower()
        if not EMAIL_RE.fullmatch(sender):messagebox.showerror('Remitente','Indica el remitente real y exacto del código recibido.');return
        save_settings({'email':email,'sender':sender,'client_id':self.client_id.get().strip(),'auto_queue':bool(self.auto_queue.get())})
        try:self._mail()
        except Exception as exc:
            self.info.set('No se pudo preparar Microsoft: '+type(exc).__name__);return
        self.info.set('Abriendo autorización oficial de Microsoft para leer solo el correo de esta cuenta…')
        def worker():
            try:
                self._mail().connect_interactive(email)
                self.post_ui(lambda:self.info.set('Lectura de Microsoft autorizada. El bot buscará códigos nuevos del remitente configurado.'))
            except Exception as e:
                msg=str(e)[:200]
                self.post_ui(lambda:self.info.set('Autorización no completada: '+msg))
        threading.Thread(target=worker,daemon=True).start()

    def tick(self):
        try:
            for _ in range(100):
                try:callback=self._ui_events.get_nowait()
                except ui_queue.Empty:break
                try:callback()
                except Exception as exc:record('outlook_ui_callback_failed',exc)
            self._tick_once()
        except Exception as exc:
            record('outlook_tick_failed',exc)
        finally:
            if not self._closed:self.after(1000,self.tick)

    def _tick_once(self):
        # El cierre inesperado del navegador también inicia la pausa.
        if self._previous_browser_running and not self.browser.running:
            self.active_email_label.set('Ninguna sesión abierta')
            self.cooldown.begin()
            self._previous_browser_running=False
        elif self.browser.running:
            self._previous_browser_running=True
            if self.active_email:self.active_email_label.set(self.active_email)
        remain=self.cooldown.remaining()
        if self.browser.rate_limited:
            self.cooldown_label.set('MICROSOFT 429 · Acceso detenido. No cambiar de cuenta.')
        elif remain:
            self.cooldown_label.set(f'ENFRIAMIENTO · {remain:02d} segundos antes de otra cuenta')
        else:
            self.cooldown_label.set('ENFRIAMIENTO · Listo para iniciar')
        self._update_counts()
        self.browser.set_sender(self.sender.get())
        state=self.state.status()
        self._maybe_start_request_account(state)
        if state['status']=='SIN_SOLICITUD':
            self.link_status.set('Enlace listo. Esperando que IMSS inicie un trámite…' if self.server else 'Puerto ocupado; cierra el Outlook anterior.')
        elif state['status']=='SOLICITUD_IMSS_ENVIADA':
            self.link_status.set('IMSS terminó la solicitud. Espera el mensaje de Historia Laboral y revisa el enlace al PDF.')
        elif state['status']=='CADUCADA':
            self.link_status.set('Solicitud IMSS caducada; inicia una nueva en IMSS.')
        else:
            self.link_status.set('Solicitud IMSS para '+str(state['email'])+' · '+str(state['status']))
            if state['status']=='ESPERANDO_CODIGO' and not self.auto_busy and (time.monotonic()-self.last_auto_check)>12:
                sender=self.sender.get().strip().lower()
                if (EMAIL_RE.fullmatch(sender) and self.client_id.get().strip() and
                    self.email.get().strip().lower()==state['email']):
                    self._mail()  # create the service on the Tk thread
                    self.auto_busy=True;self.last_auto_check=time.monotonic()
                    threading.Thread(target=self._try_auto_code,args=(state,sender),daemon=True).start()


    def _try_auto_code(self,request,sender):
        try:
            found=self._mail().code(request['email'],sender,request['started'])
            if found and found.get('code'):
                self.state.put_code(request['request_id'],found['code'],email=request['email'])
                self.post_ui(lambda:self.info.set('Código detectado con permiso de Microsoft y enviado al bot IMSS.'))
        except Exception as e:
            # No imprimir tokens/códigos de mensajes. Evita afirmaciones de éxito.
            short=str(e)[:130]
            if ('sin autorización' in short.lower() or 'faltan dependencias' in short.lower()):
                self.post_ui(lambda:self.info.set('Lectura automática inactiva: '+short))
        finally:self.auto_busy=False

    def close(self):
        self._closed=True
        self.close_private()
        if self.server:
            try:self.server.close()
            except Exception:pass
        self.destroy()

if __name__=='__main__':
    from ejecutar import main
    main()
