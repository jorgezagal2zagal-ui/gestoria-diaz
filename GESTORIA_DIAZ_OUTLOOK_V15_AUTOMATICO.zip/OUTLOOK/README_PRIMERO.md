# Gestoría Díaz — Outlook automático V15

## Abrir el programa

1. Cierra las versiones anteriores y extrae este ZIP en una carpeta nueva.
2. Ejecuta `OUTLOOK/ABRIR_OUTLOOK.bat`. Si falta el entorno, prepara las dependencias.
3. Si no hay Edge, Chrome ni Chromium instalado, se prepara Chromium antes de abrir el panel.
4. Con una cuenta elegida y su contraseña guardada, el acceso comienza automáticamente.
   El botón **INICIAR** también ejecuta el flujo completo; no hace falta abrir la bandeja aparte.

Se necesita Windows y Python 3.10 o posterior. Las dependencias de Windows de 64 bits
se resolvieron y descargaron para Python 3.12. El BAT y DPAPI nativo no se ejecutaron en Linux.

## Pantalla principal

- **INICIAR:** abre el navegador privado, introduce el correo y la contraseña guardada y abre Outlook.
- **DETENER:** detiene el acceso y desactiva el arranque automático hasta volver a pulsar INICIAR.
- **IMPORTAR TXT:** importa y marca las cuentas del archivo; no abre todas simultáneamente.
- **CUENTAS:** elige qué cuenta o cuentas pueden utilizarse.
- **COPIAR CORREO** y **AJUSTES** son los únicos controles secundarios.

El estado del navegador, los errores y la pausa quedan siempre visibles.
Los controles de lectura opcional, remitente, envío manual y diagnóstico están en **AJUSTES**.

## Contraseña y cuentas

En **AJUSTES > Contraseña**, escribe una vez tu contraseña común y pulsa **GUARDAR PARA TODOS**.
Se guarda con DPAPI de tu usuario de Windows y se usa para los correos actuales y futuros.
No hay una contraseña incorporada en el ZIP. Las cuentas y claves guardadas anteriormente
se conservan en el mismo directorio de datos del usuario.

La primera ejecución de V15 activa el arranque automático. Una detención posterior se conserva
al volver a abrir el programa. Puedes reactivarlo con INICIAR o desde Ajustes.
Fuera de una solicitud IMSS se abre una sola cuenta elegida por inicio: no recorre la lista al
cerrar el navegador. Una solicitud IMSS solo utiliza su cuenta seleccionada correspondiente.

## Pausa y errores

El enfriamiento entre sesiones es de **30 segundos**. Un error antes de crear la pestaña
no marca la cuenta como usada ni impone una pausa ficticia. Los errores de arranque no se
ocultan con el mensaje de cierre. Edge, Chrome y Chromium se prueban con tiempos limitados.

Se conservan los dos reintentos (5 y 10 segundos) del aviso «inicio de sesión con contraseña
no disponible». No se repite indefinidamente. Microsoft 429 mantiene detenido el acceso;
la pausa de 30 segundos no levanta ese bloqueo. Las verificaciones de identidad que pida
Microsoft deben completarse en su propia página.

## Validación

- `python validar.py` / `PRUEBAS.bat`: 89 pruebas unittest más cola, migración y enlace HTTP local.
- `python PROBAR_INTERFAZ_V15.py --mode auto`: panel Tk real, navegador visible y páginas ficticias.
- `python PROBAR_INTERFAZ_V15.py --mode button`: mismo recorrido mediante el botón INICIAR.
- En Linux con un escritorio y Chromium del sistema, agrega `--chromium /usr/bin/chromium`.

Se comprobaron ambos recorridos, el cierre/reintento, la contraseña común, la apertura
automática de la bandeja después del acceso y DETENER. Ninguna prueba utilizó cuentas reales.
Pendiente comprobar el BAT, DPAPI nativo, las ventanas de Windows y una cuenta Microsoft real.
Los documentos V12/V13/V14 incluidos son antecedentes de las versiones anteriores.
