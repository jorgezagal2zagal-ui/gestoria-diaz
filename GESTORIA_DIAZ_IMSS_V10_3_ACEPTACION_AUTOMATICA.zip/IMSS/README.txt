IMSS V10.3: aceptación automática de SÍ, QUIERO HACER EL CAMBIO.
Lee CAMBIO_V10_3.md. Ejecuta ABRIR_BOT.bat.
Marca la autorización automática para ESTE trámite antes de iniciar o mientras espera en el aviso.
No necesitas pulsar además AUTORIZAR CAMBIO. El siguiente folio necesita autorización propia.
122 pruebas locales; pendiente clic real en HONOR. Sin PIN ni datos de las capturas.
