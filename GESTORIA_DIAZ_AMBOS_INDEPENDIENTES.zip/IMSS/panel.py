"""Panel Windows: Wi-Fi ADB + CURP/correo + código manual de IMSS Digital.
No usa claves de correo ni elude verificaciones; el PIN opcional se almacena cifrado por Windows.
"""
from __future__ import annotations

import base64
import io
import os
from diagnostico import record
import ipaddress
import math
import queue
import re
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk
from urllib.request import Request, urlopen
from zipfile import ZipFile

from adb_imss import ADB, APP_PACKAGE, DeviceError, IMSSFlow, adb_binary, connect_wifi
import pin_vault
from mail_link import Session, SessionInvalid
from enlace import Client, LinkError
from solicitudes import Requests, DPAPIProtector, CURP
from pin_default import DEFAULT_PHONE_PIN, configured_pin

BASE = Path(__file__).resolve().parent
GOLD, DARK, BLACK, PANEL, TXT, MUTED = '#D6B36C', '#151515', '#0C0C0C', '#1C1C1C', '#F8F6EF', '#A5A5A5'


def valid_ipv4(s):
    try:
        return isinstance(ipaddress.ip_address(s), ipaddress.IPv4Address)
    except ValueError:
        return False


def valid_port(s):
    return isinstance(s,str) and bool(re.fullmatch('[0-9]{1,5}',s)) and 1 <= int(s) <= 65535


class IMSSPanel:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('Gestoría Díaz | IMSS Digital - V10 independiente')
        self.root.geometry('1040x750')
        self.root.minsize(940, 690)
        self.root.configure(bg=BLACK)
        self._closed=False
        self.q = queue.Queue()
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.advance = threading.Event()  # Espera sin sondear mientras solicita código/acción manual.
        self.running = False
        self._session=None
        self._prepared_form=None
        self._dispatch_busy=False
        self._prepare_generation=0
        self._pending_session=None
        self._pending_identity=None
        self._current_job=None
        self._jobs_store=None
        self._next_queue_check=0.0
        self._queue_retry=2.0
        self._auto_unlock_enabled=False
        self.link_enabled=tk.BooleanVar(value=False)
        self.queue_enabled=tk.BooleanVar(value=False)
        self.queue_status=tk.StringVar(value='Cola detenida; los datos se cifran con DPAPI en Windows.')
        self.connected = False
        self.connecting = False
        self.adb = None
        self.flow = None
        self.screen_image = None
        self.scale = 1
        self.screen_size = (0, 0)
        self.email = tk.StringVar()
        self.curp = tk.StringVar()
        self.code = tk.StringVar()
        self.phone_pin = tk.StringVar()
        self.auto_unlock = tk.BooleanVar(value=False)
        self._session_pin, initial_pin_message = configured_pin(pin_vault)
        self._auto_unlock_attempted = False
        self.pin_storage_status = tk.StringVar(value=initial_pin_message)
        self.accept_privacy = tk.BooleanVar(value=False)
        self.ip = tk.StringVar(value='')
        self.port = tk.StringVar()
        self.status = tk.StringVar(value='Desconectado. Activa Depuración inalámbrica en tu Android.')
        self._make_ui()
        self.root.after(170, self.flush)
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        self.root.report_callback_exception=self._callback_error

    def _callback_error(self,error_type,error,trace):
        record('imss_callback_failed',error.with_traceback(trace))
        try:self.status.set('Error de interfaz. Revisa el diagnóstico técnico; no se confirmó la operación.')
        except Exception:pass

    def _lbl(self, parent, text, size=10, color=MUTED, bold=False, **kw):
        return tk.Label(parent, text=text, bg=parent['bg'], fg=color,
                        font=('Segoe UI', size, 'bold' if bold else 'normal'), **kw)

    def _entry(self, parent, variable, width=20, secret=False):
        return tk.Entry(parent, textvariable=variable, width=width, bg='#292929',
                        fg='white', insertbackground='white', highlightbackground='#494949',
                        highlightcolor=GOLD, highlightthickness=1, relief='flat',
                        font=('Segoe UI', 12), show='•' if secret else '', bd=7)

    def _button(self, parent, text, fn, gold=False, w=None):
        return tk.Button(parent, text=text, command=fn, bg=GOLD if gold else '#303030',
                         fg='#0E0E0E' if gold else 'white', activebackground='#F0CF8A',
                         activeforeground='black', relief='flat', cursor='hand2',
                         font=('Segoe UI', 10, 'bold'), padx=14, pady=9, width=w)

    def _make_ui(self):
        header = tk.Frame(self.root, bg=BLACK)
        header.pack(fill='x', padx=25, pady=(18, 10))
        self._lbl(header, 'GESTORÍA DÍAZ', 24, GOLD, True).pack(anchor='w')
        self._lbl(header, 'IMSS DIGITAL   /   CONSTANCIA DE SEMANAS COTIZADAS', 10, MUTED).pack(anchor='w')
        tk.Frame(self.root, bg=GOLD, height=2).pack(fill='x', padx=25)
        main = tk.Frame(self.root, bg=BLACK)
        main.pack(fill='both', expand=True, padx=25, pady=14)
        left_outer = tk.Frame(main, bg=DARK)
        left_outer.pack(side='left', fill='both', expand=True)
        self.left_canvas = tk.Canvas(left_outer, bg=DARK, highlightthickness=0)
        self.left_canvas.pack(side='left', fill='both', expand=True)
        scroll = tk.Scrollbar(left_outer, orient='vertical', command=self.left_canvas.yview)
        scroll.pack(side='right', fill='y')
        self.left_canvas.configure(yscrollcommand=scroll.set)
        left = tk.Frame(self.left_canvas, bg=DARK, padx=18, pady=14)
        window_id = self.left_canvas.create_window((0, 0), window=left, anchor='nw')
        left.bind('<Configure>', lambda e: self.left_canvas.configure(scrollregion=self.left_canvas.bbox('all')))
        self.left_canvas.bind('<Configure>', lambda e: self.left_canvas.itemconfigure(window_id, width=e.width))
        def scroll_left(e):
            if (self.left_canvas.winfo_rootx() <= e.x_root <= self.left_canvas.winfo_rootx() + self.left_canvas.winfo_width()
                    and self.left_canvas.winfo_rooty() <= e.y_root <= self.left_canvas.winfo_rooty() + self.left_canvas.winfo_height()):
                self.left_canvas.yview_scroll(int(-e.delta / 120), 'units')
        self.root.bind_all('<MouseWheel>', scroll_left)
        right = tk.Frame(main, bg=DARK, padx=14, pady=14, width=315)
        right.pack(side='right', fill='y', padx=(12, 0))
        right.pack_propagate(False)

        self._lbl(left, '1. CONEXIÓN AL CELULAR POR WI-FI', 11, GOLD, True).pack(anchor='w')
        row = tk.Frame(left, bg=DARK)
        row.pack(fill='x', pady=(8, 5))
        ipf = tk.Frame(row, bg=DARK)
        ipf.pack(side='left', padx=(0, 8), fill='x', expand=True)
        self._lbl(ipf, 'Dirección IP de Android').pack(anchor='w')
        self._entry(ipf, self.ip, 23).pack(fill='x', pady=(2, 0))
        portf = tk.Frame(row, bg=DARK)
        portf.pack(side='left', padx=(0, 3))
        self._lbl(portf, 'Puerto (opcional)').pack(anchor='w')
        self._entry(portf, self.port, 12).pack(pady=(2, 0))
        row2 = tk.Frame(left, bg=DARK)
        row2.pack(fill='x', pady=(4, 7))
        self._button(row2, 'CONECTAR', self.connect, gold=True).pack(side='left')
        self._button(row2, 'Emparejar (solo 1ª vez)', self.pair).pack(side='left', padx=8)
        self._button(row2, 'Instalar ADB', self.install_adb).pack(side='left')
        self._button(row2, 'DETECTAR PUERTO', self.detect_port).pack(side='left', padx=(8, 0))
        self._lbl(left, 'Si se detecta automáticamente, el puerto se rellena solo. Nunca uses el de vinculación.', 9).pack(anchor='w')
        self._lbl(left, 'PIN opcional del celular (privado; confirma tu identidad)').pack(anchor='w', pady=(7, 0))
        unlock_row = tk.Frame(left, bg=DARK)
        unlock_row.pack(fill='x', pady=(3, 7))
        self._entry(unlock_row, self.phone_pin, 12, secret=True).pack(side='left', fill='x', expand=True)
        self._button(unlock_row, 'DESBLOQUEAR CELULAR', self.unlock_phone, gold=True).pack(side='left', padx=(8, 0))
        self._button(left, 'ENVIAR PIN AHORA (SI ANDROID NO LO DETECTA)', self.send_pin_confirmed).pack(anchor='w', pady=(1, 8))
        pin_buttons = tk.Frame(left, bg=DARK)
        pin_buttons.pack(fill='x', pady=(0, 4))
        self._button(pin_buttons, 'GUARDAR PIN CIFRADO', self.save_phone_pin).pack(side='left')
        self._button(pin_buttons, 'OLVIDAR PIN GUARDADO', self.forget_phone_pin).pack(side='left', padx=8)
        self._lbl(left, '', 9).destroy()
        tk.Label(left, textvariable=self.pin_storage_status, bg=DARK, fg=MUTED,
                 anchor='w', font=('Segoe UI', 9)).pack(fill='x')
        tk.Checkbutton(left, text='Usar PIN cuando Android solicite desbloqueo o validación de identidad',
                       variable=self.auto_unlock, bg=DARK, fg=TXT,
                       selectcolor='#292929', activebackground=DARK,
                       activeforeground=TXT, font=('Segoe UI', 10), anchor='w').pack(fill='x', pady=(0, 4))
        self._lbl(left, 'El PIN solo se guarda con GUARDAR PIN CIFRADO; nunca viene incluido en el paquete.', 9).pack(anchor='w')
        tk.Frame(left, bg='#353535', height=1).pack(fill='x', pady=12)

        self._lbl(left, '2. DATOS PARA SOLICITAR LAS SEMANAS', 11, GOLD, True).pack(anchor='w')
        tk.Checkbutton(left,text='Conectar con Outlook independiente en esta PC',variable=self.link_enabled,
                       bg=DARK,fg=TXT,selectcolor=PANEL).pack(anchor='w',pady=4)
        self._lbl(left, 'Correo electrónico (opcional si Outlook asigna una cuenta)').pack(anchor='w', pady=(7, 0))
        self._entry(left, self.email).pack(fill='x', pady=(3, 5))
        self._lbl(left, 'CURP (18 caracteres)').pack(anchor='w')
        self._entry(left, self.curp).pack(fill='x', pady=(3, 7))
        tk.Checkbutton(left, text='He leído y acepto el Aviso de Privacidad del IMSS',
                       variable=self.accept_privacy, bg=DARK, fg=TXT,
                       selectcolor='#292929', activebackground=DARK,
                       activeforeground=TXT, font=('Segoe UI', 10),
                       anchor='w').pack(fill='x', pady=(2, 5))
        self._lbl(left, 'El cambio de dispositivo exige autorización expresa del titular en cada trámite.', 9).pack(anchor='w', pady=(2, 5))
        self._button(left, 'AUTORIZAR CAMBIO DE DISPOSITIVO', self.authorize_transfer).pack(anchor='w',pady=4)
        row3 = tk.Frame(left, bg=DARK)
        row3.pack(fill='x', pady=(2, 0))
        self._button(row3, 'INICIAR TRÁMITE', self.start, gold=True).pack(side='left')
        self._button(row3, 'REANUDAR', self.resume).pack(side='left', padx=7)
        self._button(row3, 'DETENER', self.halt).pack(side='left')
        tk.Frame(left, bg='#353535', height=1).pack(fill='x', pady=12)

        self._lbl(left,'COLA DE SOLICITUDES',11,GOLD,True).pack(anchor='w')
        controls=tk.Frame(left,bg=DARK);controls.pack(fill='x',pady=4)
        self._button(controls,'AGREGAR CURP',self.enqueue_request).pack(side='left')
        self._button(controls,'REVISAR FOLIO',self.review_request).pack(side='left',padx=4)
        self._button(left,'CAMBIAR CORREO DEL FOLIO (SOLO EN ACCESO)',self.change_request_email).pack(anchor='w',pady=4)
        self._button(controls,'CANCELAR FOLIO',self.cancel_request).pack(side='left')
        tk.Checkbutton(left,text='Procesar cola al quedar libres HONOR y Outlook',variable=self.queue_enabled,
                       bg=DARK,fg=TXT,selectcolor=PANEL).pack(anchor='w')
        self.queue_view=ttk.Treeview(left,columns=('folio','status'),show='headings',height=3)
        self.queue_view.heading('folio',text='Folio');self.queue_view.heading('status',text='Estado')
        self.queue_view.pack(fill='x',pady=4)
        tk.Label(left,textvariable=self.queue_status,bg=DARK,fg=MUTED,wraplength=560,justify='left').pack(anchor='w')
        self._lbl(left, '3. CÓDIGO DE VERIFICACIÓN' , 11, GOLD, True).pack(anchor='w')
        self._lbl(left, 'Cuando IMSS lo solicite, escribe aquí el código recibido.').pack(anchor='w', pady=(5, 4))
        code_row = tk.Frame(left, bg=DARK)
        code_row.pack(fill='x')
        self._entry(code_row, self.code, 14, secret=True).pack(side='left', fill='x', expand=True)
        self._button(code_row, 'ENVIAR CÓDIGO', self.send_code, gold=True).pack(side='left', padx=(8, 0))
        self._lbl(left, 'En modo conectado recibe el código verificado de Outlook. Nunca se guarda en archivos.', 9).pack(anchor='w', pady=(5, 0))
        tk.Frame(left, bg='#353535', height=1).pack(fill='x', pady=12)

        self._lbl(left, 'ESTADO DEL TRÁMITE', 11, GOLD, True).pack(anchor='w')
        self._lbl(left, '', 10).destroy()
        tk.Label(left, textvariable=self.status, bg=DARK, fg=TXT, anchor='w',
                 justify='left', wraplength=580, font=('Segoe UI', 10, 'bold')).pack(fill='x', pady=(6, 4))
        self.log = tk.Text(left, bg='#101010', fg='#DDD4BC', relief='flat', height=6,
                           highlightthickness=0, font=('Consolas', 9), state='disabled', wrap='word')
        self.log.pack(fill='both', expand=True, pady=(4, 7))
        self._button(left, 'TRAER PDF DE DESCARGAS DEL CELULAR', self.get_pdf).pack(anchor='w')
        self._lbl(left, 'Si el IMSS envía el documento al correo, descárgalo desde ese correo.', 9,
                  color=MUTED).pack(anchor='w', pady=(6, 0))

        self._lbl(right, 'PANTALLA DEL CELULAR', 11, GOLD, True).pack(anchor='center')
        self._lbl(right, 'Puedes tocar esta vista para pulsar botones.', 9).pack(anchor='center', pady=5)
        self.preview = tk.Canvas(right, width=280, height=395, bg='#050505',
                                 highlightbackground='#3A3A3A', highlightthickness=1)
        self.preview.pack(anchor='center', pady=(8, 6))
        self.preview.create_text(140, 187, text='Conecta el celular\npara ver la pantalla',
                                 fill=MUTED, font=('Segoe UI', 11), justify='center')
        self.preview.bind('<Button-1>', self.preview_tap)
        self._button(right, 'ACTUALIZAR VISTA', self.refresh_preview).pack(fill='x', pady=(4, 7))
        self._lbl(right, 'ESTADO ACTUAL', 10, GOLD, True).pack(anchor='w')
        tk.Label(right, textvariable=self.status, bg=DARK, fg=TXT, anchor='nw',
                 wraplength=275, justify='left', font=('Segoe UI', 10)).pack(fill='x', pady=(3, 0))

    def put(self, kind, payload):
        self.q.put((kind, payload))

    def log_line(self, message):
        self.put('log', message)

    def flush(self):
        try:
            self._flush_once()
            self._queue_tick()
        except Exception as exc:
            record('imss_ui_error',exc)
            if self.running:self.stop.set();self.advance.set()
        finally:
            if not self._closed:self.root.after(170,self.flush)

    def _flush_once(self):
        try:
            while True:
                kind, value = self.q.get_nowait()
                if kind == 'status':
                    self.status.set(value)
                elif kind == 'log':
                    self.log.configure(state='normal')
                    self.log.insert('end', '• ' + value + '\n')
                    self.log.see('end')
                    self.log.configure(state='disabled')
                elif kind == 'error':
                    self.status.set('Error: ' + value)
                    self.log.configure(state='normal')
                    self.log.insert('end', '⚠ ' + value + '\n')
                    self.log.see('end')
                    self.log.configure(state='disabled')
                elif kind == 'preview':
                    self.display_preview(value)
                elif kind == 'pdf_list':
                    self.pdf_dialog(value)
                elif kind == 'connected':
                    self.connected = bool(value)
                elif kind == 'port_found':
                    ip_found, port_found = value
                    # Actualiza los campos exclusivamente desde el hilo de Tkinter.
                    self.ip.set(ip_found)
                    self.port.set(port_found)
                elif kind == 'link_prepared':
                    self._on_prepared(*value)
                elif kind == 'prepare_failed':
                    self._on_prepare_failed(*value)
                elif kind == 'email_change_ready':
                    self._on_email_change_ready(*value)
                elif kind == 'flow_end':
                    self._on_flow_end(*value)
                elif kind == 'auto_connect':
                    self.connect()
        except queue.Empty:
            pass

    def display_preview(self, png: bytes):
        try:
            img = tk.PhotoImage(data=base64.b64encode(png).decode('ascii'))
            factor = max(1, math.ceil(img.width() / 280), math.ceil(img.height() / 395))
            scaled = img.subsample(factor)
            self.preview.delete('all')
            self.screen_image = scaled
            self.scale = factor
            self.screen_size = (img.width(), img.height())
            self.preview.create_image(0, 0, image=self.screen_image, anchor='nw')
        except tk.TclError as e:
            self.log_line('No se pudo presentar captura: ' + str(e))

    def _thread(self, fn):
        threading.Thread(target=fn, daemon=True).start()

    def _jobs(self):
        if self._jobs_store is None:
            self._jobs_store=Requests(DPAPIProtector())
            self._jobs_store.recover()
        return self._jobs_store

    def _refresh_jobs(self):
        rows=self._jobs().list()
        selected=self.queue_view.selection()
        for item in self.queue_view.get_children():self.queue_view.delete(item)
        for job in rows[-30:]:self.queue_view.insert('', 'end',iid=job['id'],values=(job['id'][:8],job['status']))
        self.queue_view.selection_set([item for item in selected if self.queue_view.exists(item)])
        return rows

    def enqueue_request(self):
        try:
            jid=self._jobs().enqueue(self.curp.get())
            email=self.email.get().strip().lower()
            if email:
                if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email):
                    self._jobs().set(jid,'CANCELADA',error='Correo inválido; no se inició')
                    raise DeviceError('Revisa el correo antes de agregar la solicitud.')
                self._jobs().set(jid,'PENDIENTE',email=email)
            self.curp.set('')
            self.queue_status.set('Solicitud guardada: '+jid[:8]+'. Activa procesar cola cuando hayas revisado el teléfono.')
            self._refresh_jobs()
        except Exception as exc:
            record('queue_enqueue_failed',exc)
            messagebox.showerror('No se agregó la solicitud',str(exc))

    def _release_job_link(self,jid):
        job=self._jobs().get(jid)
        link_id=job.get('link_id') if job else None
        if link_id:
            client=Client()
            state=client.status(link_id)
            if state.get('request_id')==link_id:
                if state.get('email'):self._jobs().set(jid,job['status'],email=state['email'])
                client.cancel(link_id)
            elif state.get('status')!='SIN_SOLICITUD':
                raise LinkError('Outlook está atendiendo otro folio; no se cambió su reserva.')
            self._jobs().set(jid,job['status'],link_id='')
        if self._pending_identity and self._pending_identity[0]==jid:
            self._pending_session=None;self._pending_identity=None

    def review_request(self):
        selected=self.queue_view.selection()
        if not selected or self.running or self._dispatch_busy:return
        jid=selected[0];job=self._jobs().get(jid)
        if not job or job['status']!='REQUIERE_ATENCION':return
        if not messagebox.askyesno('Revisar antes de reintentar',
            'Confirma que revisaste el HONOR, que IMSS volvió al inicio del trámite y que el correo sigue '
            'siendo válido. Se conservarán la CURP y el folio. No se repetirá ninguna vinculación sin autorización.'):
            return
        try:self._release_job_link(jid)
        except LinkError:
            self.queue_status.set('No se pudo liberar la reserva. Abre Outlook, revisa su sesión y vuelve a intentarlo.');return
        self._jobs().set(jid,'PENDIENTE',error='')
        self._next_queue_check=0
        self._refresh_jobs()

    def cancel_request(self):
        selected=self.queue_view.selection()
        if not selected or self.running or self._dispatch_busy:return
        jid=selected[0]
        if not messagebox.askyesno('Cancelar folio','¿Cancelar esta solicitud de la cola? Se conserva el historial.'):
            return
        try:self._release_job_link(jid)
        except LinkError:
            self.queue_status.set('No se pudo liberar la reserva remota; revisa Outlook antes de cancelar.');return
        self._jobs().set(jid,'CANCELADA',error='Cancelada por el operador')
        self._refresh_jobs()

    def change_request_email(self):
        selected=self.queue_view.selection()
        if not selected or self.running or self._dispatch_busy or not self.connected:return
        jid=selected[0];job=self._jobs().get(jid)
        if not job or job['status']!='REQUIERE_ATENCION':
            self.queue_status.set('Solo se cambia el correo de un folio que requiere atención.');return
        new=simpledialog.askstring('Cambiar correo conservando folio','Correo nuevo (sin contraseña):')
        if new is None:return
        new=new.strip().lower()
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',new) or new==job.get('email'):
            messagebox.showerror('Correo','Introduce otro correo válido.');return
        if not messagebox.askyesno('Conservar CURP y folio',
                '¿Autorizas cambiar solo el correo de este folio? Se comprobará que IMSS siga en ACCESO, '
                'antes de solicitar un código. La CURP no se modificará.'):
            return
        self._dispatch_busy=True
        def work():
            try:
                with self.lock:
                    nodes=self.adb.hierarchy()
                    probe=IMSSFlow(self.adb,'','',lambda _:None)
                    summary=probe.screen_summary(nodes)
                    allowed=(not ADB.credential_labels(nodes) and not probe.device_transfer_dialog(nodes)
                        and not probe.is_code_screen(nodes) and 'curp' in summary and 'correo' in summary
                        and len([node for node in nodes if node.editable])>=2
                        and any(word in summary for word in ('iniciar sesion','ingresar','acceso')))
                self.put('email_change_ready',(jid,job.get('email'),new,allowed))
            except Exception as exc:
                record('email_change_stage_check_failed',exc)
                self.put('email_change_ready',(jid,job.get('email'),new,False))
        self._thread(work)

    def _on_email_change_ready(self,jid,old,new,allowed):
        self._dispatch_busy=False
        job=self._jobs().get(jid)
        if (not allowed or self.running or not job or job['status']!='REQUIERE_ATENCION'
                or job.get('email')!=old):
            self.queue_status.set('No cambié nada: no se confirmó ACCESO o el folio ya cambió. Revisa el HONOR.');return
        try:self._release_job_link(jid)
        except LinkError:
            self.queue_status.set('No se liberó el enlace; conserva el folio y revisa Outlook.');return
        if old:self._jobs().skip_email(jid,old)
        self._jobs().set(jid,'PENDIENTE',email=new,error='')
        self.queue_status.set('Correo cambiado. Se conservaron exactamente la CURP y el folio.')
        self._next_queue_check=0
        self._refresh_jobs()

    def _queue_tick(self):
        if (not self.queue_enabled.get() or self.running or self._dispatch_busy or self._closed
            or not self.connected or not self.accept_privacy.get()):return
        now=time.monotonic()
        if now<self._next_queue_check:return
        self._next_queue_check=now+2
        rows=self._refresh_jobs()
        if any(row['status']=='REQUIERE_ATENCION' for row in rows):
            self.queue_status.set('Cola detenida: selecciona y revisa el folio que requiere atención.');return
        jid,curp=self._jobs().oldest_pending()
        if not jid:return
        job=self._jobs().get(jid)
        if not self.link_enabled.get() and not job.get('email'):
            self.queue_status.set('Falta correo: conecta Outlook para asignarlo automáticamente.');return
        self._prepare(curp,job.get('email') or '',jid)

    def _prepare(self,curp,email,jid=None):
        if self._dispatch_busy:return
        linked=bool(self.link_enabled.get())
        identity=(jid,curp,email)
        if linked:
            if self._pending_session is not None and self._pending_identity!=identity:
                self.queue_status.set('Hay una reserva previa sin resolver; conserva el folio y revisa Outlook antes de cambiar datos.')
                return
            if self._pending_session is None:
                self._pending_session=Session(email=email)
                self._pending_identity=identity
        session=self._pending_session if linked else None
        if jid and session:self._jobs().set(jid,'PENDIENTE',link_id=session.request_id)
        self._dispatch_busy=True
        generation=self._prepare_generation
        self.queue_status.set('Preparando el folio; verificando disponibilidad del enlace...')
        def work():
            try:
                if linked:
                    session.prepare()
                self.put('link_prepared',(jid,curp,email,session,generation))
            except Exception as exc:
                record('link_prepare_failed',exc)
                self.put('prepare_failed',(jid,type(exc).__name__,generation))
        try:self._thread(work)
        except Exception as exc:self._on_prepare_failed(jid,type(exc).__name__,generation)

    def _on_prepare_failed(self,jid,error_type,generation=None):
        self._dispatch_busy=False
        if generation is not None and generation!=self._prepare_generation:return
        if error_type=='SessionInvalid' and jid:
            self._jobs().set(jid,'REQUIERE_ATENCION',error='Reserva inactiva; revisar Outlook antes de reintentar')
        self._next_queue_check=time.monotonic()+self._queue_retry
        self._queue_retry=min(30,self._queue_retry*2)
        self.queue_status.set('Esperando Outlook: '+error_type+'. Reintento con espera; CURP y folio conservados.')

    def _on_prepared(self,jid,curp,email,session,generation=None):
        self._dispatch_busy=False
        if generation is not None and generation!=self._prepare_generation:
            if jid:self._jobs().set(jid,'REQUIERE_ATENCION',email=session.email if session else email,
                                    error='Detenido durante la preparación; revisar reserva Outlook')
            self.queue_status.set('Preparación detenida. Se conserva el folio y la reserva para revisión.')
            return
        self._queue_retry=2
        self._session=session
        self._pending_session=None;self._pending_identity=None
        email=session.email if session else email
        self._prepared_form=(curp,email)
        self._current_job=jid
        self.curp.set(curp);self.email.set(email)
        if jid:self._jobs().set(jid,'ACTIVA',email=email,error='')
        if not self.start():
            if jid:self._jobs().set(jid,'REQUIERE_ATENCION',error='No se pudo iniciar; revisar teléfono y enlace')
            self._current_job=None;self._session=None;self._prepared_form=None
        self._refresh_jobs()

    def _on_flow_end(self,jid,outcome):
        self.running=False
        if jid:
            self._jobs().set(jid,'SOLICITUD_ENVIADA' if outcome=='finished' else 'REQUIERE_ATENCION',
                             error='' if outcome=='finished' else 'Revisar HONOR y correo antes de reintentar')
        if outcome=='finished' and self.flow and self.curp.get()==self.flow.curp:
            self.curp.set('');self.email.set('')
        self._current_job=None;self._session=None;self._prepared_form=None
        self._refresh_jobs()

    def authorize_transfer(self):
        if not self.flow or not self.connected:return
        if not messagebox.askyesno('Autorización de vinculación',
                '¿El titular de ESTE trámite autorizó expresamente vincular su CURP a este teléfono? '
                'Puede desvincular su dispositivo anterior. Se enviará un solo toque si el aviso exacto está visible.'):
            return
        def work():
            try:
                with self.lock:
                    nodes=self.adb.hierarchy()
                    result=self.flow.authorize_device_change(nodes,consent=True)
                self.put('status',result)
                self.advance.set()
            except Exception as exc:
                record('device_change_failed',exc)
                self.put('error',str(exc))
        self._thread(work)

    def _discover_port(self, binary, ip):
        return ADB(binary).tls_connection_ports(ip)

    def detect_port(self):
        if self.running or self.connecting:
            self.put('status', 'Primero detén el trámite o termina de conectar el celular.')
            return
        ip = self.ip.get().strip()
        if not valid_ipv4(ip):
            messagebox.showwarning('IP inválida', 'Escribe la IP que aparece en Depuración inalámbrica.')
            return
        path = adb_binary()
        if not path:
            messagebox.showwarning('ADB faltante', 'Pulsa Instalar ADB primero.')
            return
        self.put('status', 'Buscando el puerto activo del celular...')
        def work():
            try:
                with self.lock:
                    ports = self._discover_port(path, ip)
                if len(ports) == 1:
                    self.put('port_found', (ip, ports[0]))
                    self.put('status', 'Puerto de conexión detectado: ' + ports[0] + '. Conectando...')
                    self.put('auto_connect', True)
                    self.log_line('Puerto ADB detectado para ' + ip + ': ' + ports[0])
                elif len(ports) > 1:
                    self.put('error', 'Hay varios puertos ADB para esta IP: ' + ', '.join(ports) + '. Confirma cuál muestra el teléfono.')
                else:
                    self.put('error', 'No pude detectar el puerto por Wi-Fi. Comprueba que Depuración inalámbrica esté activada, ' 
                              'que ambos estén en la misma red y copia el puerto de "Dirección IP y puerto" del teléfono. ' 
                              'El puerto de vinculación NO funciona para conectar.')
            except Exception as exc:
                self.put('error', str(exc))
        self._thread(work)

    def connect(self):
        if self.running:
            messagebox.showwarning('Trámite activo', 'Detén el trámite antes de cambiar la conexión.')
            return
        if self.connecting:
            self.put('status', 'Ya estamos intentando conectar el celular...')
            return
        ip, port = self.ip.get().strip(), self.port.get().strip()
        if not valid_ipv4(ip):
            self.put('error', 'La dirección IP del celular es inválida.')
            return
        if port and not valid_port(port):
            self.put('error', 'El puerto es inválido. Puedes dejarlo vacío para detectar automáticamente.')
            return
        binary = adb_binary()
        if not binary:
            self.put('error', 'No se encontró ADB. Pulsa INSTALAR ADB primero.')
            return
        self.connecting = True
        self.connected = False
        self.adb = None
        self.put('connected', False)
        self.put('status', 'Buscando el puerto actual y conectando el celular por Wi-Fi...')
        def work():
            try:
                with self.lock:
                    working, events = connect_wifi(binary, ip, port)
                    self.adb = working
                    for event in events:
                        self.log_line(event)
                    self.put('port_found', (ip, working.serial.rsplit(':', 1)[1]))
                    self.put('connected', True)
                    self.put('status', 'Celular conectado correctamente. Ya puedes iniciar trámite IMSS.')
                    try:
                        self.put('preview', working.screenshot())
                    except DeviceError as exc:
                        self.log_line('Conectado, pero no se pudo mostrar la pantalla: ' + str(exc))
            except Exception as exc:
                self.put('connected', False)
                self.put('error', str(exc))
            finally:
                self.connecting = False
        self._thread(work)

    def pair(self):
        ip = self.ip.get().strip()
        if not valid_ipv4(ip):
            messagebox.showwarning('IP requerida', 'Primero escribe la dirección IP de Android.')
            return
        pp = simpledialog.askstring('Emparejar Wi-Fi',
                                    'En Android: Depuración inalámbrica → Vincular dispositivo con código.\n\n'
                                    'Escribe el PUERTO DE VINCULACIÓN (no el de conexión):', parent=self.root)
        if pp is None:
            return
        code = simpledialog.askstring('Código de vinculación ADB',
                                      'Escribe el código de 6 dígitos que muestra Android.\n'
                                      '(NO es el código del IMSS.)', parent=self.root)
        if code is None:
            return
        if not valid_port(pp) or not re.fullmatch(r'\d{6}', code):
            messagebox.showerror('Datos inválidos', 'Puerto válido y código de vinculación de 6 dígitos.')
            return
        path = adb_binary()
        if not path:
            messagebox.showwarning('ADB faltante', 'Primero pulsa Instalar ADB.')
            return
        self.put('status', 'Emparejando dispositivo por Wi-Fi...')
        def work():
            try:
                with self.lock:
                    result = ADB(path).pair(ip, pp, code)
                    if 'successfully paired' not in str(result).lower():
                        raise DeviceError('ADB no confirmó el emparejamiento: ' + str(result)[:300])
                    self.log_line(result or 'Emparejamiento terminado.')
                    # ADB anuncia el puerto de conexión (distinto al de vinculación).
                    time.sleep(0.8)
                    ports = self._discover_port(path, ip)
                if len(ports) == 1:
                    self.put('port_found', (ip, ports[0]))
                    self.put('status', 'Emparejado. Puerto de conexión detectado; conectando...')
                    self.put('auto_connect', True)
                else:
                    self.put('status', 'Emparejado. Introduce el puerto de "Dirección IP y puerto" y pulsa CONECTAR, ' 
                              'o usa DETECTAR PUERTO.')
            except Exception as e:
                self.put('error', str(e))
        self._thread(work)

    def install_adb(self):
        if adb_binary():
            messagebox.showinfo('ADB listo', 'ADB ya está instalado y disponible.')
            return
        self.put('status', 'Descargando ADB oficial de Google (requiere internet)...')
        def work():
            try:
                from instalar_adb import download_and_install
                download_and_install(BASE)
                if not adb_binary():
                    raise DeviceError('La descarga terminó, pero adb.exe no apareció.')
                self.put('status', 'ADB instalado. Puedes conectarte por Wi-Fi.')
                self.log_line('Platform Tools oficial instalado con validación del archivo y extracción temporal.')
            except Exception as e:
                self.put('error', 'No se pudo instalar ADB: ' + str(e))
        self._thread(work)

    def validate_input(self):
        email = self.email.get().strip().lower()
        curp = self.curp.get().strip().upper()
        if not re.fullmatch(r'[A-Za-z0-9._+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}', email):
            raise DeviceError('Ingresa un correo electrónico válido.')
        if not CURP.fullmatch(curp):
            raise DeviceError('La CURP no tiene un formato válido. Revisa fecha, sexo y estructura.')
        return email, curp

    def save_phone_pin(self):
        """Store PIN only on explicit click, encrypted with the logged-in Windows user DPAPI."""
        try:
            self._capture_session_pin()
            if not self._session_pin:
                raise DeviceError('Introduce el PIN antes de guardarlo.')
            pin_vault.save(self._session_pin)
            self.pin_storage_status.set('PIN guardado cifrado en esta PC (tu usuario de Windows).')
            self.status.set('PIN guardado. Se cargará automáticamente al volver a abrir el bot.')
        except (DeviceError, pin_vault.VaultError) as exc:
            messagebox.showerror('No se guardó el PIN', str(exc))

    def forget_phone_pin(self):
        try:
            pin_vault.forget()
        except pin_vault.VaultError as exc:
            messagebox.showerror('No se eliminó el PIN guardado',str(exc))
            return
        self._session_pin=None
        self.phone_pin.set('')
        self._auto_unlock_attempted=False
        self.auto_unlock.set(False)
        self.pin_storage_status.set('PIN eliminado; confirma la identidad manualmente en Android.')

    def _capture_session_pin(self):
        """Capture user PIN, or reload a previously saved encrypted PIN if needed."""
        self._auto_unlock_enabled=bool(self.auto_unlock.get())
        pin = self.phone_pin.get().strip()
        if pin:
            if not re.fullmatch(r'[0-9]{4,12}', pin):
                raise DeviceError('El PIN debe tener de 4 a 12 dígitos.')
            self._session_pin = pin
            self.phone_pin.set('')
            self._auto_unlock_attempted = False
            self.pin_storage_status.set('PIN disponible solo en esta sesión; guardar requiere el botón explícito.')
        if not self._session_pin:
            self._session_pin, msg = configured_pin(pin_vault)
            self.pin_storage_status.set(msg)
        return self._session_pin

    def _try_unlock_if_locked(self, nodes=None):
        """Un solo intento por aviso confirmado; jamás prueba PIN en otro formulario."""
        prompt = self.adb.security_prompt(nodes)
        if prompt is None:
            self._auto_unlock_attempted = False
            return
        if not self._auto_unlock_enabled or not self._session_pin:
            raise DeviceError('Android solicita ' + ('validación de identidad' if prompt == 'identidad' else 'desbloqueo') +
                              '. Escribe el PIN en el panel, activa el PIN automático y pulsa REANUDAR.')
        if self._auto_unlock_attempted:
            raise DeviceError('La validación de identidad sigue visible tras un intento. '
                              'Confirma el PIN manualmente y pulsa REANUDAR para evitar bloqueos.')
        self._auto_unlock_attempted = True
        if prompt == 'identidad':
            succeeded = self.adb.confirm_identity_pin(self._session_pin, nodes)
        else:
            succeeded = self.adb.unlock_with_pin(self._session_pin)
        if not succeeded:
            raise DeviceError('La pantalla de seguridad no se cerró después del PIN. '
                              'Confirma manualmente en el teléfono y pulsa REANUDAR.')
        self._auto_unlock_attempted = False
        self.log_line('Validación de identidad completada en Android.' if prompt == 'identidad'
                      else 'Celular desbloqueado automáticamente.')

    def unlock_phone(self):
        if not self.connected or not self.adb:
            messagebox.showwarning('Sin conexión', 'Primero conecta el celular por Wi-Fi.')
            return
        try:
            self._capture_session_pin()
            if not self._session_pin:
                raise DeviceError('Introduce el PIN en el panel primero.')
        except DeviceError as e:
            messagebox.showerror('PIN inválido', str(e))
            return
        def work():
            try:
                with self.lock:
                    prompt = self.adb.security_prompt()
                    if prompt is None:
                        self.put('status', 'Android no está mostrando un bloqueo o validación de identidad confirmados.')
                        return
                    if prompt == 'identidad':
                        ok = self.adb.confirm_identity_pin(self._session_pin)
                    else:
                        ok = self.adb.unlock_with_pin(self._session_pin)
                    self.put('preview', self.adb.screenshot())
                self.put('status', 'Validación completada.' if ok else
                         'La ventana de seguridad continúa abierta: comprueba el PIN manualmente.')
            except Exception as exc:
                self.put('error', 'No se pudo desbloquear: ' + str(exc))
        self._thread(work)

    def send_pin_confirmed(self):
        """Manual fallback. Must be explicitly invoked and confirmed by the user.

        Useful for OEM PIN dialogs invisible to UIAutomator/window focus. Never
        invoked automatically without security-prompt detection.
        """
        if not self.connected or not self.adb:
            messagebox.showwarning('Sin conexión', 'Primero conecta el celular por Wi-Fi.')
            return
        if not messagebox.askyesno(
                'Confirmar pantalla segura',
                '¿Ves AHORA la pantalla de Validación de identidad o PIN de Android?\n\n'
                'Sólo confirma si está visible; de lo contrario el PIN podría '
                'escribirse en un lugar equivocado.'):
            return
        try:
            pin = self._capture_session_pin()
            if not pin:
                raise DeviceError('No está configurado el PIN.')
        except DeviceError as exc:
            messagebox.showerror('PIN', str(exc))
            return
        self.put('status', 'Enviando PIN a la pantalla de identidad confirmada por ti...')
        def work():
            try:
                with self.lock:
                    self.adb.enter_pin_on_confirmation(pin)
                    self.put('preview', self.adb.screenshot())
                self.put('status', 'PIN enviado. Si la pantalla continúa visible, Android pudo bloquear la entrada ADB.')
                self.advance.set()
            except Exception as exc:
                self.put('error', 'No se pudo enviar el PIN: ' + str(exc))
        self._thread(work)

    def start(self):
        if self._dispatch_busy:return False
        if not self.connected or not self.adb:
            messagebox.showwarning('Sin conexión', 'Conecta primero el celular por Wi-Fi.')
            return
        if self.running:
            messagebox.showinfo('Ya está activo', 'El trámite ya está en curso. Usa Reanudar si lo necesitas.')
            return
        raw_curp=self.curp.get().strip().upper()
        raw_email=self.email.get().strip().lower()
        if self.link_enabled.get() and self._prepared_form!=(raw_curp,raw_email):
            if not CURP.fullmatch(raw_curp):
                messagebox.showerror('CURP','La CURP no tiene un formato válido.');return False
            if not self.accept_privacy.get():
                messagebox.showwarning('Privacidad','Acepta el aviso de privacidad antes de conectar el trámite.');return False
            self._prepare(raw_curp,raw_email)
            return False
        try:
            email, curp = self.validate_input()
        except DeviceError as e:
            messagebox.showerror('Datos incorrectos', str(e))
            return
        if not self.accept_privacy.get():
            messagebox.showwarning('Aviso de privacidad',
                                   'Lee el Aviso de Privacidad en IMSS Digital y marca la casilla '
                                   'de autorización del panel antes de iniciar.')
            return
        try:
            self._capture_session_pin()
        except DeviceError as e:
            messagebox.showerror('PIN inválido', str(e))
            return
        self.flow = IMSSFlow(self.adb, curp, email, self.log_line)
        self.flow.privacy_approved = True
        self.stop.clear()
        self.advance.clear()
        self.running = True
        self.put('status', 'Abriendo IMSS Digital...')
        try:self._thread(self.run_flow)
        except Exception as exc:
            self.running=False;record('imss_thread_start_failed',exc)
            self.put('error','No se pudo iniciar el hilo del trámite.');return False
        return True

    def run_flow(self):
        outcome=None
        jid=self._current_job
        session=self._session
        try:
            with self.lock:
                self._try_unlock_if_locked()
                pkgs = self.adb.packages()
                if APP_PACKAGE not in pkgs:
                    raise DeviceError('IMSS Digital no está instalado. Instálalo desde Google Play.')
                self.adb.launch()
            # Menos espera inicial. La detección de pantalla se hace inmediatamente.
            time.sleep(.55)
            retries = 0
            last_preview = 0.0
            while not self.stop.is_set():
                self.advance.clear()  # clear before reading Android, never after a manual response
                try:
                    with self.lock:
                        # UIAutomator primero: evita dos consultas dumpsys costosas
                        # en cada paso normal de IMSS Digital.
                        try:
                            nodes = self.adb.hierarchy()
                        except DeviceError as read_error:
                            # Algunos diálogos seguros bloquean UIAutomator. Si el
                            # foco confirma identidad, el PIN puede gestionarse;
                            # si no, mantener el programa activo y pedir acción.
                            if self.adb.security_prompt() == 'identidad':
                                self._try_unlock_if_locked()
                                time.sleep(.25)
                                continue
                            self.flow.pause_reason = (
                                'Android impide leer la ventana protegida. En el celular '
                                'comprueba si dice Validación de identidad; si es así pulsa '
                                'ENVIAR PIN AHORA, o escribe el PIN manualmente, y pulsa REANUDAR. '
                                'Detalle: ' + str(read_error)[:130])
                            result = 'paused'
                        else:
                            if ADB.credential_labels(nodes):
                                # Evidencia textual inequívoca de la ventana de seguridad.
                                self._try_unlock_if_locked(nodes)
                                time.sleep(.25)
                                nodes = self.adb.hierarchy()
                            result = self.flow.step(nodes)
                            if result == 'identity':
                                self.flow.pause_reason = (
                                    'Validación de identidad sigue en pantalla. '
                                    'Pulsa ENVIAR PIN AHORA si Android impidió la detección automática.')
                                result = 'paused'
                            elif result == 'paused' and self.flow.pause_reason.startswith('No identifiqué'):
                                # Si OEM oculta etiquetas, comprobar foco de Android
                                # sólo cuando realmente nos quedamos sin acciones.
                                prompt = self.adb.security_prompt(nodes)
                                if prompt:
                                    self._try_unlock_if_locked(nodes)
                                    result = 'retry'
                        now = time.monotonic()
                        if result in ('paused', 'code', 'finished') or now - last_preview > 3.0:
                            self.put('preview', self.adb.screenshot())
                            last_preview = now
                except DeviceError as e:
                    self.put('error', str(e))
                    break
                if result == 'finished':
                    outcome='finished'
                    if session:
                        try:session.done()
                        except LinkError as exc:record('imss_done_notification_failed',exc)
                    self.put('status', 'El IMSS confirmó el envío de la solicitud. Revisa el correo registrado.')
                    self.log_line('Solicitud completada según lo indicado en pantalla.')
                    break
                if result in ('code', 'paused'):
                    self.put('status', self.flow.pause_reason)
                    self.log_line(self.flow.pause_reason)
                    # No repetir consultas pesadas a Android esperando la intervención.
                    if result=='code' and jid:self._jobs().set(jid,'ESPERANDO_CODIGO')
                    last_link_poll=0.0
                    link_paused=False
                    while not self.stop.is_set() and not self.advance.wait(.25):
                        if result=='code' and session and not link_paused and time.monotonic()-last_link_poll>=1:
                            last_link_poll=time.monotonic()
                            try:
                                def submit(code):
                                    with self.lock:
                                        if self.stop.is_set():raise DeviceError('Proceso detenido antes de enviar código')
                                        self.flow.type_code(code)
                                if session.exchange(submit):break
                            except Exception as exc:
                                record('imss_code_exchange_failed',exc)
                                if session.manual or isinstance(exc,SessionInvalid) or not isinstance(exc,LinkError):
                                    link_paused=True
                                    self.put('error','Código automático detenido; revisa el HONOR antes de enviar manualmente.')
                    self.advance.clear()
                    retries = 0
                    continue
                if result == 'retry':
                    retries += 1
                    if retries >= 12:
                        self.put('status', 'La pantalla no terminó de cargar. Comprueba IMSS Digital y pulsa REANUDAR.')
                        while not self.stop.is_set() and not self.advance.wait(.25):
                            pass
                        self.advance.clear()
                        retries = 0
                    else:
                        time.sleep(.45)
                    continue
                retries = 0
                self.put('status', 'Trámite en progreso; avanzando en IMSS Digital...')
                time.sleep(.3)
            if self.stop.is_set():
                self.put('status', 'Proceso detenido. El folio de la cola, si existe, se conserva para revisión.')
        except Exception as e:
            record('imss_flow_failed',e)
            self.put('error', str(e))
        finally:
            self.put('flow_end',(jid,outcome))

    def send_code(self):
        code = self.code.get().strip()
        self.code.set('')  # borrado inmediato del campo; no se persiste
        if not self.flow or not self.adb:
            messagebox.showwarning('No iniciado', 'Primero inicia el trámite y espera la pantalla de verificación.')
            return
        if not re.fullmatch('[A-Za-z0-9]{4,10}', code):
            messagebox.showerror('Código inválido', 'Escribe el código completo (4 a 10 letras o números).')
            return
        if self._session:self._session.mark_manual()
        self.put('status', 'Colocando el código en IMSS Digital...')
        def work():
            try:
                with self.lock:
                    self._try_unlock_if_locked()
                    msg = self.flow.type_code(code)
                    self.put('preview', self.adb.screenshot())
                self.put('status', msg)
                self.log_line('Código colocado; no se guardó en disco.')
                self.advance.set()
            except Exception as e:
                self.put('error', str(e))
        self._thread(work)

    def resume(self):
        if not self.connected or not self.adb:
            messagebox.showwarning('Sin conexión', 'Conecta primero el celular.')
            return
        if self.flow:
            self.flow.last_action = None
            self.flow.privacy_approved = bool(self.accept_privacy.get())
            try:
                self._capture_session_pin()
            except DeviceError as e:
                messagebox.showerror('PIN inválido', str(e))
                return
        if self.running:
            self.put('status', 'Reanudando la detección automática...')
            self.advance.set()
        else:
            self.start()

    def halt(self):
        self._prepare_generation+=1
        self.queue_enabled.set(False)
        self.stop.set()
        self.advance.set()
        # Detener el proceso nunca borra el PIN fijo configurado.
        self.phone_pin.set('')
        self.put('status', 'Deteniendo operaciones en el teléfono...')

    def preview_tap(self, event):
        if not self.adb or not self.connected or not self.screen_image:
            return
        if event.x > self.screen_image.width() or event.y > self.screen_image.height():
            return
        w, h = self.screen_size
        x = min(w-1, event.x * self.scale)
        y = min(h-1, event.y * self.scale)
        def work():
            try:
                with self.lock:
                    self.adb.tap(x, y)
                    time.sleep(.7)
                    self.put('preview', self.adb.screenshot())
            except Exception as e:
                self.put('error', str(e))
        self._thread(work)

    def refresh_preview(self):
        if not self.adb:
            messagebox.showinfo('Sin conexión', 'Primero conecta el celular.')
            return
        def work():
            try:
                with self.lock:
                    self.put('preview', self.adb.screenshot())
            except Exception as e:
                self.put('error', str(e))
        self._thread(work)

    def get_pdf(self):
        if not self.adb:
            messagebox.showwarning('Sin conexión', 'Primero conecta el celular.')
            return
        self.put('status', 'Buscando archivos PDF en Descargas del celular...')
        def work():
            try:
                with self.lock:
                    paths = self.adb.list_download_pdfs()
                self.put('pdf_list', paths)
            except Exception as e:
                self.put('error', str(e))
        self._thread(work)

    def pdf_dialog(self, paths):
        if not paths:
            messagebox.showinfo('No hay PDF', 'No se encontraron PDFs en Descargas del celular.\n\n'
                                'Si el IMSS envió la constancia al correo, ábrelo y descárgala allí.')
            self.status.set('No se encontraron PDFs en Descargas del celular.')
            return
        window = tk.Toplevel(self.root)
        window.title('Elegir PDF de Descargas')
        window.geometry('600x350')
        window.configure(bg=DARK)
        tk.Label(window, text='Elige el archivo que deseas copiar a tu PC:',
                 bg=DARK, fg=GOLD, font=('Segoe UI', 12, 'bold')).pack(pady=12)
        lb = tk.Listbox(window, bg='#262626', fg='white', selectbackground=GOLD,
                        selectforeground=BLACK, font=('Segoe UI', 10))
        lb.pack(padx=15, fill='both', expand=True)
        for path in paths:
            lb.insert('end', path)
        def copy():
            if not lb.curselection():
                return
            remote = paths[lb.curselection()[0]]
            local_folder = filedialog.askdirectory(title='Guardar el PDF en...', parent=window)
            if not local_folder:
                return
            # Nunca cambiar el nombre remoto arbitrariamente ni copiar otro archivo.
            base = Path(remote).name
            if not base.lower().endswith('.pdf'):
                return
            dest = Path(local_folder) / base
            if dest.exists():
                dest = Path(local_folder) / (Path(base).stem + '_imss_' + time.strftime('%Y%m%d_%H%M%S') + '.pdf')
            window.destroy()
            def work():
                try:
                    with self.lock:
                        self.adb.pull_pdf(remote, dest)
                    self.put('status', 'PDF copiado en: ' + str(dest))
                    self.log_line('PDF transferido a la carpeta indicada.')
                except Exception as e:
                    self.put('error', str(e))
            self._thread(work)
        self._button(window, 'COPIAR PDF SELECCIONADO', copy, gold=True).pack(pady=12)
        self.status.set('Selecciona el PDF que deseas guardar en Windows.')

    def close(self):
        self._closed=True
        self._session_pin = None
        self.phone_pin.set('')
        self.stop.set()
        self.advance.set()
        self.root.destroy()

    def run(self):
        self.log_line('IMSS V10 independiente: identidad asistida, PIN privado opcional y enlace Outlook opcional.')
        self.root.mainloop()


if __name__ == '__main__':
    from ejecutar import main
    main()
