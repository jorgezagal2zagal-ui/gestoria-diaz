"""Optional IMSS client session. Folio/account binding; codes remain in memory only."""
import secrets, threading
from enlace import Client, LinkError

class SessionInvalid(LinkError):pass

class Session:
    def __init__(self,client=None,email='',request_id=None):
        self.client=client or Client()
        self.request_id=request_id or secrets.token_hex(16)
        self.email=email.strip().lower()
        self.written=False
        self.acknowledged=False
        self.manual=False
        self.lock=threading.RLock()
    def prepare(self):
        state=(self.client.begin(self.email,self.request_id) if self.email else
               self.client.reserve(self.request_id))
        self._validate(state)
        if state['status'] in ('CADUCADA','CANCELADA','SOLICITUD_IMSS_ENVIADA'):
            raise SessionInvalid('La sesión no está activa; requiere revisión del operador.')
        self.email=state['email']
        return self.email
    def _validate(self,state):
        if state.get('request_id')!=self.request_id:raise SessionInvalid('El folio del enlace no coincide.')
        if not state.get('email') or (self.email and state['email'].casefold()!=self.email.casefold()):
            raise SessionInvalid('El correo del enlace no coincide.')
    def exchange(self,submit):
        """At most one phone submission, even when the acknowledgement is lost."""
        with self.lock:
            if self.manual:return False
            if self.written:
                if not self.acknowledged:
                    self.client.ack(self.request_id);self.acknowledged=True
                return True
            state=self.client.status(self.request_id);self._validate(state)
            if state['status'] in ('CADUCADA','CANCELADA'):raise SessionInvalid('El enlace caducó o fue cancelado; revisa antes de reintentar.')
            if state['status']!='CODIGO_DISPONIBLE':return False
            code=state.get('code')
            if not isinstance(code,str) or len(code)!=6 or not code.isascii() or not code.isdigit():
                raise SessionInvalid('Código recibido inválido.')
            # Reserve the single attempt before ADB: an exception may mean a partial write.
            self.written=True
            try:submit(code)
            except Exception:
                self.manual=True
                raise
            self.client.ack(self.request_id);self.acknowledged=True
            return True
    def mark_manual(self):
        with self.lock:self.manual=True
    def done(self):return self.client.done(self.request_id)
