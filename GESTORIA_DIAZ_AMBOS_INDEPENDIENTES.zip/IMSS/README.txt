IMSS V10 independiente, basado en tu IMSS V9.
Lee README_PRIMERO.md y el informe de pruebas.
Ejecuta INSTALAR.bat y ABRIR_BOT.bat.
No hay PIN incorporado. Cambio de dispositivo solo con autorización expresa.
Windows y HONOR reales pendientes de validación.
