"""Gestoría Díaz - controlador ADB para IMSS Digital (sin contraseñas ni lectura de correo)."""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from diagnostico import record
import time
import unicodedata
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path

APP_PACKAGE = 'st.android.imsspublico'


def norm(s: str) -> str:
    s = unicodedata.normalize('NFKD', str(s or '')).encode('ascii', 'ignore').decode('ascii')
    return re.sub(r'\s+', ' ', s.lower()).strip()


def adb_binary() -> str | None:
    root = Path(__file__).resolve().parent
    names = [root / 'platform-tools' / 'adb.exe', root / 'platform-tools' / 'adb']
    sdk = os.environ.get('LOCALAPPDATA', '')
    if sdk:
        names.append(Path(sdk) / 'Android' / 'Sdk' / 'platform-tools' / 'adb.exe')
    for name in names:
        if name.exists():
            return str(name)
    return shutil.which('adb')


class DeviceError(RuntimeError):
    pass


@dataclass
class Node:
    text: str
    desc: str
    rid: str
    clazz: str
    bounds: tuple[int, int, int, int]
    clickable: bool = False
    enabled: bool = True
    focused: bool = False
    checkable: bool = False
    checked: bool = False

    @property
    def label(self) -> str:
        return norm(' '.join((self.text, self.desc, self.rid)))

    @property
    def cx(self) -> int:
        return (self.bounds[0] + self.bounds[2]) // 2

    @property
    def cy(self) -> int:
        return (self.bounds[1] + self.bounds[3]) // 2

    @property
    def editable(self) -> bool:
        return ('edittext' in norm(self.clazz) or 'textfield' in norm(self.clazz)) and self.enabled

    @property
    def valid(self) -> bool:
        return self.enabled and self.bounds[2] > self.bounds[0] and self.bounds[3] > self.bounds[1]


def parse_hierarchy(xml: str) -> list[Node]:
    try:
        root = ET.fromstring(xml)
    except ET.ParseError as exc:
        raise DeviceError('No se pudo leer la pantalla de Android. Desbloquea el equipo.') from exc
    items = []
    for e in root.iter('node'):
        a = e.attrib
        m = re.match(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]', a.get('bounds', ''))
        if not m:
            continue
        n = Node(a.get('text', ''), a.get('content-desc', ''), a.get('resource-id', ''),
                 a.get('class', ''), tuple(map(int, m.groups())),
                 a.get('clickable', '') == 'true', a.get('enabled', '') != 'false',
                 a.get('focused', '') == 'true',
                 a.get('checkable', '') == 'true', a.get('checked', '') == 'true')
        if n.valid:
            items.append(n)
    return items


class ADB:
    def __init__(self, binary: str, serial: str = ''):
        self.binary, self.serial = binary, serial

    def run(self, *cmd: str, timeout: int = 20, binary=False) -> str | bytes:
        argv = [self.binary] + (['-s', self.serial] if self.serial else []) + list(map(str, cmd))
        try:
            p = subprocess.run(argv, capture_output=True, timeout=timeout, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except FileNotFoundError as exc:
            raise DeviceError('Falta ADB. Presiona el botón Instalar ADB.') from exc
        except subprocess.TimeoutExpired as exc:
            raise DeviceError('El celular no respondió a tiempo por Wi-Fi.') from exc
        if p.returncode:
            record('adb_command_failed')
            raise DeviceError('ADB devolvió un error (salida '+str(p.returncode)+'). Revisa conexión y autorización en Android.')
        return p.stdout if binary else p.stdout.decode('utf-8', 'replace').strip()

    def connect(self, ip: str, port: str) -> str:
        # adb connect is a host-level command, not a command for an attached serial.
        host = ADB(self.binary)
        result = host.run('connect', f'{ip}:{port}', timeout=25)
        # El comando puede imprimir "failed to connect" incluso sin lanzar excepción.
        if not re.search(r'(?im)^\s*(connected to|already connected to)\s+', result):
            raise DeviceError(result or f'No se pudo conectar a {ip}:{port}.')
        return result

    def is_online(self) -> bool:
        try:
            return str(self.run('get-state', timeout=10)).strip() == 'device'
        except DeviceError:
            return False

    def connected_serials(self, ip: str) -> list[str]:
        """Retorna conexiones ADB en línea para la IP indicada, sin tocar otros equipos."""
        try:
            output = str(ADB(self.binary).run('devices', timeout=12))
        except DeviceError:
            return []
        found = []
        for line in output.splitlines():
            columns = line.split()
            if len(columns) >= 2 and columns[1] == 'device':
                address = columns[0]
                if re.fullmatch(re.escape(ip) + r':\d{1,5}', address):
                    port = int(address.rsplit(':', 1)[1])
                    if 1 <= port <= 65535 and address not in found:
                        found.append(address)
        return found

    def tls_connection_ports(self, ip: str) -> list[str]:
        """Busca sólo puertos TLS de CONEXIÓN anunciados por el Android de esta IP.

        No confunde `_adb-tls-pairing._tcp` con `_adb-tls-connect._tcp`.
        La lista de servicios puede quedar vacía si el Wi-Fi bloquea mDNS.
        """
        try:
            host = ADB(self.binary)
            listing = str(host.run('mdns', 'services', timeout=12))
        except DeviceError:
            return []
        ports: list[str] = []
        # ADB versión actual (espacios/tabs entre servicio y dirección),
        # aceptando el punto final opcional de `_tcp.` según implementación.
        rx = re.compile(r'_adb-tls-connect\._tcp\.?\s+(' + re.escape(ip) + r'):(\d{1,5})(?!\d)')
        for line in listing.splitlines():
            match = rx.search(line)
            if match:
                port = match.group(2)
                if 1 <= int(port) <= 65535 and port not in ports:
                    ports.append(port)
        return ports

    def pair(self, ip: str, port: str, code: str) -> str:
        return self.run('pair', f'{ip}:{port}', code, timeout=25)

    def lock_screen_state(self) -> bool | None:
        """Return True only with positive keyguard evidence; None if unrecognised.

        Never use a blind PIN entry: accidental typing into the IMSS app is unsafe.
        OEM Android versions differ in dumpsys keys, so unknown is NOT unlocked.
        """
        try:
            dump = str(self.run('shell', 'dumpsys', 'window', 'policy', timeout=12))
        except DeviceError:
            return None
        # True/false flags known across Android versions.
        flags = re.findall(
            r'(?i)\b(?:mShowingLockscreen|mKeyguardShowing|isKeyguardShowing|isStatusBarKeyguard|'
            r'mShowingDream|mIsKeyguardShowing|keyguardShowing)\s*[=:]\s*(true|false)\b', dump)
        if any(v.lower() == 'true' for v in flags):
            return True
        if flags and all(v.lower() == 'false' for v in flags):
            return False
        # No positive evidence: do not type a PIN on a possibly-unlocked phone.
        return None

    def unlock_with_pin(self, pin: str) -> bool:
        """Attempt one unlock; caller must require positive keyguard detection.

        Sends each digit as an Android key event; never logs or stores a password.
        """
        if not re.fullmatch(r'[0-9]{4,12}', pin):
            raise DeviceError('PIN inválido. Debe tener entre 4 y 12 números.')
        if self.lock_screen_state() is not True:
            raise DeviceError('No detecté un bloqueo de pantalla confirmado. No escribiré el PIN en otra aplicación.')
        self.key('KEYCODE_WAKEUP')
        size = str(self.run('shell', 'wm', 'size', timeout=12))
        matches = re.findall(r'(\d+)x(\d+)', size)
        width, height = tuple(map(int, matches[-1])) if matches else (1080, 2400)
        x = width // 2
        self.run('shell', 'input', 'swipe', x, int(height * .80), x, int(height * .25), 220, timeout=12)
        time.sleep(.35)
        # Android PIN keypad: KEYCODE_0 .. KEYCODE_9.
        for digit in pin:
            self.key('KEYCODE_' + digit)
        self.key('KEYCODE_ENTER')
        time.sleep(.55)
        return self.lock_screen_state() is False

    def packages(self) -> str:
        return self.run('shell', 'pm', 'list', 'packages', APP_PACKAGE)

    def launch(self) -> str:
        # El usuario tiene que desbloquear el teléfono: no se salta biometría o bloqueo.
        return self.run('shell', 'monkey', '-p', APP_PACKAGE, '-c', 'android.intent.category.LAUNCHER', '1')

    def tap(self, x: int, y: int) -> None:
        self.run('shell', 'input', 'tap', int(x), int(y), timeout=12)

    def tap_node(self, node: Node) -> None:
        self.tap(node.cx, node.cy)

    def text(self, value: str) -> None:
        # La CURP, correo y OTP se validan y no incluyen metacaracteres de shell.
        self.run('shell', 'input', 'text', value, timeout=15)

    def key(self, name: str) -> None:
        self.run('shell', 'input', 'keyevent', name, timeout=12)

    def hierarchy(self) -> list[Node]:
        """Lee UIAutomator por la ruta de Android correcta, sin archivos persistentes.

        /sdcard puede rechazar la creación de archivos durante una pantalla segura;
        /data/local/tmp suele estar disponible para ADB. No da por hecho que dump
        creó el archivo: comprueba salida, lectura y XML antes de procesarlo.
        """
        failures = []
        for remote in ('/data/local/tmp/window_imss.xml', '/sdcard/window_imss.xml'):
            try:
                # Remover un archivo viejo para no interpretar una pantalla obsoleta.
                self.run('shell', 'rm', '-f', remote, timeout=6)
                output = str(self.run('shell', 'uiautomator', 'dump', remote, timeout=18))
                if 'ERROR:' in output.upper() or 'exception' in output.lower():
                    raise DeviceError(output[:200])
                xml = str(self.run('shell', 'cat', remote, timeout=9))
                start = xml.find('<?xml')
                if start < 0:
                    start = xml.find('<hierarchy')
                if start < 0:
                    raise DeviceError('El volcado no contenía una jerarquía XML.')
                return parse_hierarchy(xml[start:])
            except DeviceError as exc:
                failures.append(str(exc)[:100])
            finally:
                try:
                    self.run('shell', 'rm', '-f', remote, timeout=6)
                except DeviceError:
                    pass
        raise DeviceError('Android no permitió leer la pantalla. Si ves "Validación de identidad", '
                          'confirma el PIN en el teléfono o usa el desbloqueo automático con el PIN '
                          'configurado en este panel. Detalle: ' + '; '.join(failures)[:170])

    @staticmethod
    def credential_labels(nodes: list[Node]) -> bool:
        """Evidencia explícita de un aviso de confirmación de identidad Android."""
        all_text = norm(' '.join((n.text + ' ' + n.desc) for n in nodes))
        # Pantallas OEM HONOR/Huawei: algunos leen el título y el subtítulo
        # en nodos diferentes o exponen solo una parte del texto.
        title = ('validacion de identidad' in all_text or
                 'verificacion de identidad' in all_text)
        detail = ('confirma tu identidad' in all_text or 'para ingresar' in all_text or
                  'introduce el pin' in all_text or 'ingresa tu pin' in all_text)
        return title and detail

    def security_prompt(self, nodes: list[Node] | None = None) -> str | None:
        """Confirm a system-owned credential UI via hierarchy or foreground window/activity.

        No PIN is sent to an arbitrary app. A secure OEM screen may hide
        UIAutomator and require user entry; in that case report uncertainty.
        """
        if nodes and self.credential_labels(nodes):
            return 'identidad'
        focused = ''
        try:
            dump = str(self.run('shell', 'dumpsys', 'window', 'windows', timeout=10))
            focus_lines = re.findall(
                r'(?im)^\s*(?:mCurrentFocus|mFocusedApp)\s*=\s*(.+)$', dump)
            focused = norm(' '.join(focus_lines))
        except DeviceError:
            pass
        # Some Android builds expose the current Activity only via activity dump.
        activity = ''
        try:
            dump = str(self.run('shell', 'dumpsys', 'activity', 'activities', timeout=12))
            lines = [line for line in dump.splitlines()
                     if re.search(r'(?i)\b(?:topResumedActivity|mResumedActivity|ResumedActivity)\b', line)]
            activity = norm(' '.join(lines[:4]))
        except DeviceError:
            pass
        foreground = focused + ' ' + activity
        system_packages = (
            'com.android.settings', 'com.android.systemui', 'com.android.keyguard',
            'com.google.android.permissioncontroller', 'com.huawei.systemmanager',
            'com.hihonor.systemmanager', 'com.huawei.securitymgr',
            'com.hihonor.securitymgr', 'com.android.permissioncontroller',
            'com.hihonor.systemui', 'com.huawei.systemui', 'com.hihonor.settings',
            'com.huawei.settings', 'com.hihonor.keyguard', 'com.huawei.keyguard',
            'com.hihonor.securitycenter', 'com.huawei.securitycenter',
            'com.hihonor.securityassistant', 'com.huawei.securityassistant',
            'com.huawei.android.hwlockscreen', 'com.hihonor.android.hwlockscreen',
        )
        markers = (
            'confirmlockpassword', 'confirmcredential', 'confirmdevicecredential',
            'confirm_lock', 'confirm_lock_password', 'confirmlockpattern',
            'keyguardbouncer', 'keyguardpin', 'keyguardpassword',
            'passwordconfirm', 'confirmcredentials', 'pinentry', 'pinview',
            'verifycredential', 'verifydevicecredential', 'confirmfingerprint',
            'verifyidentity', 'verifyidentityactivity', 'confirmidentity',
            'securityverification', 'credentialcheck', 'pinverification',
        )
        if any(pkg in foreground for pkg in system_packages) and any(m in foreground for m in markers):
            return 'identidad'
        if self.lock_screen_state() is True:
            return 'bloqueo'
        return None

    def confirm_identity_pin(self, pin: str, nodes: list[Node] | None = None) -> bool:
        """Un solo intento de PIN en una ventana protegida identificada."""
        if not re.fullmatch(r'[0-9]{4,12}', pin):
            raise DeviceError('El PIN debe tener entre 4 y 12 números.')
        if self.security_prompt(nodes) != 'identidad':
            raise DeviceError('No se confirmó la pantalla segura de identidad. No se introdujo el PIN.')
        # Algunos HONOR muestran un teclado de PIN con números accesibles como
        # botones; tocarlos es más compatible que enviar KEYCODE_N desde ADB.
        # No usamos coordenadas fijas: sólo números de la ventana confirmada.
        digit_buttons: dict[str, Node] = {}
        for n in (nodes or []):
            label = norm(n.text or n.desc)
            if n.clickable and n.valid and re.fullmatch(r'[0-9]', label):
                digit_buttons.setdefault(label, n)
        if len(digit_buttons) >= 9 and all(d in digit_buttons for d in pin):
            for digit in pin:
                self.tap_node(digit_buttons[digit])
        else:
            for digit in pin:
                self.key('KEYCODE_' + digit)
            self.key('KEYCODE_ENTER')
        time.sleep(.45)
        # La pantalla puede bloquear inspección aun después de aceptar el PIN;
        # el resultado desconocido NO es prueba de desbloqueo.
        try:
            after = self.hierarchy()
        except DeviceError:
            return self.security_prompt() is None
        return bool(after) and not self.credential_labels(after)

    def enter_pin_on_confirmation(self, pin: str) -> None:
        """One explicit user-confirmed PIN entry; does not bypass Android security.

        Only call following direct UI confirmation that the phone currently
        displays a device-credential screen. OEM may block ADB injections.
        """
        if not re.fullmatch(r'[0-9]{4,12}', pin):
            raise DeviceError('PIN inválido.')
        for digit in pin:
            self.key('KEYCODE_' + digit)
        self.key('KEYCODE_ENTER')

    def screenshot(self) -> bytes:
        return self.run('exec-out', 'screencap', '-p', timeout=18, binary=True)

    def list_download_pdfs(self) -> list[str]:
        out = self.run('shell', 'find', '/sdcard/Download', '-type', 'f', '-iname', '*.pdf', timeout=25)
        return [s.strip() for s in out.splitlines() if s.strip().lower().endswith('.pdf')][:100]

    def pull_pdf(self, remote: str, destination: Path) -> None:
        self.run('pull', remote, str(destination), timeout=60)


def connect_wifi(binary: str, ip: str, requested_port: str = '') -> tuple[ADB, list[str]]:
    """Conecta por TLS inalámbrico con una IP conocida y autorización ADB existente.

    Prioridad: conexión ya activa > servicio TLS anunciado > puerto manual.
    Nunca explora puertos al azar ni otros dispositivos de la red.
    """
    host = ADB(binary)
    events: list[str] = []
    for serial in host.connected_serials(ip):
        candidate = ADB(binary, serial)
        if candidate.is_online():
            events.append('Reutilizando conexión Wi-Fi existente: ' + serial)
            return candidate, events
    ports = host.tls_connection_ports(ip)
    if ports:
        events.append('Puerto Wi-Fi actual descubierto automáticamente: ' + ', '.join(ports))
    elif requested_port:
        events.append('No hay anuncio mDNS; probando puerto manual: ' + requested_port)
    else:
        raise DeviceError('No se encontró el puerto de conexión automáticamente. En el celular abre '
                          'Opciones de desarrollador > Depuración inalámbrica y copia el puerto que '
                          'aparece en "Dirección IP y puerto". Comprueba que PC y celular estén en '
                          'la misma red Wi-Fi. No utilices el puerto de vinculación.')
    # Puerto manual sólo como recurso adicional; puede ser antiguo o de vinculación.
    if requested_port and requested_port not in ports:
        ports.append(requested_port)
    failures = []
    for port in ports:
        try:
            host.connect(ip, port)
            candidate = ADB(binary, f'{ip}:{port}')
            if not candidate.is_online():
                raise DeviceError('El dispositivo no respondió como conectado.')
            events.append('Conectado con éxito a ' + candidate.serial)
            return candidate, events
        except DeviceError as exc:
            failures.append(f'{port}: {str(exc)[:150]}')
    raise DeviceError('No se pudo conectar por Wi-Fi. Comprueba en Android la dirección IP '
                      'y el PUERTO DE CONEXIÓN actual, activa Depuración inalámbrica y '
                      'verifica que ambos equipos estén en la misma red. '
                      'Detalle: ' + '; '.join(failures)[:250])


class IMSSFlow:
    """Avanza de forma conservadora, nunca inventa campos ni supera verificaciones."""
    def __init__(self, adb: ADB, curp: str, email: str, report):
        self.adb = adb
        self.curp = curp
        self.email = email
        self.report = report
        self.last_action: tuple[str, str] | None = None
        self.pause_reason = ''
        self.report_requested = False
        self.privacy_approved = False  # Consentimiento confirmado explícitamente en el panel.
        self.privacy_web_fallback = False
        self.transfer_attempted = False

    @staticmethod
    def visible(nodes):
        return [x for x in nodes if x.valid]

    def screen_summary(self, nodes: list[Node]) -> str:
        return ' | '.join(x.label[:80] for x in nodes if (x.text or x.desc))[:1200]

    @staticmethod
    def match(nodes, terms, exclude=()):
        terms = [norm(t) for t in terms]
        exclude = [norm(t) for t in exclude]
        choices = [n for n in nodes if n.valid and any(t in n.label for t in terms) and
                   not any(t in n.label for t in exclude)]
        choices.sort(key=lambda n: (not n.clickable, n.cy, n.cx))
        return choices[0] if choices else None

    def click_once(self, nodes, terms, event, exclude=()) -> bool:
        n = self.match(nodes, terms, exclude=exclude)
        if n is None:
            return False
        # Evita toques cíclicos idénticos sobre la misma pantalla.
        screen_key = self.screen_summary(nodes)[:500]
        key = (event, screen_key)
        if self.last_action == key:
            return False
        self.adb.tap_node(n)
        self.last_action = key
        self.report(event)
        return True

    def privacy_checkbox(self, nodes: list[Node]):
        """Busca la casilla real de consentimiento, no el interruptor de sesión."""
        anchors = [n for n in nodes if n.valid and any(
            term in n.label for term in ('he leido y acepto', 'acepto el aviso',
                                          'acepto el aviso de privacidad', 'aceptar aviso de privacidad'))]
        checks = [n for n in nodes if n.valid and n.checkable and
                  not any(term in n.label for term in ('mantener sesion', 'recordarme', 'remember me'))]
        # En WebView, el texto y la casilla suelen ser nodos hermanos.
        if anchors:
            label = anchors[0]
            near = [n for n in checks if abs(n.cy - label.cy) < 90 and n.cx <= label.cx + 45]
            if near:
                return min(near, key=lambda n: (abs(n.cy-label.cy), abs(n.cx-label.cx)))
            # Algunas versiones incluyen casilla+texto en el mismo nodo accesible.
            if label.checkable:
                return label
        for n in checks:
            if 'aviso' in n.label or 'privacidad' in n.label or 'acepto' in n.label:
                return n
        return None

    def ensure_privacy(self, nodes: list[Node]) -> str:
        """Sólo marca la casilla si el usuario habilitó la autorización en el panel."""
        if not self.privacy_approved:
            self.pause_reason = ('Para continuar, lee el Aviso de Privacidad del IMSS y '
                                 'marca la autorización en el panel. Luego pulsa REANUDAR.')
            return 'paused'
        box = self.privacy_checkbox(nodes)
        if box is None:
            # WebView antiguos exponen el texto de la etiqueta, pero no el
            # atributo checked del <input type=checkbox>. Tocar a su izquierda
            # una sola vez; la validación del formulario decide si está marcada.
            label = next((n for n in nodes if n.valid and
                          ('he leido y acepto' in n.label or 'acepto el aviso' in n.label)), None)
            if label is not None:
                if not self.privacy_web_fallback:
                    self.adb.tap(max(2, label.bounds[0] - 22), label.cy)
                    self.privacy_web_fallback = True
                    self.report('Activando la casilla de privacidad en WebView...')
                    return 'action'
                return 'ok'
            self.pause_reason = ('No identifiqué con seguridad la casilla de privacidad. '
                                 'Márcala en el celular y pulsa REANUDAR.')
            return 'paused'
        if box.checked:
            return 'ok'
        # Evita pulsar de nuevo mientras Android aún no haya actualizado la pantalla.
        key = ('Aceptando aviso de privacidad', self.screen_summary(nodes)[:500])
        if self.last_action == key:
            self.pause_reason = ('La casilla no cambió tras pulsarla. Confírmala en el '
                                 'celular y pulsa REANUDAR.')
            return 'paused'
        self.adb.tap_node(box)
        self.last_action = key
        self.report('Marcando casilla de privacidad del IMSS...')
        return 'action'

    @staticmethod
    def nearby_edit(nodes: list[Node], terms: list[str]):
        edits = [n for n in nodes if n.editable]
        if not edits:
            return None
        tagged = [n for n in edits if any(t in n.label for t in terms)]
        if tagged:
            return tagged[0]
        labels = [n for n in nodes if not n.editable and any(t in n.label for t in terms)]
        if not labels:
            return None
        def score(edit):
            return min(abs(edit.cy - l.cy) + (250 if edit.cy < l.cy-100 else 0) for l in labels)
        best = min(edits, key=score)
        return best if score(best) < 340 else None

    def input_to(self, field: Node, value: str, label: str) -> bool:
        if field.text.strip() == value:
            return False
        if field.text.strip() and field.text.strip() not in ('Correo electrónico', 'CURP', 'Email'):
            # No sobrescribe otro dato potencialmente introducido por el usuario.
            if norm(field.text) == norm(value):
                return False
        self.adb.tap_node(field)
        self.adb.key('KEYCODE_MOVE_END')
        # Solo borrar cuando el EditText tiene contenido real, no el placeholder.
        if field.text.strip() and field.text.strip().lower() not in ('correo electrónico', 'curp', 'email'):
            for _ in range(min(len(field.text), 60)):
                self.adb.key('KEYCODE_DEL')
        self.adb.text(value)
        # Close Android's soft keyboard; otherwise it can cover the next form field.
        self.adb.key('KEYCODE_BACK')
        self.report(f'{label} capturado.')
        return True

    def is_code_screen(self, nodes: list[Node]) -> bool:
        summary = self.screen_summary(nodes)
        edits = [n for n in nodes if n.editable]
        if not edits:
            return False
        keys = ('codigo de verificacion', 'ingresa el codigo', 'introduce el codigo',
                'codigo enviado', 'verificar codigo', 'verification code',
                'validar codigo', 'codigo de seguridad', 'otp', 'token')
        return any(s in summary for s in keys) or (
            'codigo' in summary and (
                'verific' in summary or 'enviad' in summary or 'confirm' in summary
                or (len(edits) == 1 and 'curp' not in summary and 'correo electronico' not in summary)
            )
        )

    def type_code(self, code: str) -> str:
        if not re.fullmatch(r'[A-Za-z0-9]{4,10}', code):
            raise DeviceError('El código debe tener de 4 a 10 letras o números.')
        nodes = self.adb.hierarchy()
        detected = self.is_code_screen(nodes)
        edits = [n for n in nodes if n.editable]
        focused = [n for n in edits if n.focused]
        if not detected:
            # Compatibilidad con WebView: permite pegar en la casilla previamente
            # seleccionada por la persona, excepto en pantallas de CURP/correo.
            summary = self.screen_summary(nodes)
            if not focused or ('curp' in summary or 'correo electronico' in summary):
                raise DeviceError('No detecté el código. Toca la casilla de verificación en el celular y reintenta.')
        field = (self.nearby_edit(nodes, ['codigo', 'verificacion', 'otp', 'token'])
                 if detected else focused[0])
        if field is None and edits:
            field = edits[0]
        if field is None:
            raise DeviceError('No se detectó un campo de texto para el código.')
        self.adb.tap_node(field)
        if len(edits) >= 4 and len(edits) <= 10 and all((e.bounds[2]-e.bounds[0]) < 130 for e in edits):
            # Casillas de un carácter: enviarlos como teclas, respetando avance de foco.
            for digit in code.upper():
                if digit.isdigit():
                    self.adb.key('KEYCODE_' + digit)
                else:
                    self.adb.text(digit)
        else:
            self.adb.text(code)
        time.sleep(.2)
        after = self.adb.hierarchy()
        self.click_once(after, ['verificar', 'validar', 'confirmar', 'continuar', 'aceptar'],
                        'Código enviado a IMSS Digital.', exclude=('reenviar', 'reenvio', 'nuevo codigo', 'cancelar'))
        self.report('Código escrito. Comprobando la siguiente pantalla...')
        self.last_action = None
        return 'Código colocado en el celular; continuando el trámite.'

    def device_transfer_dialog(self, nodes: list[Node]) -> bool:
        summary = self.screen_summary(nodes)
        return ('curp' in summary and ('vinculad' in summary or 'dispositivo' in summary)
                and ('quiero hacer el cambio' in summary or 'deseas vincular' in summary
                     or 'deseas realizar' in summary or 'deseas hacer' in summary))

    def authorize_device_change(self,nodes,consent=False):
        if not consent:raise DeviceError('Se requiere autorización expresa del titular.')
        if self.transfer_attempted:raise DeviceError('Ya se intentó el cambio; revisa el teléfono. No se repetirá.')
        if not self.device_transfer_dialog(nodes):raise DeviceError('El aviso exacto de cambio ya no está visible.')
        yes=self.match(nodes,['si, quiero hacer el cambio','si quiero hacer el cambio','confirmar cambio'])
        if yes is None:raise DeviceError('No se detectó el botón afirmativo; no se tocó la pantalla.')
        self.transfer_attempted=True
        self.adb.tap_node(yes)
        self.report('Se pulsó el cambio autorizado una vez; pendiente confirmar avance en IMSS.')
        return 'Cambio autorizado enviado; comprueba el avance en el teléfono.'

    def step(self, nodes: list[Node]) -> str:
        summary = self.screen_summary(nodes)
        editable = [n for n in nodes if n.editable]
        # No se debe intentar pulsar botones IMSS bajo una ventana del sistema.
        # El panel gestionará el PIN sólo con evidencia explícita de identidad.
        if ADB.credential_labels(nodes):
            self.pause_reason = ('Android solicita Validación de identidad. '
                                 'Si no avanza automáticamente, pulsa ENVIAR PIN AHORA.')
            return 'identity'
        if self.device_transfer_dialog(nodes):
            self.pause_reason = ('Cambio de dispositivo pendiente. Solicita autorización expresa del titular '
                                 'y pulsa AUTORIZAR CAMBIO DE DISPOSITIVO. No se pulsó ningún botón.')
            return 'paused'
        if any(x in summary for x in ('se envio', 'fue enviada', 'constancia enviada',
                                     'solicitud exitosa', 'solicitud realizada',
                                     'solicitud se ha enviado', 'enviaremos tu constancia')):
            return 'finished'
        if any(s in summary for s in ('error de validacion', 'no se pudo', 'datos incorrectos',
                                     'codigo incorrecto', 'servicio no disponible')):
            self.pause_reason = 'IMSS mostró un error. Revísalo en la vista del celular.'
            return 'paused'
        if self.is_code_screen(nodes):
            self.pause_reason = 'Escribe el código recibido en el panel y pulsa ENVIAR CÓDIGO.'
            return 'code'
        if ('nss' in summary or 'numero de seguridad social' in summary) and editable and not (
                'correo' in summary and 'curp' in summary and len(editable) < 3):
            self.pause_reason = 'Esta pantalla exige NSS. Captúralo directamente en el celular y pulsa Reanudar.'
            return 'paused'
        # Una página de inicio de sesión requiere confirmar la casilla ANTES de
        # enviar correo y CURP. Nunca pulsar mantener sesión iniciada por error.
        login_screen = (('iniciar sesion' in summary or 'inicia sesion' in summary)
                        and ('curp' in summary or 'correo' in summary))
        if login_screen and ('he leido y acepto' in summary or 'acepto el aviso' in summary
                             or 'aviso de privacidad' in summary):
            privacy_result = self.ensure_privacy(nodes)
            if privacy_result != 'ok':
                return privacy_result
        curp_field = self.nearby_edit(nodes, ['curp'])
        mail_field = self.nearby_edit(nodes, ['correo electronico', 'e-mail', 'email'])
        # Si los labels no aparecen como nodos, dos campos ordenados de pantalla de ingreso.
        if not curp_field and not mail_field and len(editable) == 2 and ('iniciar sesion' in summary or 'ingresar' in summary):
            curp_field, mail_field = sorted(editable, key=lambda e: e.cy)
        if curp_field or mail_field:
            did = False
            if curp_field:
                did |= self.input_to(curp_field, self.curp, 'CURP')
                if mail_field:
                    # Bounds may shift after opening/closing the soft keyboard.
                    fresh = self.adb.hierarchy()
                    mail_field = self.nearby_edit(fresh, ['correo electronico', 'e-mail', 'email']) or next((e for e in fresh if e.editable and e != curp_field), None)
            if mail_field:
                did |= self.input_to(mail_field, self.email, 'Correo')
            if did:
                time.sleep(.55)
                nodes = self.adb.hierarchy()
            if self.click_once(nodes, ['continuar', 'iniciar sesion', 'ingresar', 'siguiente', 'acceder', 'consultar'],
                               'Datos enviados al IMSS.', exclude=('google', 'crear cuenta', 'registrar')):
                return 'action'
            if did:
                return 'action'
        # Vista explicativa del trámite en la app oficial: avanzar antes de solicitar.
        if 'constancia de semanas cotizadas' in summary and self.click_once(
                nodes, ['continuar', 'siguiente'], 'Avanzando a la solicitud de constancia.'):
            return 'action'
        # Ingresar al servicio desde la pantalla inicial.
        if self.click_once(nodes, ['constancia de semanas cotizadas', 'semanas cotizadas', 'semanas de cotizacion'],
                           'Abriendo Semanas Cotizadas.'):
            return 'action'
        # Pantalla posterior a la autenticación; la elección de reporte detallado se deja en default.
        if ('semanas' in summary or 'cotizad' in summary) and self.click_once(
                nodes, ['solicitar constancia', 'solicitar reporte', 'generar constancia',
                        'consultar semanas', 'obtener constancia', 'solicitar', 'consultar'],
                'Solicitando constancia de semanas cotizadas.',
                exclude=('salir', 'cancelar', 'volver')):
            self.report_requested = True
            return 'action'
        # Evita pausar durante una carga breve de WebView o una transición.
        if not editable and (not summary.strip() or any(x in summary for x in
                ('cargando', 'espere por favor', 'procesando solicitud', 'loading', 'un momento'))):
            return 'retry'
        self.pause_reason = ('No identifiqué un botón seguro. Si Android muestra Validación de identidad, '
                             'usa ENVIAR PIN AHORA; de lo contrario toca la opción correcta y pulsa REANUDAR.')
        return 'paused'
