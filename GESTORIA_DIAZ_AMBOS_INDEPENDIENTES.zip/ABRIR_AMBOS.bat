@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0OUTLOOK\ABRIR_OUTLOOK.bat"
start "" "%~dp0IMSS\ABRIR_BOT.bat"
